import React from "react";
import { useState, useEffect } from "react";
import Typography from "@material-ui/core/Typography";
import DirectionsWalkIcon from "@material-ui/icons/DirectionsWalk";
import Card from "@material-ui/core/Card";
import CardContent from "@material-ui/core/CardContent";
import Button from "@material-ui/core/Button";
import IconButton from "@material-ui/core/IconButton";
import CloseIcon from "@material-ui/icons/Close";
import Slide from "@material-ui/core/Slide";
import Switch from "@material-ui/core/Switch";
import DirectionsBusIcon from "@material-ui/icons/DirectionsBus";
import DirectionsBikeIcon from "@material-ui/icons/DirectionsBike";

interface Props {
    name: string;
    description: string;
}
interface Payload {
    startPos: string;
    endPos: string;
    minutesAvailable: string;
    transportMode: string;
}

const style = {
    icon: {
        display: "flex",
        margin: "auto",
    },
    outlinedText: {
        color: "#FF45AB",
    },
    button: {
        background: "#FF45AB",
        color: "white",
    },
    card: {
        minWidth: "275",
        background: "#EDE9ED",
        position: "fixed" as "fixed",
        bottom: 0,
        borderRadius: "29px 29px 0px 0px",
    },
    alignText: {
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
    },
    iconWrapper: {
        display: "flex",
        alignItems: "center",
        justifyContent: "space-around",
    },
    closeButton: {
        position: "absolute" as "absolute",
        right: 0,
        top: 0,
    },
};

const Popup: React.FC<Props> = ({ name, description }) => {
    const [checked, setChecked] = useState(true);
    const [data, setData] = useState(undefined);

    const payload = {
        startPos: "7",
        endPos: "2",
        minutesAvailable: "34",
        transportMode: "walk",
    };

    useEffect(() => {
        getTransport(payload);
    }, []);

    const handleChange = () => {
        setChecked(!checked);
    };

    const handleClick = () => {
        window.location.href =
            "https://www.google.com/maps/dir/Bodø/67.291488,14.3424781/@67.291488,14.3424781";
    };

    const getTransport = (payload: Payload) => {
        fetch(
            `http://52.157.70.191/api/route?startPOIID=${payload.startPos}&endPOIID=${payload.endPos}&minutesAvailable=${payload.minutesAvailable}&transportMode=${payload.transportMode}`
        )
            .then((res) => res.json())
            .then((res) => {
                console.log(res);
                setData(res);
            });
    };

    return (
        <div>
            <Switch checked={checked} onChange={handleChange} />
            <Slide direction="up" in={checked} mountOnEnter unmountOnExit>
                <Card style={style.card}>
                    <CardContent>
                        <Typography variant="h4" style={{ fontWeight: "bold" }}>
                            {name}
                        </Typography>
                        <IconButton
                            style={style.closeButton}
                            onClick={handleChange}
                        >
                            <CloseIcon />
                        </IconButton>
                        <div style={{ marginTop: 8 }}>
                            <span style={style.outlinedText}>Åpen nå </span>
                            <span>16:00 - 00:00</span>
                        </div>
                        <br></br>
                        <div style={style.iconWrapper}>
                            <div style={style.alignText}>
                                <DirectionsWalkIcon
                                    style={style.outlinedText}
                                />
                                <span style={style.outlinedText}>20 min.</span>
                            </div>
                            <div style={style.alignText}>
                                <DirectionsBusIcon style={style.outlinedText} />
                                <span style={style.outlinedText}>5 min.</span>
                            </div>
                            <div style={style.alignText}>
                                <DirectionsBikeIcon
                                    style={style.outlinedText}
                                />
                                <span style={style.outlinedText}>10 min.</span>
                            </div>
                        </div>
                        <p>{description}</p>
                        <Button
                            variant="contained"
                            style={style.button}
                            onClick={handleClick}
                        >
                            Vis meg veien
                        </Button>
                    </CardContent>
                </Card>
            </Slide>
        </div>
    );
};

export default Popup;
