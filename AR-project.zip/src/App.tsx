import React from "react";
import Popup from "./components/popup/popup";
import "./App.css";

function App() {
    const description =
        "På vår scene skjer det stadig ting. Sjekk ut programmet for denne uka for å se hva du ikke bør gå glipp av";
    return (
        <div className="App">
            <Popup name="Tollboden" description={description}></Popup>
        </div>
    );
}

export default App;
