﻿using Microsoft.Extensions.Configuration;
using Newtonsoft.Json.Linq;
using PointOfInterest.Facades;
using PointOfInterest.Facades.EnTur;
using PointOfInterest.Models.Directions;
using PointOfInterest.Models.Places;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace PointOfInterest.Services.Implementation
{
    public class DirectionsService : IDirectionsService
    {

        private readonly IConfiguration _configuration;
        private readonly IWeatherFacade _weatherFacade;
        private readonly IOttoFacade _ottoFacade;
        private readonly IEnTurFacade _enTurFacade;

        public DirectionsService(IConfiguration configuration, IWeatherFacade weatherFacade, IOttoFacade ottoFacade, IEnTurFacade enTurFacade)
        {
            _configuration = configuration;
            _weatherFacade = weatherFacade;
            _ottoFacade = ottoFacade;
            _enTurFacade = enTurFacade;
        }

        public async Task<EnTurJourneyPlanResult[]> ProposeRoutes(double fromLat, double fromLon, double toLat, double toLon, double maximumWalkingDistanceInMeters)
        {
            // Otto
            var fullOttoJourney = new EnTurJourneyPlanResult[3];

            var ottoRoute = await FindViableOttoRoute(fromLat, fromLon, toLat, toLon, maximumWalkingDistanceInMeters);
            if (ottoRoute != null)
            {
                fullOttoJourney[0] = await _enTurFacade.GetTripPlanner(
                    fromLat,
                    fromLon,
                    Convert.ToDouble(ottoRoute.FromLocation.Latitude),
                    Convert.ToDouble(ottoRoute.FromLocation.Longitude),
                    "walk");

                fullOttoJourney[1] = await _enTurFacade.GetTripPlanner(
                    Convert.ToDouble(ottoRoute.FromLocation.Latitude),
                    Convert.ToDouble(ottoRoute.FromLocation.Longitude),
                    Convert.ToDouble(ottoRoute.ToLocation.Latitude),
                    Convert.ToDouble(ottoRoute.ToLocation.Longitude),
                    "bike");

                fullOttoJourney[2] = await _enTurFacade.GetTripPlanner(
                    Convert.ToDouble(ottoRoute.ToLocation.Latitude),
                    Convert.ToDouble(ottoRoute.ToLocation.Longitude),
                    toLat,
                    toLon,
                    "walk");
            }

            return fullOttoJourney;
            
        }


        public async Task DecideRoute(double fromLat, double fromLon, double toLat, double toLon, double minutesAvailable, string transportMode)
        {
            var season = GetSeason();
            var weather = await GetWeatherCategory(minutesAvailable / 60);
            var dayOfWeek = DateTime.Now.DayOfWeek.ToString().ToLower();

            if (String.IsNullOrEmpty(transportMode))
            {
                transportMode = GetTransportType(weather);
            }

            DateTime timeOfDayDatetime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, DateTime.Now.Hour, DateTime.Now.Minute, 0);
#if !DEBUG
            timeOfDayDatetime = TimeZoneInfo.ConvertTimeFromUtc(timeOfDayDatetime, TimeZoneInfo.FindSystemTimeZoneById("Europe/Stockholm"));
#endif
            var timeOfDay = timeOfDayDatetime.ToString().Substring(11, 5).Remove(2, 1);
        }


        private string GetSeason()
        {
            int month = Int32.Parse(DateTime.Now.Month.ToString());
            if (month > 11 || month < 3)
                return "winter";
            if (month < 6)
                return "spring";
            if (month < 9)
                return "summer";
            if (month < 12)
                return "fall";
            return "unknownmonth";
        }

        private async Task<string> GetWeatherCategory(double hourDuration)
        {
            if (hourDuration > 8)
                hourDuration = 12;
            else if (hourDuration > 3)
                hourDuration = 6;
            else
                hourDuration = 1;

            var weather = await _weatherFacade.GetWeatherForecast((int)hourDuration);

            try
            {


                if (weather.precipitation.precipitationAmount > 0)
                    return "badweather";
                if (weather.windSpeed > 9)
                    return "badweather";
                if (weather.temperature < -15)
                    return "badweather";
                //15 = fog
                if (weather.weatherSymbol.number > 4 && weather.weatherSymbol.number != 15)
                    return "badweather";
                if (weather.weatherSymbol.number > 2)
                    return "neutralweather";
                if (weather.weatherSymbol.number > 0)
                    return "goodweather";
                return "neutralweather";
            }
            catch
            {
                return "neutralweather";
            }
        }
        private string GetTransportType(string weather)
        {
            if (weather == "goodweather" || weather == "neutralweather")
            {
                return "walk";
            }
            else
            {
                return "transit";
            }
        }

        private async Task<OttoRoute> FindViableOttoRoute(double fromLat, double fromLon, double toLat, double toLon, double acceptableWalkLengthInMeters)
        {
            var originStation = await _ottoFacade.FindClosest(fromLat, fromLon);
            var destinationStation = await _ottoFacade.FindClosest(toLat, toLon);

            if (originStation.DistanceInMeter + destinationStation.DistanceInMeter > acceptableWalkLengthInMeters)
            {
                return null;
            }

            return new OttoRoute
            {
                FromLocation = originStation.Location,
                ToLocation = destinationStation.Location
            };
        }
    }
}
