﻿using PointOfInterest.Models;
using PointOfInterest.Facades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using PointOfInterest.Dtos;
using PointOfInterest.Services;
using PointOfInterest.Models.Places;
using MongoDB.Driver;
using PointOfInterest.Mappers;

namespace PointOfInterest.Services.Implementation
{
    public class PlacesService : IPlacesService
    {
        private readonly IPlacesSearchFacade _placesSearchFacade;
        private readonly IDataService _dataService;

        public PlacesService(IPlacesSearchFacade placesSearchFacade, IDataService dataService)
        {
            _placesSearchFacade = placesSearchFacade;
            _dataService = dataService;
        }

        public async Task<List<PoiBaseModel>> GenerateBaseModelsFromNearbySearch(string locationType)
        {
            var result = await _placesSearchFacade.NearbySearch(locationType);
            return result.ToBaseModel(locationType);
        }

        public async Task<int> PopulateDataBaseFromNearbySearch(string locationType)
        {
            var locationsList = await GenerateBaseModelsFromNearbySearch(locationType);

            var numNewDocumentsAdded = 0;
            foreach (PoiBaseModel location in locationsList)
            {
                // Doing upserts sequentially. Due to how the ID number is generated, this may be risky to do in parallel.
                // Anyways, adding new POIs are supposed to be a rare occasion.

                var addedNewDocument = await _dataService.UpsertBasedOnSourceIdAsync(location); 
                if (addedNewDocument)
                {
                    numNewDocumentsAdded++;
                }
                
            }
            return numNewDocumentsAdded; // Number of added (not updated) items
        }

        public async Task<string> UpdateAndDeleteOldEntries(string locationType)
        {
            var numNewItems = await PopulateDataBaseFromNearbySearch(locationType); // Returns number of added items
            var numDeletedItems = await DeleteOldEntries(locationType, "Google"); // Returns number of deleted items

            return $"Successfully updated POIs of type {Convert.ToString(locationType)}. \n" +
                $"{numNewItems} new items were added. \n" +
                $"{numDeletedItems} previously existing items collected from Google Maps were deleted due to being outdated.";

        }

        public async Task<int> GenerateDetailsModels(string locationType)
        {
            var documents = await _dataService.SearchAsync(types: locationType);

            var upsertedCounter = 0;
            foreach (PoiBaseModel document in documents)
            {
                var success = await GenerateAndSaveDetailsOnEatery(document);
                if (success == true)
                {
                    upsertedCounter++;
                }
            }

            return upsertedCounter;
        }

        /// <summary>
        /// Return eateries (cafes or restaurants) in PoiEatery format. If no ID is provided, returns all POIs of the type.
        /// </summary>
        /// <param name="type"></param>
        /// <returns></returns>
        //public async Task<PoiEatery> FindPoiEatery(string type)
        //{

        //    return (await _dataService.SearchAsync(types: type))
        //}

        public async Task<IEnumerable<PoiEatery>> GetDetailedEateries(string type, int? id = null)
        {
            List<PoiBaseModel> baseModel;
            List<EateryDetailsModel> details;
            if (id == null)
            {
                baseModel = await _dataService.SearchAsync(types: type);
                details = await _dataService.GetDetailsModelAsync<EateryDetailsModel>();

            }
            else
            {
                baseModel = await _dataService.SearchAsync(ids: new List<int> { (int)id });
                details = await _dataService.GetDetailsModelAsync<EateryDetailsModel>(ids: new List<int> { (int)id });
            }

            return baseModel.ToPoiEateryDto(details);
        }


        private async Task<bool> GenerateAndSaveDetailsOnEatery(PoiBaseModel baseModel)
        {
            EateryDetailsModel eateryModel = null;

            var successfullyUpserted = false;
            if (baseModel.Types.Contains("cafe") || baseModel.Types.Contains("restaurant"))
            {
                eateryModel = (await _placesSearchFacade.PlaceDetailsSearch(baseModel.SourceId)).ToEateryModel();
                eateryModel.Id = baseModel.Id;

                await _dataService.UpsertDetailsModelAsync(eateryModel);

                successfullyUpserted = true;
            }

            return successfullyUpserted;
        }

        
        private async Task<int> DeleteOldEntries(string locationType, string source = "Google")
        {
            var date = DateTime.UtcNow.Subtract(new TimeSpan(0, 5, 0)); // This function is only called right after updating, so 5 minutes is fine
            return await _dataService.DeleteAsync(types: locationType, sources: source, updatedBefore: date);
        }
    }
}
