﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Security.Authentication;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using MongoDB.Bson;
using MongoDB.Driver;
using PointOfInterest.Configuration;
using PointOfInterest.Dtos;
using PointOfInterest.Mappers;
using PointOfInterest.Models;
using PointOfInterest.Models.Places;

namespace PointOfInterest.Services.Implementation
{
    public class DataService : IDataService
    {
        private readonly DatabaseOptions _configuration;
        private readonly MongoClient _client;
        private readonly IMongoDatabase _database;

        public DataService(IOptions<DatabaseOptions> configuration)
        {
            _configuration = configuration.Value;
            _client = GetClient();
            _database = _client.GetDatabase(_configuration.Database);
        }


        public async Task<List<PoiBaseModel>> SearchAsync(List<int> ids = null, string tags = null,
                                                                 string types = null, string sources = null,
                                                                 DateTime? updatedAfter = null, DateTime? updatedBefore = null)
        {
            var collection = _database.GetCollection<PoiBaseModel>(_configuration.PoiBaseCollection);
            var filter = GetFilter<PoiBaseModel>(ids, tags, types, sources, updatedAfter, updatedBefore);
            var items = await collection.FindAsync<PoiBaseModel>(filter);

            return await items.ToListAsync();
        }

        public async Task<PaginationModel<PoiBase>> SearchPaginatedAsync(List<int> ids = null, string tags = null,
                                                                              string types = null, string sources = null,
                                                                              DateTime? updatedAfter = null,
                                                                              DateTime? updatedBefore = null,
                                                                              int page = 1, int pageSize = 10)
        {
            var collection = _database.GetCollection<PoiBaseModel>(_configuration.PoiBaseCollection);
            var filter = GetFilter<PoiBaseModel>(ids, tags, types, sources, updatedAfter, updatedBefore);
            var totalPages = (int) Math.Ceiling((double) await collection.CountDocumentsAsync(filter) / pageSize);


            var clampedPage = 0;
            IAsyncCursor<PoiBaseModel> items = null;
            if (totalPages > 0)
            {
                clampedPage = Math.Clamp(page, 1, totalPages);

                items = await collection.FindAsync(filter, new FindOptions<PoiBaseModel, PoiBaseModel>
                {
                    Skip = (clampedPage - 1) * pageSize,
                    Limit = Math.Min(pageSize, 50)
                });
            }

            return new PaginationModel<PoiBase>
            {
                CurrentPage = clampedPage,
                PageSize = pageSize,
                TotalPages = totalPages,
                Items = (items == null) ? null : (await items.ToListAsync()).ToPoiBaseDto()
            };
        }

        //public async Task CreateAsync(PoiBaseModel data)
        //{
        //    var collection = _database.GetCollection<PoiBaseModel>(_configuration.PoiBaseCollection);
        //    var idCounterCollection = _database.GetCollection<IdCounterModel>(_configuration.IdCounterCollection);

        //    try
        //    {
        //        var idCounterDocument = await idCounterCollection.FindOneAndUpdateAsync(
        //            doc => doc._id == _configuration.IdCounterDocumentIndex,
        //            Builders<IdCounterModel>.Update.Inc(idcounter => idcounter.counter, 1)
        //            );
        //        data.Id = idCounterDocument.counter;
        //        await collection.InsertOneAsync(data);
        //    }
        //    catch (MongoCommandException ex)
        //    {
        //        throw ex;
        //    }
        //}

        public async Task<bool> UpsertBasedOnSourceIdAsync(PoiBaseModel data)
        {
            var collection = _database.GetCollection<PoiBaseModel>(_configuration.PoiBaseCollection);
            var idCounterCollection = _database.GetCollection<IdCounterModel>(_configuration.IdCounterCollection);

            var existingDocument = await collection.Find(poi => Equals(poi.SourceId, data.SourceId)).FirstOrDefaultAsync();

            bool newDocumentWasAdded = false;

            if (existingDocument == null)
            {
                var idCounterDocument = await idCounterCollection.FindOneAndUpdateAsync(
                    doc => doc._id == _configuration.IdCounterDocumentIndex,
                    Builders<IdCounterModel>.Update.Inc(idcounter => idcounter.counter, 1)
                    );
                data.Id = idCounterDocument.counter;
                newDocumentWasAdded = true;
            }
            else
            {
                data.Id = existingDocument.Id;
                data.Types.AddRange(existingDocument.Types);
                data.Types = data.Types.Distinct().ToList();
            }

            try
            {
                await collection.ReplaceOneAsync(
                    poi => poi.Id == data.Id,
                    data,
                    new ReplaceOptions { IsUpsert = true });
            }
            catch (MongoCommandException ex)
            {
                throw ex;
            }

            return newDocumentWasAdded;
        }

        public async Task UpsertDetailsModelAsync<TDetailsModel>(TDetailsModel data) where TDetailsModel : DetailsAbstractClass
        {
            // Requires an existing collection named correctly, for each details-model.
            var collection = _database.GetCollection<TDetailsModel>(_configuration.DetailsCollectionBase + typeof(TDetailsModel).Name); 

            try
            {
                await collection.ReplaceOneAsync(
                    poi => poi.Id == data.Id,
                    data,
                    new ReplaceOptions { IsUpsert = true });
            }
            catch (MongoCommandException ex)
            {
                throw ex;
            }
        }

        public async Task<List<TDetailsModel>> GetDetailsModelAsync<TDetailsModel>(List<int> ids = null,
                                                                                          string tags = null,
                                                                                          string types = null) where TDetailsModel : DetailsAbstractClass
        {
            var collection = _database.GetCollection<TDetailsModel>(_configuration.DetailsCollectionBase + typeof(TDetailsModel).Name);

            var filter = GetFilter<TDetailsModel>(ids, tags, types);
            var items = await collection.FindAsync<TDetailsModel>(filter);

            return await items.ToListAsync();
        }

        public async Task<int> DeleteAsync(List<int> ids = null, string tags = null,
                                      string types = null, string sources = null,
                                      DateTime? updatedAfter = null, DateTime? updatedBefore = null)
        {
            if (sources == null)
            {
                throw new ArgumentException("Parameter cannot be null", nameof(sources)); // To prevent accidental deletion of all manually inserted items
            }

            var collection = _database.GetCollection<PoiBaseModel>(_configuration.PoiBaseCollection);

            var items = await SearchAsync(ids, tags, types, sources, updatedAfter, updatedBefore);

            var numDeletedItems = 0;
            foreach (PoiBaseModel item in items)
            {
                numDeletedItems++;
                await collection.DeleteOneAsync(poi => poi.Id == item.Id);
            };

            return numDeletedItems;
        }

        private FilterDefinition<TModel> GetFilter<TModel>(List<int> ids = null, string tags = null, string types = null,
                                                         string sources = null, DateTime? updatedAfter = null, DateTime? updatedBefore = null)
        {
            var filters = new List<FilterDefinition<TModel>>();

            if (ids != null)
            {
                filters.Add(Builders<TModel>.Filter.In("_id", ids));
            }

            if (!string.IsNullOrEmpty(tags))
            {
                filters.Add(Builders<TModel>.Filter.AnyIn("tags", tags.Split(",")));
            }

            if (!string.IsNullOrEmpty(types))
            {
                filters.Add(Builders<TModel>.Filter.AnyIn("types", types.Split(",")));
            }

            if (!string.IsNullOrEmpty(sources))
            {
                filters.Add(Builders<TModel>.Filter.In("source", sources.Split(",")));
            }

            if (updatedAfter != null)
            {
                filters.Add(Builders<TModel>.Filter.Gte("lastUpdated", updatedAfter));
            }

            if (updatedBefore != null)
            {
                filters.Add(Builders<TModel>.Filter.Lte("lastUpdated", updatedBefore));
            }

            return Builders<TModel>.Filter.And(filters);
        }

        private MongoClient GetClient()
        {
            var settings = new MongoClientSettings
            {
                Server = new MongoServerAddress(_configuration.Host, 10255),
                UseSsl = true,
                SslSettings = new SslSettings { EnabledSslProtocols = SslProtocols.Tls12 },
                Credentials = new List<MongoCredential>
                {
                    new MongoCredential("SCRAM-SHA-1",
                        new MongoInternalIdentity(_configuration.Database, _configuration.Username),
                        new PasswordEvidence(_configuration.Password))
                }

            };

            return new MongoClient(settings);
        }
    }
}