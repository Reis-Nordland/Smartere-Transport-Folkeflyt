﻿using MongoDB.Driver;
using PointOfInterest.Dtos;
using PointOfInterest.Models;
using PointOfInterest.Models.Places;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace PointOfInterest.Services
{
    public interface IPlacesService
    {
        Task<List<PoiBaseModel>> GenerateBaseModelsFromNearbySearch(string location_type);
        Task<int> PopulateDataBaseFromNearbySearch(string locationType);
        Task<string> UpdateAndDeleteOldEntries(string locationType);
        Task<int> GenerateDetailsModels(string locationType);
        Task<IEnumerable<PoiEatery>> GetDetailedEateries(string type, int? id = null);
    }
}