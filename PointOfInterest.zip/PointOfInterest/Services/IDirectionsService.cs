﻿using PointOfInterest.Facades.EnTur;
using PointOfInterest.Models.Places;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace PointOfInterest.Services
{
    public interface IDirectionsService
    {
        Task DecideRoute(double fromLat, double fromLon, double toLat, double toLon, double minutesAvailable, string transportMode);
        Task<EnTurJourneyPlanResult[]> ProposeRoutes(double fromLat, double fromLon, double toLat, double toLon, double maximumWalkingDistanceInMeters);
    }
}