﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MongoDB.Bson;
using MongoDB.Driver;
using PointOfInterest.Dtos;
using PointOfInterest.Models;
using PointOfInterest.Models.Places;

namespace PointOfInterest.Services
{
    public interface IDataService
    {
        //Task CreateAsync(PoiBaseModel data);
        //Task<PoiBaseModel> GetAsync(int id);
        Task<List<PoiBaseModel>> SearchAsync(List<int> ids = null, string tags = null, string types = null, string sources = null, DateTime? updatedAfter = null, DateTime? updatedBefore = null);
        Task<int> DeleteAsync(List<int> ids = null, string tags = null, string types = null, string sources = null, DateTime? updatedAfter = null, DateTime? updatedBefore = null);
        Task<bool> UpsertBasedOnSourceIdAsync(PoiBaseModel data);
        Task<PaginationModel<PoiBase>> SearchPaginatedAsync(List<int> ids = null, string tags = null, string types = null, string sources = null, DateTime? updatedAfter = null, DateTime? updatedBefore = null, int page = 1, int pageSize = 10);
        Task UpsertDetailsModelAsync<TDetailsModel>(TDetailsModel data) where TDetailsModel : DetailsAbstractClass;
        Task<List<TDetailsModel>> GetDetailsModelAsync<TDetailsModel>(List<int> ids = null, string tags = null, string types = null) where TDetailsModel : DetailsAbstractClass;
    }
}
