﻿using PointOfInterest.Models.Places;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PointOfInterest.Dtos
{
    public class PoiEatery
    {
        public PoiBase Base { get; set; }

        public EateryDetailsModel Details { get; set; }
    }
}
