﻿using PointOfInterest.Models.Places;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PointOfInterest.Dtos
{
    public class PoiBase
    {
        public int id { get; set; }
        public string name { get; set; }
        public CoordinateModel coordinates { get; set; }
        public string address { get; set; }
        public string[] type { get; set; }
    }
}
