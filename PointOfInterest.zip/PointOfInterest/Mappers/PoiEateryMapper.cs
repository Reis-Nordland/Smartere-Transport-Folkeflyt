﻿using PointOfInterest.Dtos;
using PointOfInterest.Models.Places;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PointOfInterest.Mappers
{
    public static class PoiEateryMapper
    {
        public static PoiEatery ToPoiEateryDto(this PoiBaseModel baseModel, EateryDetailsModel details)
        {
            if (details == null)
            {
                return null;
            }

            return new PoiEatery
            {
                Base = baseModel.ToPoiBaseDto(),
                Details = details
            };
        }

        public static IEnumerable<PoiEatery> ToPoiEateryDto(this List<PoiBaseModel> baseModel, List<EateryDetailsModel> details)
        {
            return baseModel.Select(bPoi => bPoi.ToPoiEateryDto(
                details.FirstOrDefault(
                    dPoi => dPoi.Id == bPoi.Id)
                )
            );
        }
    }
}
