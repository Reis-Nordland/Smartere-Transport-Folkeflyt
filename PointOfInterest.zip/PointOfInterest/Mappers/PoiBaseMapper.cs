﻿using PointOfInterest.Dtos;
using PointOfInterest.Models.Places;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PointOfInterest.Mappers
{
    public static class PoiBaseMapper
    {
        public static PoiBase ToPoiBaseDto(this PoiBaseModel model)
        {
            return new PoiBase
            {
                id = model.Id,
                name = model.Name,
                coordinates = model.Coordinates,
                address = model.Address,
                type = model.Types.ToArray()
            };
        }

        public static List<PoiBase> ToPoiBaseDto(this List<PoiBaseModel> modelList)
        {
            return modelList.Select(x => x.ToPoiBaseDto()).ToList();
        }
    }
}
