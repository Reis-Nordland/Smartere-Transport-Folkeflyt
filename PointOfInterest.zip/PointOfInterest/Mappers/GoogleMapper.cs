﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MongoDB.Bson;
using PointOfInterest.Facades.PlacesSearch;
using PointOfInterest.Models;
using PointOfInterest.Models.Places;

namespace PointOfInterest.Mappers
{
    public static class GoogleMapper
    {
        public static PoiBaseModel ToBaseModel(this ResultsDto dto, string type)
        {
            return new PoiBaseModel
            {
                //Id = "test",//ObjectId.GenerateNewId();

                Name = dto.name,
                //baseModel.Description = ;
                Coordinates = new CoordinateModel
                {
                    Latitude = dto.geometry.location.lat,
                    Longitude = dto.geometry.location.lng
                },
                Address = dto.vicinity,
                //baseModel.Cost = ;
                //baseModel.RequiresEquipment = ;
                //baseModel.UdFacilitated = ;
                //baseModel.Difficulty = ;
                //baseModel.Weather = ;
                //baseModel.Timescope = ;
                Images = new[]
                { new ImageModel
                {
                    ImageString = new ImageStringModel
                    {
                        ImageStringType = Convert.ToString(ImageStringTypeEnum.GooglePhotoReference),
                        ImageString = dto.photos?[0].photo_reference
                    },
                    HtmlAttributions = dto.photos?[0].html_attributions,
                    Height = dto.photos?[0].height,
                    Width = dto.photos?[0].width
                }
                },
                //baseModel.Season = ;
                //baseModel.Tags = ;
                Types = new List<string> { type },
                Source = "Google",
                SourceId = dto.place_id,
                LastUpdated = DateTime.UtcNow
            };
        }

        public static List<PoiBaseModel> ToBaseModel(this GoogleNearbySearchDto dto, string type)
        {
            return dto.results.Select(resultsDto => resultsDto.ToBaseModel(type)).ToList();
        }

        public static EateryDetailsModel ToEateryModel(this GooglePlaceDetailsSearchDto dto)
        {
            return new EateryDetailsModel
            {
                OpeningTimes = dto.result?.opening_hours?.ToWeekDayOpeningTimeModel(),
                //model.PriceLevel = dto.result?.price_level
                Rating = dto.result?.rating,
                GoogleUrl = dto.result?.url
            };
        }

        private static WeekDayOpeningTimeModel ToWeekDayOpeningTimeModel(this GooglePlaceDetailsSearchDto.OpeningHoursDto dto)
        {
            return new WeekDayOpeningTimeModel
            {
                // Days go from 0-6, starting on Sunday
                monday = dto.ToOpeningTimeModel(1),
                tuesday = dto.ToOpeningTimeModel(2),
                wednesday = dto.ToOpeningTimeModel(3),
                thursday = dto.ToOpeningTimeModel(4),
                friday = dto.ToOpeningTimeModel(5),
                saturday = dto.ToOpeningTimeModel(6),
                sunday = dto.ToOpeningTimeModel(0)
            };
        }

        private static OpeningTimeModel ToOpeningTimeModel(this GooglePlaceDetailsSearchDto.OpeningHoursDto dto, int dayNumber)
        {
            return new OpeningTimeModel
            {
                open = dto.periods?.FirstOrDefault(x => x.open.day == dayNumber)?.open?.time,
                closed = dto.periods?.FirstOrDefault(x => x.open.day == dayNumber)?.close?.time
            };
        }
    }
}

