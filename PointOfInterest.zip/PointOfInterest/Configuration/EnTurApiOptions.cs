﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PointOfInterest.Configuration
{
    public class EnTurApiOptions
    {
        public string BaseUri { get; set; }
        public string ClientName { get; set; }
    }
}
