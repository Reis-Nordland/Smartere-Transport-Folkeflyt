﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PointOfInterest.Models
{
    public class IdCounterModel
    {
        public string _id { get; set; }
        public int counter { get; set; }
    }
}
