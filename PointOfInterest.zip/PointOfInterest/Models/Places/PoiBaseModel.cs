﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using Newtonsoft.Json;
using PointOfInterest.Models;

namespace PointOfInterest.Models.Places
{
    public class PoiBaseModel
    {
        //[JsonPropertyAttribute("_id")]
        //[BsonRepresentation(BsonType.ObjectId)]
        //public ObjectId _Id { get; set; }

        [BsonElement("_id")]
        public int Id { get; set; }

        [BsonElement("name")]
        public string Name { get; set; }

        [BsonElement("description")]
        public string Description { get; set; }

        [BsonElement("coordinates")]
        public CoordinateModel Coordinates { get; set; }

        [BsonElement("address")]
        public string Address { get; set; }

        [BsonElement("cost")]
        public double? Cost { get; set; }

        [BsonElement("requiresEquipment")]
        public bool RequiresEquipment { get; set; }  = false;

        [BsonElement("udFacilitated")]
        public bool UdFacilitated { get; set; } = false;

        [BsonElement("difficulty")]
        public DifficultyEnum Difficulty { get; set; } = DifficultyEnum.unknown;

        [BsonElement("weather")]
        public string[] Weather { get; set; }

        [BsonElement("timeScope")]
        public double? Timescope { get; set; }

        [BsonElement("imageUrl")]
        public ImageModel[] Images { get; set; }

        /// <summary>
        /// Defines what seasons this POI is relevant for.
        /// One of: winter, spring, summer, fall
        /// </summary>
        [BsonElement("season")]
        public SeasonEnum[] Season { get; set; }

        [BsonElement("tags")]
        public string[] Tags { get; set; }

        [BsonElement("types")]
        public List<string> Types { get; set; }

        [BsonElement("source")]
        public string Source { get; set; }

        [BsonElement("sourceId")]
        public string SourceId { get; set; }

        [BsonElement("lastUpdated")]
        public DateTime LastUpdated { get; set; }
    }
    public class ImageModel
    {
        /// <summary>
        /// Defines what the ImageString property describes.
        /// Currently: Wether it is a Google Photo reference for use in Place Photos API, or a regular url.
        /// </summary>
        [BsonElement("imageString")]
        public ImageStringModel ImageString { get; set; }

        [BsonElement("htmlAttributions")]
        public string[] HtmlAttributions { get; set; }

        [BsonElement("height")]
        public int? Height { get; set; }

        [BsonElement("width")]
        public int? Width { get; set; }

    }

    public class ImageStringModel
    {
        [BsonElement("imageStringType")]
        public string ImageStringType { get; set; }

        /// <summary>
        /// A string corresponding to the ImageStringType.
        /// </summary>
        [BsonElement("imageString")]
        public string ImageString { get; set; }

    }
}