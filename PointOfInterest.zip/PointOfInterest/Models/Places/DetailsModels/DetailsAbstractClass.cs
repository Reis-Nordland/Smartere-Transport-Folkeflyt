﻿using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PointOfInterest.Models.Places
{
    public abstract class DetailsAbstractClass
    {
        [BsonElement("_id")]
        public int Id { get; set; }
    }
}
