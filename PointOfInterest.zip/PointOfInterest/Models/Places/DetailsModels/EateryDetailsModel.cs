﻿using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PointOfInterest.Models.Places
{
    public class EateryDetailsModel : DetailsAbstractClass
    {
        //[BsonElement("_id")]
        //new public int Id { get; set; }

        [BsonElement("openingTimes")]
        public WeekDayOpeningTimeModel OpeningTimes { get; set; }

        /// <summary>
        /// The price level of the place, on a scale of 0 to 4.
        /// Price levels are interpreted as follows:
        /// 0 — Free
        /// 1 — Inexpensive
        /// 2 — Moderate
        /// 3 — Expensive
        /// 4 — Very Expensive
        /// </summary>
        [BsonElement("priceLevel")]
        public int? PriceLevel { get; set; }

        /// <summary>
        /// The place's rating, from 1.0 to 5.0, based on aggregated (Google) user reviews.
        /// </summary>
        [BsonElement("rating")]
        public double? Rating { get; set; }

        /// <summary>
        /// Contains the URL of the official Google page for this place. This will be the Google-owned page that contains the best available information about the place. 
        /// Applications must link to or embed this page on any screen that shows detailed results about the place to the user.
        /// </summary>
        [BsonElement("googleUrl")]
        public string GoogleUrl { get; set; }
    }

    public class WeekDayOpeningTimeModel
    {
        public OpeningTimeModel monday { get; set; }
        public OpeningTimeModel tuesday { get; set; }
        public OpeningTimeModel wednesday { get; set; }
        public OpeningTimeModel thursday { get; set; }
        public OpeningTimeModel friday { get; set; }
        public OpeningTimeModel saturday { get; set; }
        public OpeningTimeModel sunday { get; set; }
    }

    public class OpeningTimeModel
    {
        /// <summary>
        /// Opening time, given in local time
        /// </summary>
        public string open { get; set; }

        /// <summary>
        /// Closing time, given in local time
        /// </summary>
        public string closed { get; set; }
    }



}
