﻿namespace PointOfInterest.Models
{
    public enum ImageStringTypeEnum
    {
        GooglePhotoReference,
        Url
    }
}