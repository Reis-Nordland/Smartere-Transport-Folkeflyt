﻿namespace PointOfInterest.Models
{
    public enum SeasonEnum
    {
        spring,
        summer,
        fall,
        winter  
    }
}