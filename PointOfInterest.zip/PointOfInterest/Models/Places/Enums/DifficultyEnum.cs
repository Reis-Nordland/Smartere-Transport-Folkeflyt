﻿namespace PointOfInterest.Models
{
    public enum DifficultyEnum
    {
        unknown,
        easy,
        medium,
        hard
    }
}