﻿using MongoDB.Bson.Serialization.Attributes;

namespace PointOfInterest.Models.Places
{
    public class CoordinateModel
    {
        [BsonElement("latitude")]
        public double Latitude { get; set; }
        [BsonElement("longitude")]
        public double Longitude { get; set; }
    }
}
