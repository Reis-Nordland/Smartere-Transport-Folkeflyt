﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PointOfInterest.Models
{
    public class FilterModel
    {
        /// <summary>
        /// Comma separated list of type names
        /// </summary>
        public string Type { get; set; }

        ///// <summary>
        ///// Comma separated list of coordinates
        ///// Coordinates are given in the following format:
        ///// <example>Latitude|Longitude,Latitude|Longitude</example>
        ///// </summary>
        ///// <remarks>coordinates=123|456,789|123</remarks>
        //public string Coordinates { get; set; }

        /// <summary>
        /// Comma separated list of ids
        /// </summary>
        public string Ids { get; set; }
    }
}
