﻿using System;

namespace PointOfInterest.Models.Directions
{
    public class TransitDetailModel
    {
        public DateTime DepartureTime { get; set; }
        public DateTime ArrivalTime { get; set; }
        public int NumStops { get; set; }
        public string Line { get; set; }
    }
}