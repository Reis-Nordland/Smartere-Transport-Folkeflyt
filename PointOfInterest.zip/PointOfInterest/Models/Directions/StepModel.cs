﻿using System;

namespace PointOfInterest.Models.Directions
{
    public class StepModel
    {
        public int Distance { get; set; }
        public TimeSpan Duration { get; set; }
        public TransitDetailModel TransitDetails { get; set; }
        public string TravelMode { get; set; }
        public StepModel[] Steps { get; set; }

    }
}