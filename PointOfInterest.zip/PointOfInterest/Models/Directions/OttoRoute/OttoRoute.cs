﻿using PointOfInterest.Facades.Otto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PointOfInterest.Models.Directions
{
    public class OttoRoute
    {
        public LocationsModel FromLocation { get; set; }
        public LocationsModel ToLocation { get; set; }
    }
}
