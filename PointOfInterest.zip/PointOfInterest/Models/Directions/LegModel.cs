﻿using PointOfInterest.Models.Places;
using System;

namespace PointOfInterest.Models.Directions
{
    public class LegModel
    {
        public StepModel[] Steps { get; set; }
        public CoordinateModel DepartureCoordinates { get; set; }
        public CoordinateModel ArrivalCoordinates { get; set; }
        public TimeSpan Duration { get; set; }
        public DateTime DepartureTime { get; set; }
        public DateTime ArrivalTime { get; set; }
    }
}