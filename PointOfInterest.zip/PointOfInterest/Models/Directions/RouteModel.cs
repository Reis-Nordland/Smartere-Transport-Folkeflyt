﻿using System;

namespace PointOfInterest.Models.Directions
{
    public class RouteModel
    {
        public LegModel[] Legs { get; set; }
        public TimeSpan Duration { get; set;}
    }
}