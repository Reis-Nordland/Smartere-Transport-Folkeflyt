﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PointOfInterest.Models.Directions
{
    public class DirectionsModel
    {
        public RouteModel[] Routes { get; set; }
    }
}
