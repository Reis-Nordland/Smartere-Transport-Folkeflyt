﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using PointOfInterest.Configuration;
using PointOfInterest.Dtos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;

namespace PointOfInterest.Facades.Weather
{
    public class WeatherFacade : IWeatherFacade
    {

        private readonly FolkeflytApiOptions _folkeflytApiOptions;
        private readonly IHttpClientFactory _clientFactory;

        public WeatherFacade(IOptions<FolkeflytApiOptions> folkeflytApiOptions, IHttpClientFactory clientFactory)
        {
            _folkeflytApiOptions = folkeflytApiOptions.Value;
            _clientFactory = clientFactory;
        }

        public async Task<WeatherForecastDto> GetWeatherForecast(int hourDuration)
        {
            var httpClient = _clientFactory.CreateClient();
            string baseUrl = _folkeflytApiOptions.WeatherForecastUrl;
            string apiUrl = baseUrl + "?hourDuration=" + hourDuration;

            httpClient.DefaultRequestHeaders.Add("Ocp-Apim-Subscription-Key", _folkeflytApiOptions.ApiKey);// = new AuthenticationHeaderValue("Ocp-Apim-Subscription-Key", "cbdfb5b8cf6845afa89eabf921b8a9ed"); // _configuration["WeatherForecastSubscriptionKey"]);

            var response = await httpClient.GetAsync(apiUrl);
            var content = await response.Content.ReadAsStringAsync();

            return JsonConvert.DeserializeObject<WeatherForecastDto>(content);
        }

    }
}
