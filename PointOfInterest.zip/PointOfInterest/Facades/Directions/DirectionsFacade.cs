﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using PointOfInterest.Dtos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace PointOfInterest.Facades.Directions
{
    public class DirectionsFacade : IDirectionsFacade
    {
        private readonly IConfiguration _configuration;
        private readonly IHttpClientFactory _clientFactory;

        public DirectionsFacade(IConfiguration configuration, IHttpClientFactory clientFactory)
        {
            _configuration = configuration;
            _clientFactory = clientFactory;
        }

        public async Task<GoogleDirectionsDto> GetDirections(double fromLat, double fromLon, double toLat, double toLon, string transportMode = "transit")
        {
            // transport mode must be driving, walking, bicycling or transit
            var httpClient = _clientFactory.CreateClient();
            var baseUri = _configuration.GetValue<string>("GoogleMapsApi:DirectionsBaseUri");
            var key = _configuration.GetValue<string>("GoogleMapsApi:ApiKey");
            var parameters = $"origin={fromLat},{fromLon}&destination={toLat},{toLon}&mode={transportMode}&key={key}";


            var response = await httpClient.GetAsync(baseUri + "?" + parameters);
            var content = await response.Content.ReadAsStringAsync();

            return JsonConvert.DeserializeObject<GoogleDirectionsDto>(content);
        }
    }
}
