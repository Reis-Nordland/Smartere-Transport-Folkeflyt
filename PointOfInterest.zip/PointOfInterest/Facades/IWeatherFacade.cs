﻿using PointOfInterest.Facades.Weather;
using System.Threading.Tasks;

namespace PointOfInterest.Facades
{
    public interface IWeatherFacade
    {
        Task<WeatherForecastDto> GetWeatherForecast(int hourDuration);
    }
}