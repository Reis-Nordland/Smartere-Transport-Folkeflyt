﻿using System;
using Newtonsoft.Json;

namespace PointOfInterest.Facades.Otto
{
    public class LocationsModel
    {
        [JsonProperty("locationId")]
        public int LocationId { get; set; }

        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("address")]
        public string Address { get; set; }

        [JsonProperty("latitude")]
        public string Latitude { get; set; }

        [JsonProperty("longitude")]
        public string Longitude { get; set; }

        [JsonProperty("car")]
        public string Car { get; set; }

        [JsonProperty("bike")]
        public string Bike { get; set; }

        [JsonProperty("scooter")]
        public string Scooter { get; set; }

        [JsonProperty("lockedGarage")]
        public bool LockedGarage { get; set; }

        [JsonProperty("favourite")]
        public bool Favourite { get; set; }
    }
}
