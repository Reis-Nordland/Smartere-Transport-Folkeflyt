﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PointOfInterest.Facades.Otto
{
    public class ClosestLocationInfoModel
    {
        public LocationsModel Location { get; set; }
        public double DistanceInMeter { get; set; }
    }
}
