﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using PointOfInterest.Configuration;
using PointOfInterest.Models.Places;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace PointOfInterest.Facades.Otto
{
    public class OttoFacade : IOttoFacade
    {
        private readonly FolkeflytApiOptions _folkeflytApiOptions;
        private readonly IHttpClientFactory _clientFactory;

        public OttoFacade(IOptions<FolkeflytApiOptions> folkeflytApiOptions, IHttpClientFactory clientFactory)
        {
            _folkeflytApiOptions = folkeflytApiOptions.Value;
            _clientFactory = clientFactory;
        }

        public async Task<ClosestLocationInfoModel> FindClosest(double lat, double lon)
        {
            var httpClient = _clientFactory.CreateClient();
            string baseUrl = _folkeflytApiOptions.OttoBaseUrl;
            string requestUrl = baseUrl + $"/FindClosest/{lat}&{lon}";

            

            httpClient.DefaultRequestHeaders.Add("Ocp-Apim-Subscription-Key", _folkeflytApiOptions.ApiKey);

            var response = await httpClient.GetAsync(requestUrl);
            var content = await response.Content.ReadAsStringAsync();

            return JsonConvert.DeserializeObject<ClosestLocationInfoModel>(content);
        }


    }
}
