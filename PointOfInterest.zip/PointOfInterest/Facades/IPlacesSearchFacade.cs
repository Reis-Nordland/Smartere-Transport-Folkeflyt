﻿using System;
using System.Threading.Tasks;
using PointOfInterest.Dtos;
using PointOfInterest.Facades.PlacesSearch;

namespace PointOfInterest.Facades
{
    public interface IPlacesSearchFacade
	{
        Task<GoogleNearbySearchDto> NearbySearch(string location_type, double lat = 67.280403637657145, double lon = 14.387173516453352, int radius = 1300);
        Task<GooglePlaceDetailsSearchDto> PlaceDetailsSearch(string placeId);
    }
}
