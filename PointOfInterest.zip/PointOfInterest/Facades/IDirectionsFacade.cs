﻿using PointOfInterest.Dtos;
using PointOfInterest.Facades.Directions;
using System.Threading.Tasks;

namespace PointOfInterest.Facades
{
    public interface IDirectionsFacade
    {
        Task<GoogleDirectionsDto> GetDirections(double fromLat, double fromLon, double toLat, double toLon, string transportMode = "transit");
    }
}