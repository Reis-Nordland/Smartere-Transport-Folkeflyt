﻿namespace PointOfInterest.Facades.EnTur
{
    public class EnTurLegs
    {
        public string Mode { get; set; }
        public double Distance { get; set; }
        public EnTurLine Line { get; set; }
        public EnTurPointsOnLink PointsOnLink { get; set; }
    }
}