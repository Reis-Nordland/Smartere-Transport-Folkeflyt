﻿namespace PointOfInterest.Facades.EnTur
{
    public class EnTurJourneyPlanResult
    {
        public EnTurTrip Trip { get; set; }
    }
}