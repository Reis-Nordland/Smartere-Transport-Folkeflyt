﻿using System;

namespace PointOfInterest.Facades.EnTur
{
    public class EnTurTripPattern
    {
        public DateTime StartTime { get; set; }
        public double Duration { get; set; }
        public double WalkDistance { get; set; }
        public EnTurLegs[] Legs { get; set; }
    }
}