﻿namespace PointOfInterest.Facades.EnTur
{
    public class EnTurPointsOnLink
    {
        public string Points { get; set; }
        public double Length { get; set; }
    }
}