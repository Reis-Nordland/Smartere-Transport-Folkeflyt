﻿using GraphQL;
using GraphQL.Client.Http;
using GraphQL.Client.Serializer.Newtonsoft;
using Microsoft.Extensions.Options;
using Newtonsoft.Json.Linq;
using PointOfInterest.Configuration;
using PointOfInterest.Facades.EnTur;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PointOfInterest.Facades.Entur
{
    public class EnTurFacade : IEnTurFacade
    {
        private readonly EnTurApiOptions _apiOptions;

        public EnTurFacade(IOptions<EnTurApiOptions> apiOptions)
        {
            _apiOptions = apiOptions.Value;
        }

        public async Task<EnTurJourneyPlanResult> GetTripPlanner(double fromLat, double fromLong, double toLat, double toLong, string transportType)
        {
            var graphQLClient = new GraphQLHttpClient(_apiOptions.BaseUri, new NewtonsoftJsonSerializer());
            graphQLClient.HttpClient.DefaultRequestHeaders.Add("ET-Client-Name", _apiOptions.ClientName);

            var enturTransportMode = TransportTypeToEnturModeMapper.GetEnturMode(transportType);

            var request = new GraphQLRequest
            {
                Query = @"{
  trip(
    from: {
    
    coordinates: {
      latitude: " + fromLat.ToString().Replace(',', '.') + @"
      longitude: " + fromLong.ToString().Replace(',', '.') + @"
    }}

    to: {
      
      coordinates: {
      latitude: " + toLat.ToString().Replace(',', '.') + @"
      longitude: " + toLong.ToString().Replace(',', '.') + @"
    }
    }
    numTripPatterns: 3
    minimumTransferTime: 180
    walkSpeed: 1.3
    wheelchair: false
    arriveBy: false
    modes: " + enturTransportMode + @"
  )

#### Requested fields
  {
    tripPatterns {
      startTime
      duration
      walkDistance

          legs {
          
            mode
            distance
            line {
              id
              publicCode
            }
            pointsOnLink {
              points
              length
            }
          }
      
    }
  }
}"
            };


            var response = await graphQLClient.SendQueryAsync<EnTurJourneyPlanResult>(request);
            //dynamic travelPlan = JObject.Parse(response.Data.ToString());
            return response.Data;
        }

        internal static class TransportTypeToEnturModeMapper
        {

            public static string GetEnturMode(string transportType)
            {
                switch (transportType)
                {
                    case "walk":
                        return "foot";
                    case "publictransport":
                        return "[bus, foot]";
                    case "bike":
                        return "[foot, bicycle]";
                    default:
                        return "foot";
                }
            }
        }
    }
}


