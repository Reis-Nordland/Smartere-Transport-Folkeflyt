﻿using System.Collections.Generic;

namespace PointOfInterest.Facades.PlacesSearch
{
    public class GooglePlaceDetailsSearchDto
    {
        public List<object> html_attributions { get; set; }
        public ResultDto result { get; set; }
        public string status { get; set; }



        public class AddressComponentDto
        {
            public string long_name { get; set; }
            public string short_name { get; set; }
            public List<string> types { get; set; }
        }

        public class LocationDto
        {
            public double lat { get; set; }
            public double lng { get; set; }
        }

        public class NortheastDto
        {
            public double lat { get; set; }
            public double lng { get; set; }
        }

        public class SouthwestDto
        {
            public double lat { get; set; }
            public double lng { get; set; }
        }

        public class ViewportDto
        {
            public NortheastDto northeast { get; set; }
            public SouthwestDto southwest { get; set; }
        }

        public class GeometryDto
        {
            public LocationDto location { get; set; }
            public ViewportDto viewport { get; set; }
        }

        public class CloseDto
        {
            public int day { get; set; }
            public string time { get; set; }
        }

        public class OpenDto
        {
            public int day { get; set; }
            public string time { get; set; }
        }

        public class PeriodDto
        {
            public CloseDto close { get; set; }
            public OpenDto open { get; set; }
        }

        public class OpeningHoursDto
        {
            public bool open_now { get; set; }
            public List<PeriodDto> periods { get; set; }
            public List<string> weekday_text { get; set; }
        }

        public class PhotoDto
        {
            public int height { get; set; }
            public List<string> html_attributions { get; set; }
            public string photo_reference { get; set; }
            public int width { get; set; }
        }

        public class PlusCodeDto
        {
            public string compound_code { get; set; }
            public string global_code { get; set; }
        }

        public class ReviewDto
        {
            public string author_name { get; set; }
            public string author_url { get; set; }
            public string language { get; set; }
            public string profile_photo_url { get; set; }
            public int rating { get; set; }
            public string relative_time_description { get; set; }
            public string text { get; set; }
            public int time { get; set; }
        }

        public class ResultDto
        {
            public List<AddressComponentDto> address_components { get; set; }
            public string adr_address { get; set; }
            public string business_status { get; set; }
            public string formatted_address { get; set; }
            public string formatted_phone_number { get; set; }
            public GeometryDto geometry { get; set; }
            public string icon { get; set; }
            public string international_phone_number { get; set; }
            public string name { get; set; }
            public OpeningHoursDto opening_hours { get; set; }
            public List<PhotoDto> photos { get; set; }
            public string place_id { get; set; }
            public PlusCodeDto plus_code { get; set; }
            public double rating { get; set; }
            public string reference { get; set; }
            public List<ReviewDto> reviews { get; set; }
            public List<string> types { get; set; }
            public string url { get; set; }
            public int user_ratings_total { get; set; }
            public int utc_offset { get; set; }
            public string vicinity { get; set; }
            public string website { get; set; }
        }
    }
}