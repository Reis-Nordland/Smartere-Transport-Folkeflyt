﻿using Newtonsoft.Json;

namespace PointOfInterest.Facades.PlacesSearch
{
    public class GoogleNearbySearchDto
    { 
        //public string[] html_attributions { get; set; }
        public ResultsDto[] results { get; set; }
        public string status { get; set; }
    }

    public class ResultsDto
    {
        public string business_status { get; set; }

        public GeometryDto geometry { get; set; }

        public string icon { get; set; }

        //public string id { get; set; }
        
        public string name { get; set; }

        public OpeningHoursDto opening_hours { get; set; }
        
        public PhotoDto[] photos { get; set; }
        
        public string place_id { get; set; }
        
        public PlusCodeDto plus_code { get; set; }
        
        public int price_level { get; set; }
        
        public double rating { get; set; }
        
        public string reference { get; set; }
        
        public string[] types { get; set; }
        
        public int user_ratings_total { get; set; }
        
        public string vicinity { get; set; }
    }

    public class GeometryDto
    {
        public CoordinatesDto location { get; set; }
        public ViewportDto viewport { get; set; }
    }
    public class CoordinatesDto
    {
        public double lat { get; set; }
        public double lng { get; set; }
    }

    public class ViewportDto
    {
        public CoordinatesDto northeast { get; set; }
        public CoordinatesDto southwest { get; set; }
    }
    public class PhotoDto
    {
        public int height { get; set; }
        public string[] html_attributions { get; set; }
        public string photo_reference { get; set; }
        public int width { get; set; }
    }

    public class OpeningHoursDto
    {
        public bool open_now { get; set; }
    }

    public class PlusCodeDto
    {
        public string compound_code { get; set; }
        public string global_code { get; set; }
    }
}