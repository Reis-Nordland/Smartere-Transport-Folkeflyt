﻿using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using PointOfInterest.Dtos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;


namespace PointOfInterest.Facades.PlacesSearch
{
    public class PlacesSearchFacade : IPlacesSearchFacade
    {
        private readonly IConfiguration _configuration;
        private readonly IHttpClientFactory _clientFactory;

        public PlacesSearchFacade(IConfiguration configuration, IHttpClientFactory clientFactory)
        {
            _configuration = configuration;
            _clientFactory = clientFactory;
        }

        //<summary>
        //Search for a location type in a circle around the given coordinates. The default values cover the entirety of Bodø city center.
        //</summary>
        public async Task<GoogleNearbySearchDto> NearbySearch(string location_type, double lat = 67.28040363765714, double lon = 14.387173516453352, int radius = 1300)
        {
            var httpClient = _clientFactory.CreateClient();
            var baseUri = _configuration.GetValue<string>("GoogleMapsApi:NearbySearchBaseUri");
            var key = _configuration.GetValue<string>("GoogleMapsApi:ApiKey");
            var parameters = $"location={lat},{lon}&radius={radius}&language=no&type={location_type}&key={key}";


            var response = await httpClient.GetAsync(baseUri + "?" + parameters);
            var content = await response.Content.ReadAsStringAsync();

            return JsonConvert.DeserializeObject<GoogleNearbySearchDto>(content);
        }

        public async Task<GooglePlaceDetailsSearchDto> PlaceDetailsSearch(string placeId)
        {
            var httpClient = _clientFactory.CreateClient();
            var baseUri = _configuration.GetValue<string>("GoogleMapsApi:PlaceDetailsBaseUri");
            var key = _configuration.GetValue<string>("GoogleMapsApi:ApiKey");
            var parameters = $"place_id={placeId}&key={key}";

            var response = await httpClient.GetAsync(baseUri + "?" + parameters);
            var content = await response.Content.ReadAsStringAsync();

            return JsonConvert.DeserializeObject<GooglePlaceDetailsSearchDto>(content);
        }
    }
}
