﻿using PointOfInterest.Facades.Otto;
using PointOfInterest.Models.Places;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace PointOfInterest.Facades
{
    public interface IOttoFacade
    {
        Task<ClosestLocationInfoModel> FindClosest(double lat, double lon);
    }
}