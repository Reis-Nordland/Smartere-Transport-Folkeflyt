﻿using PointOfInterest.Facades.EnTur;
using System.Threading.Tasks;

namespace PointOfInterest.Facades
{
    public interface IEnTurFacade
    {
        Task<EnTurJourneyPlanResult> GetTripPlanner(double fromLat, double fromLong, double toLat, double toLong, string transportType);
    }
}