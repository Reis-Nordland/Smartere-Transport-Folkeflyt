﻿using GoogleApi.Entities.Places.Search.NearBy.Response;
using Microsoft.AspNetCore.Mvc;
using MongoDB.Driver;
using PointOfInterest.Dtos;
using PointOfInterest.Facades;
using PointOfInterest.Facades.Directions;
using PointOfInterest.Facades.PlacesSearch;
using PointOfInterest.Models.Places;
using PointOfInterest.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;

namespace PointOfInterest.Controllers
{
    [ApiController]
    [Route("MapsLocations")]
    public class GoogleMapsController : ControllerBase
    {
        private readonly IPlacesSearchFacade _placesSearchFacade;
        private readonly IDirectionsFacade _directionsFacade;
        private readonly IPlacesService _placesService;

        public GoogleMapsController(IPlacesSearchFacade placesSearchFacade, IDirectionsFacade directionsFacade, IPlacesService placesService)
        {
            _placesSearchFacade = placesSearchFacade;
            _directionsFacade = directionsFacade;
            _placesService = placesService;
        }

        /// <summary>
        /// Search for a location type in a radius around the given coordinates.
        /// </summary>
        /// <remarks>
        /// Search for a location type in a radius around the given coordinates. The default values cover the entirety of Bodø city center.
        /// </remarks>
        //[Route("NearbySearch")]
        //[HttpGet]
        //public async Task<GoogleNearbySearchDto> NearbySearch(LocationTypeEnum locationType, double lat = 67.280403637657145, double lon = 14.387173516453352, int radius = 1300)
        //{
        //    var type = Convert.ToString(locationType);
        //    return await _placesSearchFacade.NearbySearch(type, lat, lon, radius);
        //}

        //[HttpGet("SaveDetails")]
        //public async Task<string> GetEateryDetails(LocationTypeEnum locationType)
        //{
        //    var numUpsertions = await _placesService.GenerateDetailsModels(Convert.ToString(locationType));
        //    return $"{numUpsertions} POIs of type {Convert.ToString(locationType)} had their details saved.";
        //}

        /// <summary>
        /// Find a route from A to B
        /// </summary>
        /// <remarks>
        /// Get directions from a start coordinate to an end coordinate using Google Maps API in the background
        ///// </remarks>
        //[Route("Directions")]
        //[HttpGet]
        //public async Task<GoogleDirectionsDto> GetDirections(double fromLat, double fromLon, double toLat, double toLon, string transportMode = "transit")
        //{
        //    return await _directionsFacade.GetDirections(fromLat, fromLon, toLat, toLon, transportMode);
        //}

        ///// <summary>
        ///// Update database entries
        ///// </summary>
        ///// <remarks>
        ///// Get POIs from Google Maps and add new entries to the database, update existing ones and delete entries 
        ///// that were originally collected from Google Maps but are no longer present there.
        ///// </remarks>
        //[HttpPost("UpdateDatabaseEntries")]
        //public async Task<string> UpdateDatabase(LocationTypeEnum locationType)
        //{
        //    return await _placesService.UpdateAndDeleteOldEntries(Convert.ToString(locationType));
        //}
    }
}
