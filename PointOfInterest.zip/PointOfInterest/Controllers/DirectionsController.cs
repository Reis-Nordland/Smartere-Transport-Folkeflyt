﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PointOfInterest.Controllers.InputEnums;
using PointOfInterest.Facades;
using PointOfInterest.Facades.EnTur;
using PointOfInterest.Facades.Otto;
using PointOfInterest.Models.Places;
using PointOfInterest.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PointOfInterest.Controllers
{
    [EnableCors("MyPolicy")]
    [Route("api/[controller]")]
    [ApiController]
    public class DirectionsController : ControllerBase
    {
        private readonly IDirectionsService _directionsService;
        private readonly IEnTurFacade _enTurFacade;
        private readonly IOttoFacade _ottoFacade;

        public DirectionsController(IDirectionsService directionsService, IEnTurFacade enTurFacade, IOttoFacade ottoFacade)
        {
            _directionsService = directionsService;
            _enTurFacade = enTurFacade;
            _ottoFacade = ottoFacade;
        }

        /// <summary>
        /// Get the optimal route from A to B given the transport mode and minutes available
        /// </summary>
        /// <remarks>
        /// This operation decides the optimal route from A to B given the transport mode and minutes available using the EnTur API in the background
        /// </remarks>
        [HttpGet]
        public async Task<EnTurJourneyPlanResult> RouteFinder(
            //double fromLat = 67.27201106674154,
            //double fromLon = 14.351895205688761,
            //double toLat = 67.28863567665056,
            //double toLon = 14.39420973532621,
            //TransportTypeEnum transportType = TransportTypeEnum.walk)
            double fromLat = 67.272768,
            double fromLon= 14.367313, 
            double toLat = 67.280784,
            double toLon = 14.371899,
            TransportTypeEnum transportType = TransportTypeEnum.publictransport)
        {
            return await _enTurFacade.GetTripPlanner(fromLat, fromLon, toLat, toLon, Convert.ToString(transportType));
        }

        /// <summary>
        /// Find Otto stations nearby
        /// </summary>
        /// <remarks>
        /// Finds the coordinates of all nearby (within specified radius) Otto stations
        /// </remarks>
        [HttpGet("ClosestOtto")]
        public async Task<ClosestLocationInfoModel> OttoFinder(double lat = 67.27201106674154, double lon = 14.351895205688761, double meterDistance = 1000)
        {
            return await _ottoFacade.FindClosest(lat, lon);
        }



        /// <summary>
        /// Otto wayfinder
        /// </summary>
        /// <remarks>
        /// Finds the closest Otto stations to go from/to, and shows directions for the whole journey
        /// </remarks>
        [HttpGet("FindOttoRoute")]
        public async Task<EnTurJourneyPlanResult[]> OttoJourney(double fromLat = 67.27201106674154, double fromLon = 14.351895205688761, double toLat = 67.28863567665056, double toLon = 14.39420973532621, double maxWalkDistance = 10000000)
        {
            return await _directionsService.ProposeRoutes(fromLat, fromLon, toLat, toLon, maxWalkDistance);
        }


        // This uses google maps, which does not have collective transport
        //[HttpGet]
        //public async Task DecideRoute(double fromLat, double fromLon, double toLat, double toLon, double minutesAvailable = 180, string transportMode = "transit")
        //{
        //    await _directionsService.DecideRoute(fromLat, fromLon, toLat, toLon, minutesAvailable, transportMode);
        //}

    }
}
