﻿using Newtonsoft.Json.Converters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace PointOfInterest.Controllers
{
    [JsonConverter(typeof(StringEnumConverter))]
    public enum LocationTypeEnum
    {
        [EnumMember(Value = "cafe")]
        cafe,
        [EnumMember(Value = "airport")]
        airport,
        [EnumMember(Value = "library")]
        library,
        [EnumMember(Value = "museum")]
        museum,
        [EnumMember(Value = "restaurant")]
        restaurant,
        [EnumMember(Value = "tourist_attraction")]
        tourist_attraction

        //amusement_park,
        //aquarium,
        //art_gallery,
        //atm,
        //bakery,
        //bank,
        //bar,
        //beauty_salon,
        //book_store,
        //bowling_alley,
        //bus_station,
        //campground,
        //car_rental
        //church
        //city_hall
        //clothing_store
        //convenience_store
        //department_store
        //hair_care
        //lodging
        //meal_takeaway
        //mosque
        //movie_theater
        //night_club
        //park
        //pharmacy
        //post_office
        //shoe_store
        //shopping_mall
        //spa
        //stadium
        //storage
        //store
        //supermarket
        //synagogue
        //taxi_stand
        //train_station
        //transit_station
        //university

    }
}
