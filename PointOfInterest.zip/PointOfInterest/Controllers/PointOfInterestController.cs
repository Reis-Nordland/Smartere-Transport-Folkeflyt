﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using PointOfInterest.Dtos;
using PointOfInterest.Models;
using PointOfInterest.Models.Places;
using PointOfInterest.Services;

namespace PointOfInterest.Controllers
{
    [ApiController]
    [Route("poi")]
    public class PointOfInterestController : ControllerBase
    {
        private readonly ILogger<PointOfInterestController> _logger;
        private readonly IDataService _dataService;
        private readonly IPlacesService _placesService;

        public PointOfInterestController(ILogger<PointOfInterestController> logger, IDataService dataService, IPlacesService placesService)
        {
            _logger = logger;
            _dataService = dataService;
            _placesService = placesService;
        }

        /// <summary>
        /// Search for Points Of Interest (POIs)
        /// </summary>
        /// <remarks>
        /// Search for Points Of Interest (POIs) in Bodø based on a filter of POI IDs, tags and coordinates
        /// </remarks>
        /// <param name="filters"></param>
        /// <returns>A paginated response with POIs</returns>
        /// <response code="400">If the filters are incorrectly formatted</response>
        //[HttpGet("search")]
        //[ProducesResponseType(StatusCodes.Status400BadRequest)]
        //[ProducesResponseType(StatusCodes.Status200OK)]
        //public async Task<PaginationModel<PoiBase>> Search([FromQuery] FilterModel filters, int page = 1, int pageSize = 10)
        //{
        //    // Need to expand search functionality to other queries, like coordinates
            
        //    List<int> ids = null;
        //    if (filters.Ids != null)
        //    {
        //        try
        //        {
        //            ids = filters.Ids.Split(",").Select(x => Convert.ToInt32(x)).ToList();
        //        }
        //        catch
        //        {
        //            throw new ArgumentException("ID's need to be on the form of integers separated by commas", nameof(ids));
        //        }
        //    }

        //    return await _dataService.SearchPaginatedAsync(types: filters.Type, ids: ids, page: page, pageSize: pageSize);
        //}


        //[HttpGet("cafes")]
        //public async Task<IEnumerable<PoiEatery>> GetCafes()
        //{
        //    return await _placesService.GetDetailedEateries(type: "cafe");
        //}

        //[HttpGet("cafe/{id}")]
        //public async Task<IEnumerable<PoiEatery>> GetCafe(int id)
        //{
        //    return await _placesService.GetDetailedEateries(id: id, type: "cafe");
        //}

        //[HttpGet("restaurants")]
        //public async Task<IEnumerable<PoiEatery>> GetRestaurants()
        //{
        //    return await _placesService.GetDetailedEateries(type: "restaurant");
        //}

        //[HttpGet("restaurant/{id}")]
        //public async Task<IEnumerable<PoiEatery>> GetRestaurant(int id)
        //{
        //    return await _placesService.GetDetailedEateries(id: id, type: "restaurant");
        //}

        /// <summary>
        /// Add a Point Of Interest (POI) to the POI database
        /// </summary>
        /// <remarks>
        /// Add a Point Of Interest (POI) to the POI database using a PoiBaseModel as a request body
        /// </remarks>
        //[HttpPost]
        //public async Task<OkResult> Create([FromBody] PoiBaseModel model)
        //{
        //    await _dataService.CreateAsync(model);
        //    return Ok();
        //}

        /// <summary>
        /// Get nearby places of a given type in Bodø
        /// </summary>
        /// <remarks>
        /// Get nearby places of a given type in entire Bodø using Google Maps
        /// </remarks>
        //[Route("GetNearbyPlaces")]
        //[HttpGet]
        //public async Task<PoiBaseModel[]> GetNearbyPlaces(LocationTypeEnum locationType)
        //{
        //    var location_type = Convert.ToString(locationType);
        //    var results = (List<PoiBaseModel>)await _googleMapsService.GenerateBaseModelsFromNearbySearch(location_type);

        //    return results.ToArray();
        //}
    }
}
