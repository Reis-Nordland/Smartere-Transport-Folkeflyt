﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Hurtigruten.Facades;
using Hurtigruten.Models;
using Hurtigruten.Mappers;
namespace Hurtigruten.Services.Implementation
{
    public class TimeTableService : ITimeTableService
    {
        private readonly IHurtigrutenFacade _facade;

        public TimeTableService(IHurtigrutenFacade facade)
        {
            _facade = facade;
        }
        public async Task<ICollection<DepartureModel>> GetTimeTable(string dock)
        {
            var data = await _facade.GetTimeTable(dock);
            return data.ToModel();
        }
    }
}
