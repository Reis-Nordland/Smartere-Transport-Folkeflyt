﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Hurtigruten.Models;

namespace Hurtigruten.Services
{
    public interface ITimeTableService
    {
        Task<ICollection<DepartureModel>> GetTimeTable(string dock);
    }
}
