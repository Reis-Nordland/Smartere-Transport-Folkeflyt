﻿namespace Hurtigruten.Dtos
{
    public class DepartureDto
    {
        public string Direction { get; set; }

        public string ShipName { get; set; }

        public string DepartureTime { get; set; }
    }
}