﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Hurtigruten.Models;
using Hurtigruten.Services;
using Microsoft.AspNetCore.Mvc;

namespace Hurtigruten.Controllers
{
    [Route("timetable")]
    [ApiController]
    public class TimetableController : ControllerBase
    {
        private readonly ITimeTableService _service;

        public TimetableController(ITimeTableService service)
        {
            _service = service;
        }

        /// <summary>
        /// Get timetable for Hurtigruten
        /// </summary>
        /// <remarks>
        /// Get timetable for Hurtigruten, for departures in southward and northward direction in the same response
        /// </remarks>
        [HttpGet]
        public async Task<ICollection<DepartureModel>> Get(string dock = "bodo")
        {
            var data = await _service.GetTimeTable(dock);
            return data;
        }
    }
}