﻿using System;
using Newtonsoft.Json;

namespace Hurtigruten.Models
{
    public class DepartureModel
    {
        [JsonProperty("direction")]
        public string Direction { get; set; }

        [JsonProperty("shipName")]
        public string ShipName { get; set; }

        [JsonProperty("departureTime")]
        public DateTime? DepartureTime { get; set; }
    }
}