﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Hurtigruten.Dtos;
using Hurtigruten.Models;

namespace Hurtigruten.Facades
{
    public interface IHurtigrutenFacade
    {
        Task<ICollection<DepartureDto>> GetTimeTable(string dock);
    }
}
