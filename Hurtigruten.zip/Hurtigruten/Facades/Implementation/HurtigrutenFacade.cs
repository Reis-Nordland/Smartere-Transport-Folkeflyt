﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using HtmlAgilityPack;
using Hurtigruten.Dtos;
using Microsoft.Extensions.Configuration;

namespace Hurtigruten.Facades.Implementation
{
    public class HurtigrutenFacade : IHurtigrutenFacade
    {
        private readonly IConfiguration _configuration;

        public HurtigrutenFacade(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        private readonly ICollection<Tuple<string, string, string>> _departurePaths =
            new List<Tuple<string, string, string>>
            {
                new Tuple<string, string, string>(
                    "/html/body/div[1]/main/div/div/article/ul/li[1]/p[1]/span",
                    "/html/body/div[1]/main/div/div/article/ul/li[1]/p[1]",
                    "/html/body/div[1]/main/div/div/article/ul/li[1]/p[1]/a/span"),
                new Tuple<string, string, string>(
                    "/html/body/div[1]/main/div/div/article/ul/li[1]/p[2]/span",
                    "/html/body/div[1]/main/div/div/article/ul/li[1]/p[2]",
                    "/html/body/div[1]/main/div/div/article/ul/li[1]/p[2]/a/span"),

            };

        public async Task<ICollection<DepartureDto>> GetTimeTable(string dock)
        {
            var departures = new List<DepartureDto>();
            var web = new HtmlWeb();

            string baseUrl = _configuration["HurtigrutenUrl"];
            var html = await web.LoadFromWebAsync($"{baseUrl}/{dock}");
            var documentNode = html.DocumentNode;
            foreach (var (time, direction, ship) in _departurePaths)
            {
                var timeValue = documentNode.SelectNodes(time)?.FirstOrDefault()?.InnerText;
                var directionValue = documentNode.SelectNodes(direction)?.FirstOrDefault()?.InnerText?.Split("\n")?[1];
                var shipValue = documentNode.SelectNodes(ship)?.FirstOrDefault()?.InnerText;

                departures.Add(new DepartureDto
                {
                    DepartureTime = timeValue,
                    Direction = directionValue,
                    ShipName = shipValue
                });
            }

            return departures;
        }
    }
}
