﻿using System;
using System.Collections.Generic;
using System.Linq;
using Hurtigruten.Dtos;
using Hurtigruten.Models;

namespace Hurtigruten.Mappers
{
    public static class DepartureMapper
    {
        public static DepartureModel ToModel(this DepartureDto dto)
        {
            var canParse = DateTime.TryParse(dto.DepartureTime, out _);
            return new DepartureModel
            {
              DepartureTime = canParse ? DateTime.Parse(dto.DepartureTime) as DateTime? : null,
              Direction = dto.Direction,
              ShipName = dto.ShipName
            };
        }

        public static ICollection<DepartureModel> ToModel(this ICollection<DepartureDto> dto)
        {
            return dto.Select(model => model.ToModel()).ToList();
        }

    }
}
