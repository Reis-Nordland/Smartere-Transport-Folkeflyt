﻿using Newtonsoft.Json.Converters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace FolkeflytPOI.Controllers
{

    [JsonConverter(typeof(StringEnumConverter))]
    public enum TypeEnum
    {
        //[EnumMember(Value = "airport")]
        //airport,
        //[EnumMember(Value = "library")]
        //library,
        //[EnumMember(Value = "museum")]
        //museum,
        //[EnumMember(Value = "restaurant")]
        //restaurant,
        //[EnumMember(Value = "bar")]
        //bar,
        //[EnumMember(Value = "shopping_mall")]
        //shopping_mall,
        //[EnumMember(Value = "pier")]
        //pier,
        //[EnumMember(Value = "beach")]
        //beach,
        //[EnumMember(Value = "port")]
        //port,
        //[EnumMember(Value = "bus_stop")]
        //bus_stop,
        //[EnumMember(Value = "church")]
        //church,
        //[EnumMember(Value = "bike_stand")]
        //bike_stand,

        //[EnumMember(Value = "airport")]
        //airport,
        //[EnumMember(Value = "port")]
        //port,
        [EnumMember(Value = "natur")]
        natur,
        [EnumMember(Value = "aktiviteter")]
        aktiviteter,
        [EnumMember(Value = "kultur")]
        kultur,
        //[EnumMember(Value = "bus_stop")]
        //bus_stop,
        //[EnumMember(Value = "bike_stand")]
        //bike_stand,
        [EnumMember(Value = "mat")]
        mat,
        [EnumMember(Value = "lokale_produkter")]
        lokale_produkter,
        [EnumMember(Value = "transport")]
        transport,

    }
}
