﻿using FolkeflytPOI.Interfaces;
using FolkeflytPOI.Models;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace FolkeflytPOI.Controllers
{
    [EnableCors("MyPolicy")]
    [Route("api/[controller]")]
    public class POIController : ControllerBase
    {
        private readonly ITranslatorApi _translatorApi;
        private readonly IConfiguration _configuration;

        public POIController(IConfiguration configuration, ITranslatorApi translatorApi)
        {
            _configuration = configuration;
            _translatorApi = translatorApi;
        }

        /// <summary>
        /// Get Points Of Interest (POIs)
        /// </summary>
        /// <remarks>
        /// Get Points Of Interest (POIs), either all POIs, or filter based on id and/or type.
        /// </remarks>
        [EnableCors("MyPolicy")]
        [HttpGet()]
        public List<POI> Get(int? id, TypeEnum? type) //string[] tags = null
        {
            //testCommunication().Wait();
            DAL.Dal db = new DAL.Dal(_configuration);
            //if (tags != null && tags.Length > 0)
            //{
            //    return db.GetTaggedPOIS(tags);
            //}
            return db.GetPOI(id: id, type: Convert.ToString(type));
        }

        [EnableCors("MyPolicy")]
        [HttpPost("/translate")]
        public async Task<string> Translate(string textToTranslate, string toLanguage)
        {
            var result = await _translatorApi.TranslateText(textToTranslate, toLanguage);
            return result;
        }

        //[EnableCors("MyPolicy")]
        //[HttpGet("/transportTimes")]
        //public string GetTransportTimes(string startLat, string startLong, string endLat, string endLong, string transportMode) 
        //{
        //    var result = "";
        //    return result;
        //}

        private POI TestCreatePoi()
        {
            POI poi = new POI()
            {
                id = "20",
                name = "Småbåthavn og molo",
                coordinates = new coordinates()
                {
                    latitude = 67.280784,
                    longitude = 14.371899
                },
                address = "Moloveien 8003 Bodø",
                type = "nature-beach",
                openingHours = new Models.OpeningHours()
                {
                    monday = new OpeningHoursDay { opens = "0800", closes = "2400" },
                    tuesday = new OpeningHoursDay { opens = "0800", closes = "2400" },
                    wednesday = new OpeningHoursDay { opens = "0800", closes = "2400" },
                    thursday = new OpeningHoursDay { opens = "0800", closes = "2400" },
                    friday = new OpeningHoursDay { opens = "0800", closes = "2400" },
                    saturday = new OpeningHoursDay { opens = "0800", closes = "2400" },
                    sunday = new OpeningHoursDay { opens = "0800", closes = "2400" },
                    closedOnHoliday = "no"
                },
                weather = new string[2] { "goodweather", "neutralweather" },
                season = new string[4] { "winter", "spring", "summer", "fall" },
                duration = 0.5F,
                description = "Bodø utgjør et viktig knutepunkt i Nord, og småbåthavnene i Bodø er svært viktige i så måte. Rundt småbåthavnen i Bodø kranser en flott molo. Moloen ble påbegynt bygget allerede i 1892, av Statens Havnevesen, og tilbyr en flott naturopplevelse.",
                Tags = new string[] { "beach", "nature", "niceweather" }
            };
            return poi;
        }
    }
}
