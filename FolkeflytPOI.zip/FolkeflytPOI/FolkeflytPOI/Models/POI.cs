﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using Newtonsoft.Json;
using System;
namespace FolkeflytPOI.Models
{
    public class POI
    {
        [JsonIgnore]
        [BsonRepresentation(BsonType.ObjectId)]
        //[BsonId(IdGenerator = typeof(CombGuidGenerator))]
        public ObjectId Id { get; set; }

        [BsonElement("id")]
        public string id { get; set; }

        [BsonElement("name")]
        public string name { get; set; }

        [BsonElement("coordinates")]
        public coordinates coordinates { get; set; }

        [BsonElement("address")]
        public string address { get; set; }

        [BsonElement("type")]
        public string type { get; set; }

        [BsonElement("openingHours")]
        public OpeningHours openingHours { get; set; }

        [BsonElement("weather")]
        public string[] weather { get; set; }

        [BsonElement("season")]
        public string[] season { get; set; }

        [BsonElement("duration")]
        public float duration { get; set; }

        [BsonElement("description")]
        public string description { get; set; }
        [BsonElement("pictureName")]
        public string pictureName { get; set; }
        [BsonElement("pictureLink")]
        public string pictureLink { get; set; }
        
        [BsonElement("pictureLinkMobile")]
        public string pictureLinkMobile { get; set; }

        [BsonIgnore]
        public int weatherSymbol { get; set; }

        [BsonElement("transportType")]
        public string transportType { get; set; }
        [BsonIgnore]
        public float estimatedTransportTime { get; set; }
        [BsonIgnore]
        public string startTime { get; set; }

        [BsonElement("tags")]
        public string[] Tags { get; set; }

        [BsonElement("url")]
        public string Url { get; set; }

        [BsonElement("events")]
        public Event[] Events { get; set; }

        [JsonIgnore]
        [BsonElement("isActive")]
        public bool? isActive { get; set; }

    }

    public class Event
    {
        [BsonElement("name")]
        public string name { get; set; }
        [BsonElement("startTime")]
        public string startTime { get; set; }

        [BsonElement("date")]
        public DateTime date { get; set; }
    }
    public class coordinates
    {
        [BsonElement("latitude")]
        public double latitude { get; set; }
        [BsonElement("longitude")]
        public double longitude { get; set; }
    }

    public class OpeningHours
    {
        [BsonElement("monday")]
        public OpeningHoursDay monday { get; set; }

        [BsonElement("tuesday")]
        public OpeningHoursDay tuesday { get; set; }

        [BsonElement("wednesday")]
        public OpeningHoursDay wednesday { get; set; }

        [BsonElement("thursday")]
        public OpeningHoursDay thursday { get; set; }

        [BsonElement("friday")]
        public OpeningHoursDay friday { get; set; }

        [BsonElement("saturday")]
        public OpeningHoursDay saturday { get; set; }

        [BsonElement("sunday")]
        public OpeningHoursDay sunday { get; set; }

        [BsonElement("closedOnHoliday")]
        public string closedOnHoliday { get; set; }
    }

    public class OpeningHoursDay
    {
        public string opens { get; set; }
        public string closes { get; set; }
    }
}