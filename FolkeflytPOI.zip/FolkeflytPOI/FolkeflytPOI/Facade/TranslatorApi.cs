﻿using System.Text;
using Newtonsoft.Json;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System;
using System.Web;
using FolkeflytPOI.Interfaces;
using FolkeflytPOI.Configurations;

namespace FolkeflytPOI.Facade
{
    public class TranslatorApi: ITranslatorApi
    {
        private readonly TranslationConfiguration _translationConfiguration;

        public TranslatorApi(TranslationConfiguration translationConfiguration)
        {
            _translationConfiguration = translationConfiguration;
        }

        public async Task<string> TranslateText(string textToTranslate, string toLanguage)
        {
            var translatedText = await PerformRequestAndSerialize<string>(textToTranslate, toLanguage);

            return translatedText;
        }

        private async Task<string> PerformRequestAndSerialize<T>(string textToTranslate, string toLanguage) where T : class
        {
            var endpoint = _translationConfiguration.Endpoint;
            var route = _translationConfiguration.Route + toLanguage;
            var key = _translationConfiguration.Key;
            var location = _translationConfiguration.Location;

            object[] body = new object[] { new { Text = textToTranslate } };
            var requestBody = JsonConvert.SerializeObject(body);

            using var client = new HttpClient();
            using var request = new HttpRequestMessage();

            // Build the request.
            request.Method = HttpMethod.Post;
            request.RequestUri = new Uri(endpoint + route);
            request.Content = new StringContent(requestBody, Encoding.UTF8, "application/json");
            request.Headers.Add("Ocp-Apim-Subscription-Key", key);
            // location required if you're using a multi-service or regional (not global) resource.
            request.Headers.Add("Ocp-Apim-Subscription-Region", location);

            // Send the request and get response.
            HttpResponseMessage response = await client.SendAsync(request).ConfigureAwait(false);
            // Read response as a string.
            string result = await response.Content.ReadAsStringAsync();
            return result;
           
        }
    }
}
