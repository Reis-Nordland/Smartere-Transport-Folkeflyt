﻿using System.Threading.Tasks;
using System.Collections.Generic;

namespace FolkeflytPOI.Interfaces
{
    public interface ITranslatorApi
    {
        Task<string> TranslateText(string text, string toLanguage);
    }
}
