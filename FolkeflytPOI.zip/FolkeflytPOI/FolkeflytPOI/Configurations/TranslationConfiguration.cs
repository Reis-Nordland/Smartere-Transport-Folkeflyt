﻿namespace FolkeflytPOI.Configurations
{
    public class TranslationConfiguration
    {
        public string Endpoint { get; set; }
        public string Route { get; set; }
        public string Key { get; set; }
        public string Location{ get; set; }
    }
}
