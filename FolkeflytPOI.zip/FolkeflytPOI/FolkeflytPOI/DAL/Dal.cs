﻿using System;
using System.Collections.Generic;
using System.Linq;
using MongoDB.Driver;
using MongoDB.Bson;
using System.Security.Authentication;
using FolkeflytPOI.Models;
using Microsoft.Extensions.Configuration;
using MongoDB.Bson.Serialization;

namespace FolkeflytPOI.DAL
{
    public class Dal : IDisposable
    {
        private readonly IConfiguration _configuration;

        public Dal(IConfiguration configuration)
        {
            _configuration = configuration;
        }
        
        private bool disposed = false;

        private string UserName => _configuration["DbUserName"];
        private string Host => _configuration["DbHost"];
        private string Password => _configuration["DbPassword"];
        private string DbName => _configuration["DbName"];
        private string POICollectionName => _configuration["PoiCollectionName"];

        // Gets all POI from the MongoDB server with filter       
        public List<POI> GetPOI(int? id = null, string type = null)
        {
            try
            {
                var filter = GetFilter(id: id, types: type);
                var collection = GetPOICollection();

                //if (filter == null)
                //{
                //    return collection.Find(new BsonDocument()).ToList(); // Return all POIs
                //}

                var a = collection.Find(filter);
                return a.ToList();
            }
            catch (MongoConnectionException)
            {
                return new List<POI>();
            }
        }

        public List<POI> GetTaggedPOIS(string[] tags)
        {
            try
            {
                var collection = GetPOICollection();
                if (tags == null || tags.Length == 0 )
                {
                    return collection.Find(new BsonDocument()).ToList();
                }
                //var tagString = tags.ToString();
                var filter = $"{{'tags': '{{ $in: {tags} }} }}'}}";
                return collection.AsQueryable<POI>().Where<POI>(poi => poi.Tags.Any(tag => tags.Contains(tag))).ToList();
            }
            catch (MongoConnectionException)
            {
                return new List<POI>();
            }
        }

        // Creates POI and inserts it into the collection in MongoDB.
        public void CreatePOI(POI poi)
        {
            var collection = GetPOICollection();//ForEdit();
            try
            {
                poi.Id = ObjectId.GenerateNewId();
                collection.InsertOne(poi);
            }
            catch (MongoCommandException ex)
            {
                string msg = ex.Message;
            }
        }

        private IMongoCollection<POI> GetPOICollection()
        {
            var database = GetMongoDatabase();

            var POICollection = database.GetCollection<POI>(POICollectionName);
            return POICollection;
        }

        private IMongoDatabase GetMongoDatabase()
        {
            MongoClientSettings settings = new MongoClientSettings();
            settings.Server = new MongoServerAddress(Host, 10255);
            settings.UseSsl = true;
            settings.SslSettings = new SslSettings();
            settings.SslSettings.EnabledSslProtocols = SslProtocols.Tls12;

            MongoIdentity identity = new MongoInternalIdentity(DbName, UserName);
            MongoIdentityEvidence evidence = new PasswordEvidence(Password);

            settings.Credential = new MongoCredential("SCRAM-SHA-1", identity, evidence);

            MongoClient client = new MongoClient(settings);
            var database = client.GetDatabase(DbName);
            return database;
        }

        private FilterDefinition<POI> GetFilter(int? id = null, string tags = null, string types = null)
        {
            var filters = new List<FilterDefinition<POI>>();

            if (id != null)
            {
                filters.Add(Builders<POI>.Filter.Eq("id", id));
            }

            if (!string.IsNullOrEmpty(tags))
            {
                filters.Add(Builders<POI>.Filter.AnyIn("tags", tags.Split(",")));
            }

            if (!string.IsNullOrEmpty(types))
            {
                filters.Add(Builders<POI>.Filter.Eq("type", types));//.Split(",")));
            }

            filters.Add(Builders<POI>.Filter.Eq(x => x.isActive, true));//.Split(",")));

            return Builders<POI>.Filter.And(filters);
        }

        #region IDisposable
        public void Dispose()
        {
            this.Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                }
            }

            this.disposed = true;
        }
        # endregion
    }
}