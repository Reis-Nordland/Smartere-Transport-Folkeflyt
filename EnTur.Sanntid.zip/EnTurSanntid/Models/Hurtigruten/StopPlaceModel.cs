﻿namespace EnTurSanntid.Models.Hurtigruten
{
    public class StopPlaceModel
    {
        /// <summary>
        /// EnTur ID of the stop.
        /// </summary>
        public string id { get; set; }

        /// <summary>
        /// Name of the stop.
        /// </summary>
        public string name { get; set; }
    }
}