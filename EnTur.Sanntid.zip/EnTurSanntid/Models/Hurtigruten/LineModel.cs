﻿namespace EnTurSanntid.Models.Hurtigruten
{
    public class LineModel
    {

        /// <summary>
        /// EnTur ID of the line.
        /// </summary>
        public string id { get; set; }

        /// <summary>
        /// Name of the line.
        /// </summary>
        public string name { get; set; }
    }
}