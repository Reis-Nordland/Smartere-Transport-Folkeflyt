﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EnTurSanntid.Models.Hurtigruten
{
    public class HurtigrutenModel
    {
        public StopPlaceModel stopPlace { get; set; }
        public DepartureModel[] departures { get; set; }
    }
}
