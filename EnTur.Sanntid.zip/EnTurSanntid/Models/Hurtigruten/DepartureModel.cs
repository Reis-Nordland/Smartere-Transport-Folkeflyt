﻿using System;

namespace EnTurSanntid.Models.Hurtigruten
{
    public class DepartureModel
    {
        /// <summary>
        /// Whether this call has been updated with real time information.
        /// </summary>
        public bool isUpdatedRealtime { get; set; }

        /// <summary>
        /// Scheduled time of arrival at quay. Not affected by read time updated.
        /// </summary>
        public DateTime? aimedArrivalTime { get; set; }

        /// <summary>
        /// Scheduled time of departure from quay. Not affected by read time updated.
        /// </summary>
        public DateTime? aimedDepartureTime { get; set; }

        /// <summary>
        /// Expected time of arrival at quay. Updated with real time information if available.
        /// </summary>
        public DateTime? expectedArrivalTime { get; set; }

        /// <summary>
        /// Expected time of departure from quay. Updated with real time information if available.
        /// </summary>
        public DateTime? expectedDepartureTime { get; set; }

        /// <summary>
        /// Actual time of arrival at quay. Updated from real time information if available.
        /// </summary>
        public DateTime? actualArrivalTime { get; set; }

        /// <summary>
        /// Actual time of departure from quay. Updated with real time information if available
        /// </summary>
        public DateTime? actualDepartureTime { get; set; }

        /// <summary>
        /// The last time these times were updated.
        /// </summary>
        public string lastUpdated { get; set; }

        /// <summary>
        /// Final destination.
        /// </summary>
        public string destination { get; set; }

        /// <summary>
        /// EnTur ID of quay. Should always be the same for this application, as Bodø fergekai only has one.
        /// </summary>
        public string quayId { get; set; }

        public LineModel line { get; set; }
    }
}