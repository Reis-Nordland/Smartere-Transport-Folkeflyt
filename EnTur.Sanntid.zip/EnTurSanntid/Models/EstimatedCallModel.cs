﻿using System;
using Newtonsoft.Json;

namespace EnTurSanntid.Models
{
    public class EstimatedCallModel
    {
        [JsonProperty("stopPointRef")]
        public string StopPointRef { get; set; }

        [JsonProperty("order")]
        public int Order { get; set; }

        [JsonProperty("cancellation")]
        public bool Cancellation { get; set; }

        [JsonProperty("predictionInaccurate")]
        public bool PredictionInaccurate { get; set; }

        [JsonProperty("aimedArrivalTime")]
        public DateTime? AimedArrivalTime { get; set; }

        [JsonProperty("expectedArrivalTime")]
        public DateTime? ExpectedArrivalTime { get; set; }

        [JsonProperty("arrivalBoardingActivity")]
        public string ArrivalBoardingActivity { get; set; }

        [JsonProperty("aimedDepartureTime")]
        public DateTime? AimedDepartureTime { get; set; }

        [JsonProperty("expectedDepartureTime")]
        public DateTime? ExpectedDepartureTime { get; set; }

        [JsonProperty("departureBoardingActivity")]
        public string DepartureBoardingActivity { get; set; }
    }
}
