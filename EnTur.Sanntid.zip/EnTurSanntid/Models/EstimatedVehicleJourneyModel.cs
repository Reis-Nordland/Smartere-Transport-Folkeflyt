﻿using System.Collections.Generic;
using Newtonsoft.Json;

namespace EnTurSanntid.Models
{
    public class EstimatedVehicleJourneyModel
    {
        public EstimatedVehicleJourneyModel()
        {
            EstimatedCalls = new List<EstimatedCallModel>();
        }

        [JsonProperty("lineRef")]
        public string LineRef { get; set; }

        [JsonProperty("directionRef")]
        public int DirectionRef { get; set; }

        [JsonProperty("datedVehicleJourneyRef")]
        public string DatedVehicleJourneyRef { get; set; }

        [JsonProperty("cancellation")]
        public bool Cancellation { get; set; }

        [JsonProperty("vehicleMode")]
        public string VehicleMode { get; set; }

        [JsonProperty("operatorRef")]
        public int OperatorRef { get; set; }

        [JsonProperty("monitored")]
        public bool Monitored { get; set; }

        [JsonProperty("dataSource")]
        public string DataSource { get; set; }

        [JsonProperty("blockRef")]
        public string BlockRef { get; set; }

        [JsonProperty("estimatedCalls")]
        public ICollection<EstimatedCallModel> EstimatedCalls { get; set; }

        [JsonProperty("isCompleteStopSequence")]
        public bool IsCompleteStopSequence { get; set; }
    }
}
