﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Threading.Tasks;
using EnTurSanntid.Dtos.Hurtigruten;
using EnTurSanntid.Models;
using EnTurSanntid.Models.Hurtigruten;
using EnTurSanntid.Services;
using Microsoft.AspNetCore.Mvc;

namespace EnTurSanntid.Controllers
{
    [Route("sanntid")]
    [ApiController]
    public class SanntidController : ControllerBase
    {
        private readonly ISanntidService _service;

        public SanntidController(ISanntidService service)
        {
            _service = service;
        }

        /// <summary>
        /// Get real time information
        /// </summary>
        /// <remarks>
        /// Get real time information on a specific public transport line
        /// </remarks>
        [HttpGet]
        [Produces("application/json")]
        public async Task<ICollection<EstimatedVehicleJourneyModel>> Get([FromQuery, Required]string line, [FromQuery]int directionRef = 1)
        {
            //NOR:Line:3731
            var data = await _service.GetJourney(line, directionRef);
            return data;
        }

        /// <summary>
        /// Hurtigruten
        /// </summary>
        /// <remarks>
        /// Get real time information on future Hurtigruten departures from Bodø Kystrutekai
        /// </remarks>
        [HttpGet("Hurtigruten")]
        [Produces("application/json")]
        public async Task<HurtigrutenModel> GetHurtigruten(int hoursTimeSpan = 24)
        {
            var timeSpanInSeconds = hoursTimeSpan * 3600;
            return await _service.GetHurtigrutenTimes(timeSpanInSeconds);
        }

    }
}