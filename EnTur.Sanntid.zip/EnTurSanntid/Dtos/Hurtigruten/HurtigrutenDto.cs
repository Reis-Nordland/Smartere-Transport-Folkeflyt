﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EnTurSanntid.Dtos.Hurtigruten
{
    public class HurtigrutenDto
    {
        public StopPlaceDto stopPlace { get; set; }
    }
}
