﻿namespace EnTurSanntid.Dtos.Hurtigruten
{
    public class LineDto
    {
        public string id { get; set; }
        public string name { get; set; }
    }
}