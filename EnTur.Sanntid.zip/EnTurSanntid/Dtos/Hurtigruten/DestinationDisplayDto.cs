﻿namespace EnTurSanntid.Dtos.Hurtigruten
{
    public class DestinationDisplayDto
    {
        public string frontText { get; set; }
    }
}