﻿namespace EnTurSanntid.Dtos.Hurtigruten
{
    public class StopPlaceDto
    {
        public string id { get; set; }
        public string name { get; set; }
        public EstimatedCallDto[] estimatedCalls { get; set; }

    }
}