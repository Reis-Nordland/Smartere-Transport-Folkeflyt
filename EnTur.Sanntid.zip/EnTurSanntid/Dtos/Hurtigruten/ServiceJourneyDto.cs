﻿namespace EnTurSanntid.Dtos.Hurtigruten
{
    public class ServiceJourneyDto
    {
        public JourneyPatternDto journeyPattern { get; set; }
    }
}