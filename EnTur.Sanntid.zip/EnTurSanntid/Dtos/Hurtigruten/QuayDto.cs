﻿namespace EnTurSanntid.Dtos.Hurtigruten
{
    public class QuayDto
    {
        public string id { get; set; }
    }
}