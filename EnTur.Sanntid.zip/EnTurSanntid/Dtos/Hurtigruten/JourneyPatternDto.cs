﻿namespace EnTurSanntid.Dtos.Hurtigruten
{
    public class JourneyPatternDto
    {
        public LineDto line { get; set; }
    }
}