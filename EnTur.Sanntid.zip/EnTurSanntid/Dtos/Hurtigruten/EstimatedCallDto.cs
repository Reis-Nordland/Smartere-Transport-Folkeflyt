﻿using System;

namespace EnTurSanntid.Dtos.Hurtigruten
{
    public class EstimatedCallDto
    {
        // Whether this call has been updated with real time information.
        public bool realtime { get; set; }
        public DateTime? aimedArrivalTime { get; set; }
        public DateTime? aimedDepartureTime { get; set; }
        public DateTime? expectedArrivalTime { get; set; }
        public DateTime? expectedDepartureTime { get; set; }
        public DateTime? actualArrivalTime { get; set; }
        public DateTime? actualDepartureTime { get; set; }
        public string date { get; set; }
        public DestinationDisplayDto destinationDisplay { get; set; }
        public QuayDto quay { get; set; }
        public ServiceJourneyDto serviceJourney { get; set; }

    }
}