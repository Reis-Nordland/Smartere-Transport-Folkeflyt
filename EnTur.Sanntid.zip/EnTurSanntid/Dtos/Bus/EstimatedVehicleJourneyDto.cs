﻿using System.Collections.Generic;
using System.Xml.Serialization;

namespace EnTurSanntid.Dtos.Bus
{
    public class EstimatedVehicleJourneyDto
    {
        [XmlElement(ElementName = "LineRef")]
        public string LineRef { get; set; }

        [XmlElement(ElementName = "DirectionRef")]
        public int DirectionRef { get; set; }

        [XmlElement(ElementName = "DatedVehicleJourneyRef")]
        public string DatedVehicleJourneyRef { get; set; }

        [XmlElement(ElementName = "Cancellation")]
        public bool Cancellation { get; set; }

        [XmlElement(ElementName = "VehicleMode")]
        public string VehicleMode { get; set; }

        [XmlElement(ElementName = "OperatorRef")]
        public int OperatorRef { get; set; }

        [XmlElement(ElementName = "Monitored")]
        public bool Monitored { get; set; }

        [XmlElement(ElementName = "DataSource")]
        public string DataSource { get; set; }

        [XmlElement(ElementName = "BlockRef")]
        public string BlockRef { get; set; }

        [XmlElement(ElementName = "EstimatedCalls")]
        public EstimatedCallsDto EstimatedCalls { get; set; }

        [XmlElement(ElementName = "IsCompleteStopSequence")]
        public bool IsCompleteStopSequence { get; set; }
    }
}