﻿using System;
using System.Xml.Serialization;

namespace EnTurSanntid.Dtos.Bus
{
    public class EstimatedTimetableDeliveryDto
    {
        [XmlElement(ElementName = "ResponseTimestamp")]
        public DateTime ResponseTimestamp { get; set; }

        [XmlElement(ElementName = "EstimatedJourneyVersionFrame")]
        public EstimatedJourneyVersionFrameDto EstimatedJourneyVersionFrame { get; set; }

        [XmlAttribute(AttributeName = "version")]
        public string Version { get; set; }

    }
}