﻿using System;
using System.Collections.Generic;
using System.Xml.Serialization;

namespace EnTurSanntid.Dtos.Bus
{
    public class EstimatedJourneyVersionFrameDto
    {
        [XmlElement(ElementName = "RecordedAtTime")]
        public DateTime RecordedAtTime { get; set; }

        [XmlElement(ElementName = "EstimatedVehicleJourney")]
        public List<EstimatedVehicleJourneyDto> EstimatedVehicleJourney { get; set; }
    }
}