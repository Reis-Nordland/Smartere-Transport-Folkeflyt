﻿using System;
using System.Xml.Serialization;

namespace EnTurSanntid.Dtos.Bus
{
    public class ServiceDeliveryDto
    {
        [XmlElement(ElementName = "ResponseTimestamp")]
        public DateTime ResponseTimestamp { get; set; }

        [XmlElement(ElementName = "ProducerRef")]
        public string ProducerRef { get; set; }
       
        [XmlElement(ElementName = "EstimatedTimetableDelivery")]
        public EstimatedTimetableDeliveryDto EstimatedTimetableDelivery { get; set; }
    }
}