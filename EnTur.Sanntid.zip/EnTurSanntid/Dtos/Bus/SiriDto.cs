﻿using System.Xml.Serialization;

namespace EnTurSanntid.Dtos.Bus
{
    [XmlType(AnonymousType = true, Namespace = "http://www.siri.org.uk/siri")]
    [XmlRoot(Namespace = "http://www.siri.org.uk/siri", IsNullable = false, ElementName = "Siri")]
    public class SiriDto
    {
        [XmlElement(ElementName = "ServiceDelivery")]
        public ServiceDeliveryDto ServiceDelivery { get; set; }

        [XmlAttribute(AttributeName = "version")]
        public string Version { get; set; }
    }
}