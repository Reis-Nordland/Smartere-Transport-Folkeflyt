﻿using System;
using System.Xml.Serialization;

namespace EnTurSanntid.Dtos.Bus
{
    [XmlRoot(ElementName = "EstimatedCall", Namespace = "http://www.siri.org.uk/siri")]
    public class EstimatedCallDto
    {
        [XmlElement(ElementName = "StopPointRef")]
        public string StopPointRef { get; set; }

        [XmlElement(ElementName = "Order")]
        public int Order { get; set; }

        [XmlElement(ElementName = "Cancellation")]
        public bool Cancellation { get; set; }

        [XmlElement(ElementName = "PredictionInaccurate")]
        public bool PredictionInaccurate { get; set; }

        [XmlElement(ElementName = "AimedArrivalTime")]
        public DateTime? AimedArrivalTime { get; set; }

        [XmlElement(ElementName = "ExpectedArrivalTime")]
        public DateTime? ExpectedArrivalTime { get; set; }

        [XmlElement(ElementName = "ArrivalBoardingActivity")]
        public string ArrivalBoardingActivity { get; set; }

        [XmlElement(ElementName = "AimedDepartureTime")]
        public DateTime? AimedDepartureTime { get; set; }

        [XmlElement(ElementName = "ExpectedDepartureTime")]
        public DateTime? ExpectedDepartureTime { get; set; }

        [XmlElement(ElementName = "DepartureBoardingActivity")]
        public string DepartureBoardingActivity { get; set; }
    }
}
