﻿using System.Threading.Tasks;
using EnTurSanntid.Dtos.Bus;
using EnTurSanntid.Dtos.Hurtigruten;

namespace EnTurSanntid.Facade
{
    public interface IEnturFacade
    {
        Task<SiriDto> GetServiceDelivery(string line);
        Task<HurtigrutenDto> HurtigrutenTimeTable(int timeRangeInSeconds);
    }
}
