﻿using System;
using System.Collections.Specialized;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web;
using System.Xml.Serialization;
using EnTurSanntid.Config;
using EnTurSanntid.Dtos;
using EnTurSanntid.Dtos.Bus;
using EnTurSanntid.Dtos.Hurtigruten;
using GraphQL;
using GraphQL.Client.Http;
using GraphQL.Client.Serializer.Newtonsoft;
using Microsoft.Extensions.Options;

namespace EnTurSanntid.Facade.Implementation
{
    public class EnturFacade : IEnturFacade
    {
        private readonly IHttpClientFactory _clientFactory;
        private readonly EnturConfig _apiConfig;

        public EnturFacade(IHttpClientFactory clientFactory, IOptions<EnturConfig> options)
        {
            _clientFactory = clientFactory;
            _apiConfig = options.Value;
        }

        public async Task<SiriDto> GetServiceDelivery(string line)
        {
            var args = new NameValueCollection();

            args.Set("datasetId", "NOR");
            args.Set("LineRef", line);

            var data = await PerformRequestAndSerialize<SiriDto>("realtime/v1/rest/et",
                string.Join("&", args.AllKeys.Select(key => string.Concat(HttpUtility.UrlEncode(key), "=", HttpUtility.UrlEncode(args[key]))).ToArray()));

            return data;
        }


        private async Task<T> PerformRequestAndSerialize<T>(string endpoint, string param = null) where T : class
        {
            var httpClient = _clientFactory.CreateClient();
            httpClient.DefaultRequestHeaders.Add("ET-Client-Name", _apiConfig.ClientName);
            var uriBuilder = new UriBuilder(new Uri(_apiConfig.BaseUri)) { Path = endpoint, Query = param };
            var response = await httpClient.GetStreamAsync(uriBuilder.Uri);
            var serializer = new XmlSerializer(typeof(T));

            return serializer.Deserialize(response) as T;
        }

        public async Task<HurtigrutenDto> HurtigrutenTimeTable(int timeRangeInSeconds)
        {

            var graphQLClient = new GraphQLHttpClient("https://api.entur.io/journey-planner/v2/graphql", new NewtonsoftJsonSerializer());
            graphQLClient.HttpClient.DefaultRequestHeaders.Add("ET-Client-Name", "Avinor - Folkeflyt");


            var hurtigrutenRequest = new GraphQLRequest
            {
                // 'NSR:StopPlace:58053' is Bodø Kystrutekai
                Query = @"
                query Hurtigruten($id: String!, $timeRange: Int) {
                    stopPlace(id: $id) {
                        id
                        name
                        estimatedCalls(timeRange: $timeRange, numberOfDepartures: 10) {
                            realtime
                            aimedArrivalTime
                            aimedDepartureTime
                            expectedArrivalTime
                            expectedDepartureTime
                            actualArrivalTime
                            actualDepartureTime
                            date
                            destinationDisplay {
                                frontText
                            }
                            quay {
                                id
                            }
                            serviceJourney {
                                journeyPattern {
                                    line {
                                        id
                                        name
                                    }
                                }
                            }
                        }
                    }
                }",
                OperationName = "Hurtigruten",
                Variables = new
                {
                    id = "NSR:StopPlace:58053",
                    timeRange = timeRangeInSeconds
                }
            };

            var graphQLResponse = await graphQLClient.SendQueryAsync<HurtigrutenDto>(hurtigrutenRequest);

            return graphQLResponse.Data;

        }
     


    }
}
