﻿using EnTurSanntid.Dtos.Hurtigruten;
using EnTurSanntid.Models.Hurtigruten;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EnTurSanntid.Mappers
{
    public static class HurtigrutenMapper
    {
        public static HurtigrutenModel ToModel(this HurtigrutenDto dto)
        {
            return new HurtigrutenModel
            {
                stopPlace = new StopPlaceModel
                {
                    id = dto.stopPlace.id,
                    name = dto.stopPlace.name
                },
                departures = dto.stopPlace.estimatedCalls.Select(x => x.ToDepartureModel()).ToArray()
            };
        }

        public static DepartureModel ToDepartureModel(this EstimatedCallDto dto)
        {
            return new DepartureModel
            {
                isUpdatedRealtime = dto.realtime,
                aimedArrivalTime = dto.aimedArrivalTime,
                aimedDepartureTime = dto.aimedDepartureTime,
                expectedArrivalTime = dto.expectedArrivalTime,
                expectedDepartureTime = dto.expectedDepartureTime,
                actualArrivalTime = dto.actualArrivalTime,
                actualDepartureTime = dto.actualDepartureTime,
                lastUpdated = dto.date,
                destination = dto.destinationDisplay.frontText,
                quayId = dto.quay.id,
                line = new LineModel
                {
                    id = dto.serviceJourney.journeyPattern.line.id,
                    name = dto.serviceJourney.journeyPattern.line.name
                }
            };
        }
    }
}

