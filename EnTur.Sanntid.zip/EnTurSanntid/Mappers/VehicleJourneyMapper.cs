﻿using System.Collections.Generic;
using System.Linq;
using EnTurSanntid.Dtos.Bus;
using EnTurSanntid.Models;

namespace EnTurSanntid.Mappers
{
    public static class VehicleJourneyMapper
    {
        public static EstimatedVehicleJourneyModel ToModel(this EstimatedVehicleJourneyDto dto)
        {
            return new EstimatedVehicleJourneyModel
            {
                BlockRef = dto.BlockRef,
                Cancellation = dto.Cancellation,
                DataSource = dto.DataSource,
                DatedVehicleJourneyRef = dto.DatedVehicleJourneyRef,
                DirectionRef = dto.DirectionRef,
                EstimatedCalls = dto.EstimatedCalls.EstimatedCall?.ToModel(),
                IsCompleteStopSequence = dto.IsCompleteStopSequence,
                LineRef = dto.LineRef,
                Monitored = dto.Monitored,
                OperatorRef = dto.OperatorRef,
                VehicleMode = dto.VehicleMode
            };
        }

        public static ICollection<EstimatedVehicleJourneyModel> ToModel(this ICollection<EstimatedVehicleJourneyDto> dto)
        {
            return dto.Select(model => model.ToModel()).ToList();
        }

        public static EstimatedCallModel ToModel(this EstimatedCallDto dto)
        {
            return new EstimatedCallModel
            {
                Cancellation = dto.Cancellation,
                AimedArrivalTime = dto.AimedArrivalTime,
                AimedDepartureTime = dto.AimedDepartureTime,
                ArrivalBoardingActivity = dto.ArrivalBoardingActivity,
                DepartureBoardingActivity = dto.DepartureBoardingActivity,
                ExpectedArrivalTime = dto.ExpectedArrivalTime,
                ExpectedDepartureTime = dto.ExpectedDepartureTime,
                Order = dto.Order,
                PredictionInaccurate = dto.PredictionInaccurate,
                StopPointRef = dto.StopPointRef
            };
        }
        public static ICollection<EstimatedCallModel> ToModel(this IEnumerable<EstimatedCallDto> dto)
        {
            return dto.Select(model => model.ToModel()).ToList();
        }
    }
}
