﻿namespace EnTurSanntid.Config
{
    public class EnturConfig
    {
        public string BaseUri { get; set; }
        public string ClientName { get; set; }
    }
}
