﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EnTurSanntid.Dtos.Hurtigruten;
using EnTurSanntid.Facade;
using EnTurSanntid.Mappers;
using EnTurSanntid.Models;
using EnTurSanntid.Models.Hurtigruten;

namespace EnTurSanntid.Services.Implementation
{
    public class SanntidService : ISanntidService
    {
        private readonly IEnturFacade _facade;

        public SanntidService(IEnturFacade facade)
        {
            _facade = facade;
        }
        public async Task<ICollection<EstimatedVehicleJourneyModel>> GetJourney(string line, int directionRef = 1)
        {
            var data = await _facade.GetServiceDelivery(line);
            var journeys = data?.ServiceDelivery?.EstimatedTimetableDelivery?.EstimatedJourneyVersionFrame?.EstimatedVehicleJourney?.Where(n => n.DirectionRef == directionRef).ToList();
            return journeys.ToModel();
        }

        public async Task<HurtigrutenModel> GetHurtigrutenTimes(int timeRangeInSeconds)
        {
            var data = await _facade.HurtigrutenTimeTable(timeRangeInSeconds);
            return data.ToModel();
        }
    }
}
