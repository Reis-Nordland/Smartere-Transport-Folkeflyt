﻿using System.Collections.Generic;
using System.Threading.Tasks;
using EnTurSanntid.Dtos.Hurtigruten;
using EnTurSanntid.Models;
using EnTurSanntid.Models.Hurtigruten;

namespace EnTurSanntid.Services
{
    public interface ISanntidService
    {
        Task<HurtigrutenModel> GetHurtigrutenTimes(int timeRangeInSeconds);
        Task<ICollection<EstimatedVehicleJourneyModel>> GetJourney(string line, int directionRef = 1);
    }
}
