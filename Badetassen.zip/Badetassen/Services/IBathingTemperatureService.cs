﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Badetassen.Models;

namespace Badetassen.Services
{
    public interface IBathingTemperatureService
    {
        Task<ICollection<BathingTemperatureModel>> GetTemperatures(string area);
    }
}
