﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Badetassen.Dtos;
using Badetassen.Facades;
using Badetassen.Mappers;
using Badetassen.Models;

namespace Badetassen.Services.Implementation
{
    public class BathingTemperatureService : IBathingTemperatureService
    {
        private readonly IBadetassenApi _badetassenApi;

        public BathingTemperatureService(IBadetassenApi badetassenApi)
        {
            _badetassenApi = badetassenApi;
        }

        public async Task<ICollection<BathingTemperatureModel>> GetTemperatures(string area = "Bodø")
        {
            var data =await _badetassenApi.GetTemperatures(area);
            return data.ToModel();
        }
    }
}
