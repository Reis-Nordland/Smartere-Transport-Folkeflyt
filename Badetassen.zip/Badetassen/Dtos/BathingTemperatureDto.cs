﻿using System;
using System.Globalization;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace Badetassen.Dtos
{
    public class BathingTemperatureDto
    {
        [JsonProperty("id")]
        public int Id { get; set; }
        
        [JsonProperty("Area_id")]
        public int AreaId { get; set; }
        
        [JsonProperty("Name")]
        public string Name { get; set; }

        [JsonProperty("GPSLat")]
        public double GpsLat { get; set; }

        [JsonProperty("GPSLong")]
        public double GpsLong { get; set; }
        
        [JsonProperty("PictureUrl")]
        public string PictureUrl { get; set; }

        [JsonProperty("lastReadingTime")]
        public DateTime LastReadingTime { get; set; }
        
        [JsonProperty("LastTemperature")]
        public float LastTemperature { get; set; }


        public static BathingTemperatureDto[] FromJson(string json) => JsonConvert.DeserializeObject<BathingTemperatureDto[]>(json, Converter.Settings);

        public static string ToJson(BathingTemperatureDto self) => JsonConvert.SerializeObject(self, Converter.Settings);

        internal static class Converter
        {
            public static readonly JsonSerializerSettings Settings = new JsonSerializerSettings
            {
                MetadataPropertyHandling = MetadataPropertyHandling.Ignore,
                DateParseHandling = DateParseHandling.None,
                Converters =
            {
                new IsoDateTimeConverter { DateTimeStyles = DateTimeStyles.AssumeUniversal }
            },
            };
        }
    }

}