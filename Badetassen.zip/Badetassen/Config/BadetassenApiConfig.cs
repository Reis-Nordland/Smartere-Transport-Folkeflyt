﻿namespace Badetassen.Config
{
    public class BadetassenApiConfig
    {
        public string BaseUri { get; set; }
        public string AccessToken { get; set; }
        public int CacheDuration { get; set; }
    }
}
