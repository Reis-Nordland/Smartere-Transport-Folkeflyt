﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Badetassen.Dtos;

namespace Badetassen.Facades
{
    public interface IBadetassenApi
    {
        Task<ICollection<BathingTemperatureDto>> GetTemperatures(string area);
    }
}
