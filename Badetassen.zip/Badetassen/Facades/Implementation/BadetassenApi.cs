﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Web;
using Badetassen.Config;
using Badetassen.Dtos;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;

namespace Badetassen.Facades.Implementation
{
    public class BadetassenApi : IBadetassenApi
    {
        private readonly IHttpClientFactory _clientFactory;
        private readonly IMemoryCache _cache;
        private readonly BadetassenApiConfig _apiConfig;
        public BadetassenApi(IHttpClientFactory clientFactory, IOptions<BadetassenApiConfig> options, IMemoryCache memoryCache)
        {
            _clientFactory = clientFactory;
            _cache = memoryCache;
            _apiConfig = options.Value;

        }

        public async Task<ICollection<BathingTemperatureDto>> GetTemperatures(string area)
        {
            var cacheKey = "folkeflyt.badetassen.temperatures";
            if (!_cache.TryGetValue(cacheKey, out ICollection<BathingTemperatureDto> temperatures))
            {
                temperatures = await PerformRequestAndSerialize<ICollection<BathingTemperatureDto>>(area);
                var cacheOptions = new MemoryCacheEntryOptions().SetAbsoluteExpiration(TimeSpan.FromMinutes(_apiConfig.CacheDuration));
                _cache.Set(cacheKey, temperatures, cacheOptions);
            }

            return temperatures;
        }

        private async Task<T> PerformRequestAndSerialize<T>(string area) where T : class
        {
            var httpClient = _clientFactory.CreateClient();
            
            httpClient.BaseAddress = new Uri(_apiConfig.BaseUri);
            httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", _apiConfig.AccessToken);
            httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            var response = await httpClient.GetAsync(HttpUtility.UrlEncode(area));
            var content = await response.Content.ReadAsStringAsync();

            return JsonConvert.DeserializeObject<T>(content);
        }
    }
}
