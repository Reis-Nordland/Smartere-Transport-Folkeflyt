﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Badetassen.Models;
using Badetassen.Services;
using Microsoft.AspNetCore.Mvc;

namespace Badetassen.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class BathingTemperatureController : ControllerBase
    {
        private readonly IBathingTemperatureService _waterTempService;

        public BathingTemperatureController(IBathingTemperatureService waterTempService)
        {
            _waterTempService = waterTempService;
        }

        /// <summary>
        /// Get bathing temperatures for Bodø
        /// </summary>
        /// <remarks>
        /// Get bathing temperatures for Bodø from Badetassen
        /// </remarks>
        /// <returns></returns>
        [HttpGet]
        public async Task<ICollection<BathingTemperatureModel>> Get()
        {
            var area = "Bodø";
            var data = await _waterTempService.GetTemperatures(area);
            return data;
        }
    }
}
