﻿using System;
using Newtonsoft.Json;

namespace Badetassen.Models
{
    public class BathingTemperatureModel
    {
        [JsonProperty("id")]
        public int Id { get; set; }

        [JsonProperty("areaId")]
        public int AreaId { get; set; }

        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("latitude")]
        public double Latitude { get; set; }

        [JsonProperty("longitude")]
        public double Longitude { get; set; }

        [JsonProperty("imageUrl")]
        public string ImageUrl { get; set; }

        [JsonProperty("lastReadingTime")]
        public DateTime LastReadingTime { get; set; }

        [JsonProperty("lastTemperature")]
        public float LastTemperature { get; set; }
    }
}
