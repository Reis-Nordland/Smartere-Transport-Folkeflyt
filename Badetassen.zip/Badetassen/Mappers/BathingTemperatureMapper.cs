﻿using System.Collections.Generic;
using System.Linq;
using Badetassen.Dtos;
using Badetassen.Models;

namespace Badetassen.Mappers
{
    public static class BathingTemperatureMapper
    {
        public static ICollection<BathingTemperatureModel> ToModel(this ICollection<BathingTemperatureDto> dto)
        {
            return dto.Select(model => model.ToModel()).ToList();
        }

        public static BathingTemperatureModel ToModel(this BathingTemperatureDto dto)
        {
            return new BathingTemperatureModel
            {
                Id = dto.Id,
                AreaId = dto.AreaId,
                ImageUrl = dto.PictureUrl,
                Name = dto.Name,
                LastReadingTime = dto.LastReadingTime,
                LastTemperature = dto.LastTemperature,
                Latitude = dto.GpsLat,
                Longitude = dto.GpsLong
            };

        }
    }
}
