# Introduction 
Dette er frontend applikasjonen som er i produksjon. Skrevet i React + Typescript.
Løsningen baserer seg på Open Street Map for kartuderlag og Open Layers for å legge lag på toppen av kartet. Begge er open source og er dermed gratis.  
Løsningen er utviklet mtp. mobile first, dvs. at den først og fremst skal brukes på mobiltelefon. 

Integrasjoner gjøres mot EnTur for henting av busstopp og Points of interest (POI), i tillegg gjøres det kall mot Mirosoft Translator for oversettelse av tekst.
Busstopp hentes ved å kalle EnTur direkte, men de andre kallene går via APIM (Api Management portalen)

Det var ønske om å kunne oversette tekst i løsningen til alle verdens språk. Derfor ble det utviklet logikk for å sende tekst til Microsoft Translator, som er gratis å bruke inntil et visst antall spørringer.
Det er implementert caching for å redusere unødvendige kall. Men det er rom for forbedring da dette ble implementert på slutten av prosjektet som en Proof of concept. 


# Getting Started
For å komme i gang er det kun nødvendig å kjøre npm install. 
Det er ikke satt opp lokal database, så man går rett mot prod. Det er kun leseoperasjoner (Get), så det skal gå greit, men det kan vurderes å sette opp lokal DB ved utvidelse av prosjektet.


# Build and Test
Det er ikke skrevet enhetstester i dette prosjektet. 
