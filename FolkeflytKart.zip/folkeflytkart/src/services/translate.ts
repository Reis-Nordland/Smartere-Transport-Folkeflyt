import axios from "axios";
const { v4: uuidv4 } = require("uuid");

let key = "";
let endpoint = "";

// location, also known as region.
// required if you're using a multi-service or regional (not global) resource. It can be found in the Azure portal on the Keys and Endpoint page.
let location = "norwayeast";

export const translateText = async (text: string, toLanguage = "fr") => {
  const translatedText = await axios.post(
    endpoint + "/translate",
    [
      {
        text: text,
      },
    ],
    {
      headers: {
        "Ocp-Apim-Subscription-Key": key,
        "Ocp-Apim-Subscription-Region": location,
        ContentType: "application/json",
        "X-ClientTraceId": uuidv4().toString(),
      },
      params: {
        "api-version": "3.0",
        from: "no",
        to: [toLanguage],
      },
      responseType: "json",
    }
  );
  return translatedText;
};
