import { Directions } from "./apiTypes";
import { Coordinates } from "../utils/types";
import { stopPlaceIds } from "../data/stopPlaceIds";
export const controller = new AbortController();
const signal = controller.signal;

export interface TransportTimePayload {
  startPos: Coordinates;
  endPos: Coordinates;
  transportMode: TransportMode;
}

export enum TransportMode {
  WALK = "walk",
  BUS = "publictransport",
  BIKE = "bike",
}

const apim_base_url = "https://folkeflyt.azure-api.net";
const apim_key = "695a3b7a16f94a148a592d11406cc39b";

function requestWithKey(url: string) {
  return fetch(url, {
    headers: {
      "Ocp-Apim-Subscription-Key": apim_key,
    },
    signal,
  });
}

function postRequestWithKey(url: string) {
  return fetch(url, {
    method: "POST",
    headers: {
      "Ocp-Apim-Subscription-Key": apim_key,
    },
    signal,
  });
}

async function translateText(textToTranslate: string, toLanguage: string) {
  return postRequestWithKey(
    `${apim_base_url}/folkeflytpoi/translate?textToTranslate=${textToTranslate}&toLanguage=${toLanguage}`
  ).then((response: any) => response.json());
}

function fetchAllPois() {
  return requestWithKey(`${apim_base_url}/folkeflytpoi/api/poi`).then(
    (response: any) => response.json()
  );
}

function fetchTransportTimes(
  payload: TransportTimePayload
): Promise<Directions[]> {
  return requestWithKey(
    `${apim_base_url}/enturreiseplanlegger/Directions?toLat=${payload.endPos.latitude}&toLon=${payload.endPos.longitude}&fromLon=${payload.startPos.longitude}&fromLat=${payload.startPos.latitude}&transportType=${payload.transportMode}`
  ).then((response: any) => response.json());
}

function fetchStopPlaces() {
  return fetch(
    `https://api.entur.io/stop-places/v1/read/stop-places?count=3&ids=${[
      ...stopPlaceIds,
    ]}`
  );
}

export { fetchAllPois, fetchTransportTimes, fetchStopPlaces, translateText };
