import React from "react";
import ArrowBackIosNewIcon from "@mui/icons-material/ArrowBackIosNew";
import DirectionsBikeIcon from "@mui/icons-material/DirectionsBike";
import DirectionsBusIcon from "@mui/icons-material/DirectionsBus";
import DirectionsWalkIcon from "@mui/icons-material/DirectionsWalk";

export enum TransportMode {
  WALK = "walk",
  BUS = "publictransport",
  BIKE = "bike",
}
export enum TransportModeKeys {
  WALK = "walkRoute",
  BUS = "busRoute",
  BIKE = "bikeRoute",
}
const style = {
  root: {
    width: "90%",
    height: "3.8rem",
    top: "0.5rem",
    left: "5%",
    position: "fixed" as "fixed",
    zIndex: 1,
    display: "flex",
    justifyContent: "center" as "center",
    background: "white",
    borderRadius: "0.7rem",
  },
  button: {
    border: "none",
    background: "none",
  },
  backIcon: {
    marginRight: 6,
    color: "black",
  },
  transportIcon: {
    marginRight: 4,
  },
};
interface Props {
  onTransportModeSelected: (
    transportType: TransportMode,
    transportKey: TransportModeKeys
  ) => void;
  selectedTransportMode: TransportMode;
  onBackPressed: () => void;
  showBus: boolean;
  transportRoutes: any;
}

function TransportMenu({
  onTransportModeSelected,
  selectedTransportMode,
  onBackPressed,
  showBus,
  transportRoutes,
}: Props) {
  const handleTransportModeClick = (
    transportType: TransportMode,
    transportModeKey: TransportModeKeys
  ) => {
    if (selectedTransportMode === transportType) {
      return;
    }
    onTransportModeSelected(transportType, transportModeKey);
  };

  const buttonStyle = {
    borderRadius: "0.7rem",
    margin: "auto 0.3rem",
    border: "none",
    height: "90%",
    display: "flex",
    alignItems: "center",
  };
  const renderTransportOption = (
    activeTransportMode: TransportMode,
    transportMode: TransportMode,
    icon: any,
    transportModeKey: TransportModeKeys
  ) => (
    <button
      onClick={() => handleTransportModeClick(transportMode, transportModeKey)}
      style={
        activeTransportMode === transportMode
          ? { background: "#129692", color: "white", ...buttonStyle }
          : { color: "black", background: "none", ...buttonStyle }
      }
    >
      <span style={style.transportIcon}>{icon}</span>
      <span>
        {transportRoutes
          ? `${Math.floor(
              transportRoutes[transportModeKey][0].duration / 60
            )} min`
          : "..."}
      </span>
    </button>
  );

  return (
    <div style={style.root}>
      <button onClick={onBackPressed} style={style.button}>
        <ArrowBackIosNewIcon style={style.backIcon} />
      </button>
      {renderTransportOption(
        selectedTransportMode,
        TransportMode.WALK,
        <DirectionsWalkIcon />,
        TransportModeKeys.WALK
      )}
      {showBus &&
        renderTransportOption(
          selectedTransportMode,
          TransportMode.BUS,
          <DirectionsBusIcon />,
          TransportModeKeys.BUS
        )}
      {renderTransportOption(
        selectedTransportMode,
        TransportMode.BIKE,
        <DirectionsBikeIcon />,
        TransportModeKeys.BIKE
      )}
    </div>
  );
}

export { TransportMenu };
