import React, { useState, useEffect, useContext } from "react";
import {
  Coordinates,
  TransportMode,
  TransportModeKeys,
  Directions,
  Poi,
} from "../../utils/types";
import { fetchTransportTimes } from "../../services/api";
import Popup from "../Popup/popup";
import { TransportMenu } from "./TransportMenu";
import BusLinePopup from "../BusLine/BusLinePopup";
import { createBusLineOptions } from "../BusLine/TransportParser";
import { UtilsContextType, UtilsContext } from "../context/UtilsContext";

export type TransportTimes = { [key in TransportMode]: string };

interface Props {
  currentLocation: Coordinates;
  addPolylineLayer: (
    routes: any,
    showFastestRoute: boolean,
    buslineIndex?: number
  ) => void;
  clearFilter: () => void;
  clickedPoint: Poi;
  setDrawedLine: (active: boolean) => void;
  setShowFilterButton: (show: boolean) => void;
  setWayFinderState: (state: any) => void;
  wayFinderState: any;
  setClickedPoint: (state: any) => void;
}

const WayfindingMenu: React.FC<Props> = ({
  addPolylineLayer,
  clickedPoint,
  setClickedPoint,
  setDrawedLine,
  setShowFilterButton,
  setWayFinderState,
  wayFinderState,
  currentLocation,
}) => {
  const [busRoutes, setBusRoutes] = useState<Directions[]>([]);
  const [loading, setLoading] = useState(false);
  const [fetchingTransportRoutes, setFetchingTransportRoutes] = useState(false);
  const [showBus, setShowBus] = useState<boolean>(false);
  const [showDialog, setShowDialog] = useState<boolean>(false);
  const [transportRoutes, setTransportRoutes] = useState<{
    walkRoute: Directions[];
    bikeRoute: Directions[];
    busRoute: Directions[];
  }>({
    walkRoute: [],
    bikeRoute: [],
    busRoute: [],
  });

  const { language } = useContext(UtilsContext) as UtilsContextType;

  useEffect(() => {
    if (!clickedPoint) {
      return;
    }
    setShowDialog(true);
    setShowBus(true);
  }, [clickedPoint]);

  const fetchAndUpdateTransportTime = async (
    toLocation: Coordinates,
    transportMode: TransportMode,
    drawLine: boolean = false,
    transportKey: TransportModeKeys
  ) => {
    // TODO: Needs CORS to be set on backend to work
    if (
      transportMode === TransportMode.BUS &&
      transportKey === "busRoute" &&
      transportRoutes[transportKey].length === 1
    ) {
      setShowBus(false);
    }
    if (
      transportMode === TransportMode.BUS &&
      transportKey === "busRoute" &&
      drawLine
    ) {
      setBusRoutes(transportRoutes[transportKey]);
    }
    if (drawLine) {
      addPolylineLayer(transportRoutes[transportKey], true);
    }
  };

  const onNewTransportModeSelected = async (
    transportMode: TransportMode,
    key: TransportModeKeys
  ) => {
    setWayFinderState((prevState: any) => ({
      ...prevState,
      selectedTransportMode: transportMode,
    }));
    fetchAndUpdateTransportTime(
      wayFinderState.coordinates,
      transportMode,
      true,
      key
    );
  };

  const startWayFinding = async (toCoordinates: Coordinates) => {
    setLoading(true);
    try {
      await fetchAndUpdateTransportTime(
        toCoordinates,
        TransportMode.BIKE,
        false,
        TransportModeKeys.BIKE
      );
      await fetchAndUpdateTransportTime(
        toCoordinates,
        TransportMode.BUS,
        false,
        TransportModeKeys.BUS
      );
      await fetchAndUpdateTransportTime(
        toCoordinates,
        TransportMode.WALK,
        true,
        TransportModeKeys.WALK
      );
      setWayFinderState({
        active: true,
        toCoordinates: toCoordinates,
        selectedTransportMode: TransportMode.WALK,
      });
    } catch (error: any) {
      console.log(error.msg);
    } finally {
      setLoading(false);
      setShowDialog(false);
      setShowFilterButton(false);
    }
  };

  const onViewingBusLine = (buslineIndex: number) => {
    //TODO: filter out route which only consist of 1 leg and is mode foot
    const filterredRoutes = transportRoutes.busRoute.filter((route) =>
      route.legs.some((leg) => leg.transportMode === "bus")
    );
    addPolylineLayer(filterredRoutes, false, buslineIndex);
  };

  const closeTransportRoute = () => {
    setWayFinderState({ ...wayFinderState, active: false });
    setDrawedLine(false);
    setShowFilterButton(true);
    setClickedPoint(null);
  };

  useEffect(() => {
    if (!clickedPoint.coordinates || !clickedPoint.coordinates.latitude) {
      return;
    }
    setTransportRoutes({
      walkRoute: [],
      bikeRoute: [],
      busRoute: [],
    });
    const walkingTimeReq = fetchTransportTimes({
      endPos: clickedPoint.coordinates,
      startPos: currentLocation,
      transportMode: TransportMode.WALK,
    });
    const bicycleTimeReq = fetchTransportTimes({
      endPos: clickedPoint.coordinates,
      startPos: currentLocation,
      transportMode: TransportMode.BIKE,
    });
    const busTimeReq = fetchTransportTimes({
      endPos: clickedPoint.coordinates,
      startPos: currentLocation,
      transportMode: TransportMode.BUS,
    });

    setFetchingTransportRoutes(true);

    Promise.all([walkingTimeReq, bicycleTimeReq, busTimeReq])
      .then(([walkingRoutesRes, bikeRoutesRes, busRoutesRes]) => {
        setTransportRoutes({
          walkRoute: walkingRoutesRes,
          bikeRoute: bikeRoutesRes,
          busRoute: busRoutesRes,
        });
      })
      .catch((e) => {
        console.log(e);
      })
      .finally(() => {
        setFetchingTransportRoutes(false);
      });

    // eslint-disable-next-line
  }, [clickedPoint?.coordinates]);

  return (
    <>
      {showDialog && (
        <Popup
          clickedPoint={clickedPoint}
          currentLocation={currentLocation}
          onToggleDialog={() => setShowDialog(!showDialog)}
          onWayfindClick={startWayFinding}
          showDialog={showDialog}
          loading={loading}
          setClickedPoint={setClickedPoint}
          setTransportRoutes={setTransportRoutes}
          transportRoutes={transportRoutes}
          fetchingTransportRoutes={fetchingTransportRoutes}
          toCoordinates={{
            longitude: clickedPoint?.coordinates?.longitude,
            latitude: clickedPoint?.coordinates?.latitude,
            error: false,
          }}
        />
      )}

      {wayFinderState.active && (
        <TransportMenu
          showBus={showBus}
          onBackPressed={closeTransportRoute}
          selectedTransportMode={wayFinderState.selectedTransportMode}
          transportRoutes={transportRoutes}
          onTransportModeSelected={(
            transport: TransportMode,
            transportKey: TransportModeKeys
          ) => onNewTransportModeSelected(transport, transportKey)}
        />
      )}
      {wayFinderState.selectedTransportMode === TransportMode.BUS &&
        wayFinderState.active && (
          <BusLinePopup
            busLineOptions={createBusLineOptions(busRoutes, language)}
            onBuslineSelected={(buslineIndex) => {
              onViewingBusLine(buslineIndex);
            }}
          />
        )}
    </>
  );
};

export default WayfindingMenu;
