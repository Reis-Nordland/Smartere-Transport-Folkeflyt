import React, { useContext } from "react";
import Button from "@mui/material/Button";
import ListIcon from "@mui/icons-material/List";
import MapIcon from "@mui/icons-material/Map";
import { UtilsContextType, UtilsContext } from "../context/UtilsContext";

interface Props {
  setShowList: (state: boolean) => void;
  showList: boolean;
}
const ListViewButton: React.FC<Props> = ({ setShowList, showList }) => {
  const style = {
    button: {
      position: "fixed" as "fixed",
      zIndex: 50,
      bottom: "1rem",
      right: "1rem",
      fontSize: "15px",
      background: showList ? "#129692" : "white",
      color: showList ? "white" : "#129692",
      borderRadius: 20,
      boxShadow: "1px 8px 15px rgba(0, 0, 0, 0.2)",
      fontWeight: "bold",
      textTransform: "none" as "none",
      paddingRight: 13,
    },
    listIcon: {
      marginLeft: 4,
    },
    mapIcon: {
      marginLeft: 4,
    },
  };

  const { language } = useContext(UtilsContext) as UtilsContextType;

  const handleButtonClick = () => {
    setShowList(!showList);
  };

  const buttonText = () => {
    if (language === "en") {
      return { mapButtonText: "Map", listButtonText: "List" };
    }
    if (language === "nb") {
      return { mapButtonText: "Kart", listButtonText: "Liste" };
    } else {
      return { mapButtonText: "", listButtonText: "" };
    }
  };
  const buttonIcon = showList ? (
    <MapIcon style={style.mapIcon} />
  ) : (
    <ListIcon style={style.listIcon} />
  );
  return (
    <Button
      onClick={handleButtonClick}
      style={style.button}
      startIcon={buttonIcon}
    >
      {showList ? buttonText().mapButtonText : buttonText().listButtonText}
    </Button>
  );
};

export default ListViewButton;
