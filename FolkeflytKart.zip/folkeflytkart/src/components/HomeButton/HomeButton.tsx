import React, { useContext } from "react";
import HomeIcon from "@mui/icons-material/Home";
import { UtilsContextType, UtilsContext } from "../context/UtilsContext";
import Button from "@mui/material/Button";

const style = {
  button: {
    position: "fixed" as "fixed",
    zIndex: 10,
    bottom: "4rem",
    right: "1rem",
    fontSize: "15px",
    background: "white",
    color: "#129692",
    borderRadius: 20,
    boxShadow: "1px 8px 15px rgba(0, 0, 0, 0.2)",
    fontWeight: "bold",
    textTransform: "none" as "none",
    // paddingRight: 13,
  },
};

interface Props {
  onHomeButtonClick: () => void;
}
const HomeButton: React.FC<Props> = ({ onHomeButtonClick }) => {
  const { language } = useContext(UtilsContext) as UtilsContextType;

  const buttonText = () => {
    if (language === "en") {
      return "Home";
    }
    if (language === "nb") {
      return "Hjem";
    } else {
      return null;
    }
  };
  return (
    <div>
      <Button
        style={style.button}
        startIcon={<HomeIcon />}
        onClick={onHomeButtonClick}
      >
        {buttonText()}
      </Button>
    </div>
  );
};

export default HomeButton;
