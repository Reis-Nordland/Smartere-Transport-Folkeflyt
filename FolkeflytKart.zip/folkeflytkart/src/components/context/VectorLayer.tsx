import React from "react";
import { useContext, useEffect } from "react";
import { MapContext, MapContextType } from "./MapContext";
import OLVectorLayer from "ol/layer/Vector";

interface Props {
  source: any;
  style: any;
  zIndex?: any;
  features?: any;
  type?: any;
}

const VectorLayer: React.FC<Props> = ({
  source,
  features,
  style,
  zIndex = 0,
}) => {
  const { map } = useContext(MapContext) as MapContextType;

  useEffect(() => {
    if (!map) return;
    let vectorLayer = new OLVectorLayer({
      source,
      style,
    });

    map.addLayer(vectorLayer);
    vectorLayer.setZIndex(zIndex);

    return () => {
      if (map) {
        map.removeLayer(vectorLayer);
      }
    };
    // eslint-disable-next-line
  }, [map, features]);
  return <></>;
};

export default VectorLayer;
