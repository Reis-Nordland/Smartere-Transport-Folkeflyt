import React, { useState, createContext, useEffect } from "react";
// import { translateText } from "../../services/translate";
import { PoiType } from "../../utils/types";
import { IconType } from "../FilterButton/CategoryButton";
import {
  activitiesIcon,
  foodIcon,
  cultureIcon,
  natureIcon,
  localProductsIcon,
  transportIcon,
  eventIcon,
} from "../FilterButton/icons";
import { Categories_EN, Categories_NO } from "../../utils/enums";
import { CategoryState } from "../../utils/types";
import { translateText } from "../../services/api";

export type UtilsContextType = {
  language: string;
  setLanguage: (language: string) => void;
  currentFilter: PoiType;
  setCurrentFilter: (filter: PoiType) => void;
  filterCategories: () => {
    text: string;
    type: any;
    iconType: any;
    icon: any;
  }[];
};

interface Props {
  children: React.ReactNode;
}
export const UtilsContext = createContext<UtilsContextType | {}>({});

export const UtilsContextProvider: React.FC<Props> = ({ children }) => {
  const browserLanguage = navigator.language;

  const [language, setLanguage] = useState(
    browserLanguage === "nb-NO" ? "nb" : "en"
  );

  const [currentFilter, setCurrentFilter] = useState(PoiType.No_FILTER);
  const [categories, setCategories] = useState<CategoryState>({
    events: Categories_NO.EVENTS,
    localProducts: Categories_NO.LOCAL_PRODUCTS,
    activities: Categories_NO.ACTIVITIES,
    nature: Categories_NO.NATURE,
    food: Categories_NO.FOOD,
    culture: Categories_NO.CULTURE,
    transport: Categories_NO.Transport,
  });

  const translateCategories = async () => {
    const response = await translateText(
      `${categories.events} | ${categories.localProducts} | ${categories.activities} | ${categories.nature} | ${categories.food} | ${categories.culture} | ${categories.transport}`,
      language
    );
    const listWithTranslatedText = response[0].translations[0].text.split("|");

    const categoryTextFallback = (index: number, fallbackText: string) => {
      return listWithTranslatedText[index] === " "
        ? fallbackText
        : listWithTranslatedText[index];
    };
    setCategories({
      events: categoryTextFallback(0, Categories_EN.EVENTS),
      localProducts: categoryTextFallback(1, Categories_EN.LOCAL_PRODUCTS),
      activities: categoryTextFallback(2, Categories_EN.ACTIVITIES),
      nature: categoryTextFallback(3, Categories_EN.NATURE),
      food: categoryTextFallback(4, Categories_EN.FOOD),
      culture: categoryTextFallback(5, Categories_EN.CULTURE),
      transport: categoryTextFallback(6, Categories_EN.Transport),
    });
  };

  useEffect(() => {
    if (language === "nb") {
      return;
    }
    if (language === "en") {
      setCategories({
        events: Categories_EN.EVENTS,
        localProducts: Categories_EN.LOCAL_PRODUCTS,
        activities: Categories_EN.ACTIVITIES,
        nature: Categories_EN.NATURE,
        food: Categories_EN.FOOD,
        culture: Categories_EN.CULTURE,
        transport: Categories_EN.Transport,
      });
    } else {
      translateCategories();
    }
    sessionStorage.clear();
    // eslint-disable-next-line
  }, [language]);

  const filterCategories = () => [
    {
      text: categories.events,
      type: PoiType.EVENTS,
      iconType: IconType.EVENT,
      icon: eventIcon,
    },
    {
      text: categories.localProducts,
      type: PoiType.LOCAL_PRODUCTS,
      iconType: IconType.LOCAL_PRODUCTS,
      icon: localProductsIcon,
    },
    {
      text: categories.activities,
      type: PoiType.ACTIVITIES,
      iconType: IconType.ACTIVITIES,
      icon: activitiesIcon,
    },
    {
      text: categories.nature,
      type: PoiType.NATURE,
      iconType: IconType.NATURE,
      icon: natureIcon,
    },
    {
      text: categories.food,
      type: PoiType.FOOD,
      iconType: IconType.FOOD,
      icon: foodIcon,
    },
    {
      text: categories.culture,
      type: PoiType.CULTURE,
      iconType: IconType.CULTURE,
      icon: cultureIcon,
    },
    {
      text: categories.transport,
      type: PoiType.TRANSPORT,
      iconType: IconType.TRANSPORT,
      icon: transportIcon,
    },
  ];
  return (
    <UtilsContext.Provider
      value={{
        language,
        setLanguage,
        currentFilter,
        setCurrentFilter,
        filterCategories,
      }}
    >
      {children}
    </UtilsContext.Provider>
  );
};

export default UtilsContext;
