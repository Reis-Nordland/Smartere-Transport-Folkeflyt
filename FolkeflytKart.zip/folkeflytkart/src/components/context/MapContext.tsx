import React, { useEffect, useState, useRef, createContext } from "react";
import * as ol from "ol";
import { fromLonLat } from "ol/proj";

interface Props {
  children: React.ReactNode;
  zoom: any;
  center: any;
  handleClickLocation: (input: any) => void;
  clickedPoint?: any;
}
export const MapContext = createContext<MapContextType | {}>({});

export type MapContextType = {
  map: any;
  centerMap: (latitude: number, longitude: number, zoomLevel: number) => void;
};

export const MapContextProvider: React.FC<Props> = ({
  children,
  zoom,
  center,
  handleClickLocation,
  clickedPoint,
}) => {
  const mapRef = useRef(null);
  const [map, setMap] = useState<any>(null);
  // offset to show marker above popup in viewport
  const offSet = 0.0034;

  let options = {
    view: new ol.View({ zoom, center }),
    layers: [],
    controls: [],
    overlays: [],
  };
  let mapObject = new ol.Map(options);

  useEffect(() => {
    mapObject.setTarget(mapRef.current!);
    setMap(mapObject);
    return () => mapObject.setTarget(undefined);
    // eslint-disable-next-line
  }, []);

  mapObject.on("click", (evt) => {
    mapObject.getProperties();
    const featureOnClick = mapObject.forEachFeatureAtPixel(
      evt.pixel,
      (feature) => {
        return feature;
      }
    );

    if (featureOnClick) {
      const properties = featureOnClick.getProperties().data;
      handleClickLocation(properties);
      map?.getView().setZoom(15);
    }
  });
  useEffect(() => {
    if (!map) return;
    map.getView().setZoom(zoom);
    // eslint-disable-next-line
  }, [zoom]);

  useEffect(() => {
    if (!map) return;
    map.getView().setCenter(center);
    map.getView().setZoom(zoom);
    // eslint-disable-next-line
  }, [zoom, center]);

  useEffect(() => {
    if (!map) return;
    if (!clickedPoint) return;

    if (clickedPoint.centroid) {
    } else {
      map
        .getView()
        .setCenter(
          fromLonLat([
            clickedPoint.coordinates.longitude,
            clickedPoint.coordinates.latitude - offSet,
          ])
        );
    }
    // eslint-disable-next-line
  }, [clickedPoint]);

  const centerMap = (
    latitude: number,
    longitude: number,
    zoomLevel: number
  ) => {
    map.getView().setCenter(fromLonLat([longitude, latitude]));
    map.getView().setZoom(zoomLevel);
  };

  return (
    <MapContext.Provider value={{ map, centerMap }}>
      <div ref={mapRef} style={{ height: "100vh" }}>
        {children}
      </div>
    </MapContext.Provider>
  );
};

export default MapContext;
