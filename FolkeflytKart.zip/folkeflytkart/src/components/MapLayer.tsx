import React, { useEffect } from "react";
import Map from "ol/Map";
import View from "ol/View";
import TileLayer from "ol/layer/Tile";
import Feature from "ol/Feature";
import { fromLonLat } from "ol/proj";
import { Vector as VectorLayer } from "ol/layer";
import { Vector as VectorSource } from "ol/source";
import { Icon, Style } from "ol/style";
import { Point } from "ol/geom";
import OSM from "ol/source/OSM";
import logo192 from "../data/logo192.png";
import { Poi } from "../utils/types";

interface Props {
  points: Poi[];
  handleClickLocation: (feature: any) => void;
}

const MapLayer: React.FC<Props> = ({ points, handleClickLocation }) => {
  const count = points.length;
  const features = new Array(count);

  for (let i = 0; i < count; i++) {
    const longitude = Number(points[i].coordinates.longitude);
    const latitude = Number(points[i].coordinates.latitude);
    const coord = fromLonLat([longitude, latitude]);

    features[i] = new Feature(new Point(coord));
    features[i].setProperties({ data: points[i] });
  }
  const olMap = new Map({
    target: "map",
    layers: [
      new TileLayer({
        source: new OSM(),
      }),
      new VectorLayer({
        source: new VectorSource({
          features: features,
        }),
        style: new Style({
          image: new Icon({
            anchor: [0.5, 46],
            anchorXUnits: "fraction",
            anchorYUnits: "pixels",
            opacity: 0.95,
            src: logo192,
          }),
        }),
      }),
    ],
    view: new View({
      center: fromLonLat([14.387754, 67.280572]),
      zoom: 14,
      constrainResolution: true,
    }),
  });

  olMap.on("click", (evt) => {
    olMap.getProperties();
    const featureOnClick = olMap.forEachFeatureAtPixel(evt.pixel, (feature) => {
      return feature;
    });

    if (featureOnClick) {
      const properties = featureOnClick.getProperties().data;
      handleClickLocation(properties);
    }
  });

  useEffect(() => {
    olMap.setTarget("map");
    return () => olMap.setTarget(undefined);
  }, []);

  return <div id="map" style={{ width: 1000, height: 400 }}></div>;
};

export default MapLayer;
