import React, { useState } from "react";
import Card from "@mui/material/Card";
import CardActions from "@mui/material/CardActions";
import CardContent from "@mui/material/CardContent";
import CardMedia from "@mui/material/CardMedia";
import { Coordinates, Poi } from "../../utils/types";
import { Typography } from "@mui/material";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import ExpandLessIcon from "@mui/icons-material/ExpandLess";
import { calculateDistance } from "../../utils/MapHelpers";
import NearMeIcon from "@mui/icons-material/NearMe";

interface Props {
  point: Poi;
  currentLocation: Coordinates;
}

const style = {
  cardMedia: {
    maxHeight: "80px",
    width: "118px",
    paddingBottom: "10px",
    marginRight: 15,
  },
  CardContentWrapper: {
    display: "flex",
    paddingBottom: 0,
    paddingTop: 10,
    marginBottom: 0,
  },
  icon: {
    color: "#5A5A5A",
    fontSize: 16,
    marginRight: 8,
    marginLeft: 8,
  },
  root: {
    borderRadius: 10,
    margin: "12px auto",
    // width: "92vw",
    padding: 10,
  },
  header: {
    fontSize: 23,
    fontWeight: 600,
    marginLeft: 16,
    marginTop: 6,
  },
  expandIcon: {
    verticalAlign: "text-top",
  },
  expandIconWrapper: {
    textAlign: "center" as "center",
    fontSize: 13,
    color: "#129692",
  },
  descriptionText: {
    fontSize: 13,
    lineHeight: 1.2,
    marginBottom: 6,
  },
};

const PointCard: React.FC<Props> = ({ point, currentLocation }) => {
  const [expandDescription, setExpandDescription] = useState(false);

  const descriptionWordsList = point.description.split(" ");
  const slicedDescriptionList = descriptionWordsList.slice(0, 11);

  const descriptionSubset = slicedDescriptionList.join(" ");
  const descriptionExceedsLimit: boolean = descriptionWordsList.length > 11;
  return (
    <Card style={style.root}>
      <Typography variant="h4" style={style.header}>
        {point.name}
      </Typography>
      <CardContent style={style.CardContentWrapper}>
        {point.pictureLink && point.pictureLink.length !== 0 && (
          <CardMedia
            component="img"
            image={point.pictureLink}
            style={style.cardMedia}
          />
        )}
        <div>
          {/* <Typography style={{ marginBottom: 4, fontSize: 13 }}>
            {point.openingHours
              ? ` ${
                  language === "en" ? text.today_eng : text.today_no
                }: ${point.openingHours[getCurrentDay()].opens.slice(
                  0,
                  2
                )}:${point.openingHours[getCurrentDay()].opens.slice(
                  2
                )} - ${point.openingHours[getCurrentDay()].closes.slice(
                  0,
                  2
                )}:${point.openingHours[getCurrentDay()].closes.slice(2)}`
              : "..."}
          </Typography> */}
          <div onClick={() => setExpandDescription(!expandDescription)}>
            <Typography style={style.descriptionText}>
              {descriptionExceedsLimit && !expandDescription
                ? `${descriptionSubset}...`
                : point.description}
            </Typography>
            {descriptionExceedsLimit && (
              <div style={style.expandIconWrapper}>
                {expandDescription ? "Vis mindre" : "Vis mer"}
                {!expandDescription && (
                  <ExpandMoreIcon style={style.expandIcon} />
                )}
                {expandDescription && (
                  <ExpandLessIcon style={style.expandIcon} />
                )}
              </div>
            )}
          </div>
        </div>
      </CardContent>
      {point.coordinates && (
        <CardActions>
          <NearMeIcon style={style.icon} />
          <span style={{ fontSize: 12 }}>
            {` ${calculateDistance(
              currentLocation.latitude!,
              currentLocation.longitude!,
              point.coordinates.latitude!,
              point.coordinates.longitude!
            ).toFixed(2)} km.`}
          </span>
          {/* <TransportModeTimes
            transportTimes={transportTimes}
            iconSize="small"
            fontSize={12}
            justifyContent="end"
            marginLeft={12}
          /> */}
        </CardActions>
      )}
    </Card>
  );
};

export default PointCard;
