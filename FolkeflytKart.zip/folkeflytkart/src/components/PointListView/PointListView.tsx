import React, { useContext } from "react";
import { Coordinates, Poi } from "../../utils/types";
import { UtilsContext, UtilsContextType } from "../context/UtilsContext";
import PointCard from "./PointCard";
import Card from "@mui/material/Card";
import TuneIcon from "@mui/icons-material/Tune";
import Select, { SelectChangeEvent } from "@mui/material/Select";
import MenuItem from "@mui/material/MenuItem";
import InputLabel from "@mui/material/InputLabel";
import FormControl from "@mui/material/FormControl";
import { PoiType } from "../../utils/types";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import InfoIcon from "@mui/icons-material/Info";

interface Props {
  points: Poi[];
  currentLocation: Coordinates;
  setFilter: (category: any) => void;
}

const style = {
  root: {
    background: "#EDEDED",
    position: "absolute" as "absolute",
    top: 0,
    zIndex: 40,
    width: "100vW",
  },
  card: {
    borderRadius: 22,
    margin: "12px auto",
    marginBottom: "25px",
    // width: "92vw",
    padding: "12px 23px 12px 23px",
  },
};

export const defaultCategories = [
  {
    name_no: "Aktiviteter",
    name_eng: "Activities",
    key: PoiType.ACTIVITIES,
  },
  {
    name_no: "Kultur",
    name_eng: "Culture",
    key: PoiType.CULTURE,
  },
  {
    name_no: "Mat",
    name_eng: "Food",
    key: PoiType.FOOD,
  },
  {
    name_no: "Transport",
    name_eng: "Transport",
    key: PoiType.TRANSPORT,
  },
  {
    name_no: "Shopping",
    name_eng: "Shopping",
    key: PoiType.LOCAL_PRODUCTS,
  },
  {
    name_no: "Natur",
    name_eng: "Nature",
    key: PoiType.NATURE,
  },
  {
    name_no: "Arrangementer",
    name_eng: "Events",
    key: PoiType.EVENTS,
  },
];

const PointListView: React.FC<Props> = ({
  points,
  currentLocation,
  setFilter,
}) => {
  const { language, currentFilter } = useContext(
    UtilsContext
  ) as UtilsContextType;

  const handleChange = (event: SelectChangeEvent) => {
    setFilter(event.target.value as string);
  };

  const listPoints = points.filter((p) => p.type === currentFilter);

  return (
    <div style={style.root}>
      <Card style={style.card}>
        <div style={{ display: "flex" }}>
          <TuneIcon style={{ margin: "auto", color: "#0D8380" }} />
          <FormControl fullWidth>
            <InputLabel id="demo-simple-select-label">Filter</InputLabel>
            <Select
              sx={{
                "& .MuiOutlinedInput-notchedOutline": {
                  border: "none",
                },
              }}
              IconComponent={() => <ExpandMoreIcon></ExpandMoreIcon>}
              labelId="demo-simple-select-label"
              id="demo-simple-select"
              value={currentFilter}
              label="Age"
              onChange={handleChange}
              style={{ color: "#0D8380" }}
            >
              {defaultCategories.map((c, i) => (
                <MenuItem key={i} value={c.key}>
                  {language === "nb" ? c.name_no : c.name_eng}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
        </div>
      </Card>
      {listPoints.length > 0 ? (
        // .filter((p) =>
        //   currentFilter === "events" && p.events ? p : p.type === currentFilter
        // )
        listPoints.map((point: Poi, i: number) => (
          <div key={i}>
            <PointCard point={point} currentLocation={currentLocation} />
          </div>
        ))
      ) : (
        <Card style={style.card}>
          <div style={{ display: "flex" }}>
            <InfoIcon style={{ marginRight: 8 }} />
            {language === "en"
              ? "There are currently no events added to this application."
              : "Det er for øyeblikket ikke lagt inn noen arrangementer i denne løsningen."}
          </div>
        </Card>
      )}
    </div>
  );
};

export default PointListView;
