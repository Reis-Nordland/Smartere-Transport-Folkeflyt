import React, { useContext } from "react";
import { UtilsContextType, UtilsContext } from "../context/UtilsContext";
import { PoiType } from "../../utils/types";
import {
  activitiesIcon,
  cultureIcon,
  foodIcon,
  localProductsIcon,
  natureIcon,
  transportIcon,
} from "./CategoryIcons";

const buttonTextStyle = {
  margin: ".5rem",
};

const categoryButtonStyle = {
  margin: ".4rem",
  display: "inline-flex",
  lineHeight: "1.1rem",
  alignItems: "center",
  padding: ".2em .4em .2em .2em",
  height: "1.75em",
  border: "none",
  width: "auto",
  fontFamily: "Helvetica-Bold, Helvetica",
  borderRadius: "1.2em",
  borderStyle: "solid .5rem black",
  fontSize: "1em",
};

const svgIconStyle = {
  height: "100%",
};

function loadCategoryIcon(type: PoiType) {
  switch (type) {
    case PoiType.ACTIVITIES:
      return activitiesIcon();
    case PoiType.CULTURE:
      return cultureIcon();
    case PoiType.FOOD:
      return foodIcon();
    case PoiType.LOCAL_PRODUCTS:
      return localProductsIcon();
    case PoiType.NATURE:
      return natureIcon();
    case PoiType.TRANSPORT:
      return transportIcon();
    default:
      return transportIcon();
  }
}

export function loadCategoryText(type: PoiType) {
  switch (type) {
    case PoiType.ACTIVITIES:
      return "Aktiviteter";
    case PoiType.CULTURE:
      return "Kultur";
    case PoiType.FOOD:
      return "Mat";
    case PoiType.LOCAL_PRODUCTS:
      return "Shopping";
    case PoiType.NATURE:
      return "Natur";
    case PoiType.TRANSPORT:
      return "Transport";
    default:
      return "";
  }
}
type Props = {
  type: PoiType;
};
function Category(props: Props) {
  const { type } = props;
  const { filterCategories } = useContext(UtilsContext) as UtilsContextType;

  const categoryText = filterCategories().find((c) => c.type === type)?.text;

  return (
    <div key={type} style={categoryButtonStyle}>
      <svg viewBox="0 0 122 122" style={svgIconStyle}>
        {loadCategoryIcon(type)}
      </svg>
      <span style={buttonTextStyle}>{categoryText}</span>
    </div>
  );
}

export default Category;
