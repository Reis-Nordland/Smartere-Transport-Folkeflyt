import React, { useContext } from "react";
import { GreenBusIcon, GreenWalkIcon } from "./Icons";
import "./busLineInstructions.css";
import { TransportMode } from "../../services/api";
import { BuslineSummary } from "./BusLineOptionsList";
import { UtilsContextType, UtilsContext } from "../context/UtilsContext";

export type BuslineStep = {
  legIndex: number;
  type: TransportMode.BUS | TransportMode.WALK;
  description: string;
  info?: string;
};
export interface BuslineProps {
  summary: BuslineSummary;
  steps: BuslineStep[];
}

const style = {
  buslineInfoText: {
    width: "60%",
    fontSize: 17,
    fontWeight: 500,
  },
  busNumberCircle: {
    color: "black",
    background: "#E7E7E7",
    font: "22px Arial, sans-serif",
    borderRadius: 8,
    textAlign: "center" as "center",
    fontWeight: 800,
    minWidth: 57,
    margin: "auto",
    marginLeft: 8,
  },
};

function BuslineIntructions(props: BuslineProps) {
  const { summary, steps = [] } = props;
  const { language } = useContext(UtilsContext) as UtilsContextType;

  return (
    <div
      className="busline-instructions-container"
      style={{
        backgroundPosition: "2.6rem 5rem",
      }}
    >
      <ul>
        <li>
          <div style={{ display: "flex" }}>
            <div style={style.busNumberCircle}>{summary.id}</div>
            <div style={{ marginLeft: 12 }}>
              <h2 style={{ fontSize: 18, fontWeight: 600 }}>
                {language === "nb" ? "Busslinje" : "Bus line"}
              </h2>
              <p style={{ marginTop: 4 }}>
                {summary.leavesAt} <br />
                {summary.timeInterval}
              </p>
            </div>
          </div>
        </li>
        {steps.map((step, index) => (
          <li key={index}>
            {step.type === TransportMode.WALK ? (
              <GreenWalkIcon />
            ) : (
              <GreenBusIcon />
            )}
            <h3 style={style.buslineInfoText}>{step.description}</h3>
            <p className="busline-instructions-item-info">{step.info}</p>
          </li>
        ))}
      </ul>
      <div className="bottom-overlay"></div>
    </div>
  );
}

export default BuslineIntructions;
