import { BuslineOption } from "./BusLinePopup";
import { TransportMode } from "../../services/api";
import { Directions, Leg } from "../../services/apiTypes";
import { BuslineStep } from "./BusLineInstructions";

function createBusLineOptions(
  routes: Directions[],
  language: string
): BuslineOption[] {
  return routes
    .filter((route) => route.legs.some((leg) => leg.transportMode === "bus"))
    .map((busRoute: Directions) => {
      const firstBusInRoute = busRoute.legs.find(
        (leg) => leg?.transportMode === "bus"
      );
      let timeInterval = "";
      let leavesAt = "";
      if (!!firstBusInRoute?.startTime) {
        const startDate = new Date(firstBusInRoute?.startTime);
        timeInterval = `${startDate.getHours()}:${startDate.getMinutes()} - ${startDate.getHours()}:${
          startDate.getMinutes() + Math.ceil(firstBusInRoute.duration / 60)
        }`;
        if (language === "nb") {
          leavesAt = `Går om ${Math.floor(
            Math.abs(startDate.getMinutes() - new Date().getMinutes())
          )} min og tar ${Math.ceil(firstBusInRoute.duration / 60)} min`;
        } else {
          leavesAt = `Leaves in ${Math.floor(
            Math.abs(startDate.getMinutes() - new Date().getMinutes())
          )} min and takes ${Math.ceil(firstBusInRoute.duration / 60)} min`;
        }
      }
      return {
        summary: {
          id: firstBusInRoute?.line || 1, //TODO: Remove this number,
          leavesAt,
          timeInterval,
        },
        steps: createSteps(busRoute.legs, language),
      };
    });
}

function createSteps(legs: Leg[], language: string): BuslineStep[] {
  let previousLeg: Leg | null = null;
  const steps: BuslineStep[] = [];
  let legIndex = 0;
  legs.forEach((leg) => {
    const type =
      leg.transportMode === "bus" ? TransportMode.BUS : TransportMode.WALK;
    if (type === TransportMode.WALK) {
      if (previousLeg?.transportMode === "bus") {
        steps.push({
          type: TransportMode.BUS,
          legIndex: legIndex - 1,
          description: ` ${language === "nb" ? "Stig av på" : "Get off at"} ${
            previousLeg.toPlaceName
          } `,
          info: `${previousLeg.numStops} stopp`,
        });
      }
      steps.push({
        legIndex,
        type: TransportMode.WALK,
        description: `${language === "nb" ? "Gå til" : "Go to"} ${
          leg.toPlaceName
        }`,
        info: `${Math.ceil(leg.duration / 60)} min`,
      });
    } else {
      steps.push({
        type: TransportMode.BUS,
        legIndex,
        description: `${language === "nb" ? "Ta buss" : "Take bus"} ${
          leg.line
        } ${language === "nb" ? "mot" : "to"} ${leg.lineDirection}`,
        info: `${Math.ceil(leg.duration / 60)} min`,
      });
    }
    legIndex++;
    previousLeg = leg;
  });
  return steps;
}
export { createBusLineOptions };
