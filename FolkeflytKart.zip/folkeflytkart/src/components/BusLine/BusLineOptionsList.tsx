import React, { useContext } from "react";
import { BusIcon } from "./Icons";
import "./busLineOptionsList.css";
import { UtilsContext, UtilsContextType } from "../context/UtilsContext";
import NavigateNextIcon from "@mui/icons-material/NavigateNext";
import { Typography } from "@mui/material";
import { text } from "../../utils/language";

export type BuslineSummary = {
  id: number;
  leavesAt: string;
  timeInterval: string;
};
const style = {
  busNumberCircle: {
    color: "black",
    background: "#E7E7E7",
    font: "22px Arial, sans-serif",
    borderRadius: 8,
    textAlign: "center" as "center",
    fontWeight: 800,
    minWidth: 57,
  },
  bustimes: {
    marginLeft: 5,
    marginTop: 0,
    marginBottom: 0,
    // color: "#129692",
    fontSize: 15,
  },
  bustimeText: {
    margin: 0,
    marginLeft: 6,
    color: "#129692",
  },
  busWrapper: {
    display: "flex",
    justifyContent: "space-between",
    marginBottom: 16,
    marginLeft: 4,
    width: "100%",
  },
  listItem: {
    marginBottom: 10,
    marginLeft: 6,
  },
  root: {
    width: "90%",
    padding: 0,
  },
  NavigateNextIcon: {
    color: "#129692",
  },
  header: {
    marginLeft: 18,
    fontSize: 20,
    fontWeight: "bold",
  },
};

interface Props {
  onSelectBusLine: (busLineId: number) => void;
  buslineOptions: BuslineSummary[];
}

function BusLineOptionsList(props: Props) {
  const { onSelectBusLine, buslineOptions = [] } = props;
  const { language } = useContext(UtilsContext) as UtilsContextType;

  const headerText =
    language === "nb" ? text.nextBusHeader_NO : text.nextBusHeader_ENG;

  return (
    <ul className="busline-options-list" style={style.root}>
      <li style={style.listItem}>
        <BusIcon />
        <Typography variant="h3" style={style.header}>
          {headerText}
        </Typography>
      </li>
      {buslineOptions.map((option, index) => (
        <li
          style={style.busWrapper}
          key={index}
          onClick={() => onSelectBusLine(option.id)}
        >
          <Typography style={style.busNumberCircle}>{option.id}</Typography>
          <div>
            <Typography style={style.bustimes}>{option.leavesAt}.</Typography>
            <Typography style={style.bustimeText}>
              {option.timeInterval}
            </Typography>
          </div>
          <div>
            <NavigateNextIcon fontSize="large" style={style.NavigateNextIcon} />
          </div>
        </li>
      ))}
    </ul>
  );
}

export default BusLineOptionsList;
