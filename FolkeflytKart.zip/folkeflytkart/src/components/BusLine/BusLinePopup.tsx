import React, { useState } from "react";
import "./busLinePopup.css";
import { DrawerIcon } from "./Icons";
import BusLineOptionsList, { BuslineSummary } from "./BusLineOptionsList";
import BuslineIntructions, {
  BuslineProps,
  BuslineStep,
} from "./BusLineInstructions";
import Button from "@mui/material/Button";

const style = {
  buttonWrapper: {
    minHeight: 42,
  },
};
export type BuslineOption = {
  summary: BuslineSummary;
  steps: BuslineStep[];
};

interface RouteDescriptorProps {
  busLineOptions: BuslineOption[];
  onBuslineSelected: (buslineIndex: number) => void;
}

function RouteDescriptor(props: RouteDescriptorProps) {
  const { busLineOptions, onBuslineSelected } = props;

  const [collapsed, setCollapsed] = useState(false);

  const [busLineInfo, setbusLineInfo] = useState(null) as [
    BuslineProps | null,
    any
  ];

  const onSelectBusline = (busLineId: number) => {
    const buslineIndex = busLineOptions.findIndex(
      (option) => option.summary.id === busLineId
    );
    setbusLineInfo({
      ...busLineOptions.find((option) => option.summary.id === busLineId),
    });
    onBuslineSelected(buslineIndex);
  };

  return (
    <div className="route-descriptor-wrapper">
      <div className="route-descriptor" style={style.buttonWrapper}>
        <Button
          onClick={() => {
            setCollapsed(!collapsed);
          }}
        >
          <DrawerIcon />
        </Button>
        {!collapsed &&
          (!busLineInfo ? (
            <BusLineOptionsList
              buslineOptions={busLineOptions.map((option) => option.summary)}
              onSelectBusLine={onSelectBusline}
            />
          ) : (
            <BuslineIntructions {...busLineInfo} />
          ))}
      </div>
    </div>
  );
}

export default RouteDescriptor;
