import TuneIcon from "@mui/icons-material/Tune";
import Select, { SelectChangeEvent } from "@mui/material/Select";
import MenuItem from "@mui/material/MenuItem";
import InputLabel from "@mui/material/InputLabel";
import FormControl from "@mui/material/FormControl";
import React, { useState } from "react";
import Card from "@mui/material/Card";
import { defaultCategories } from "../../PointListView/PointListView";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import { PoiType } from "../../../utils/types";

const style = {
  root: {
    background: "#EDEDED",
  },
  card: {
    borderRadius: 22,
    margin: "12px auto",
    marginBottom: "25px",
    // width: "92vw",
    padding: "12px 23px 12px 23px",
  },
};

interface Props {
  onFilter: (poiType: any) => void;
  clearFilter: () => void;
  currentFilter: PoiType;
}

const FilterDropdown: React.FC<Props> = ({
  onFilter,
  clearFilter,
  currentFilter,
}) => {
  const [selectedCategory, setSelectedCategory] = useState("aktiviteter");
  const handleChange = (event: SelectChangeEvent) => {
    setSelectedCategory(event.target.value as string);
    onFilter(event.target.value);
  };
  return (
    <div>
      <div
        style={{
          display: "flex",
          borderRadius: 22,
          // width: "92vw",
          padding: "12px 23px 12px 23px",
          position: "fixed",
          left: "4%",
          top: "2rem",
          zIndex: 1,
          background: "white",
          boxShadow: "1px 8px 15px rgba(0, 0, 0, 0.2)",
        }}
      >
        <TuneIcon style={{ margin: "auto", color: "#0D8380" }} />
        <FormControl fullWidth>
          <InputLabel id="demo-simple-select-label">Filter</InputLabel>
          <Select
            sx={{
              "& .MuiOutlinedInput-notchedOutline": {
                border: "none",
              },
            }}
            IconComponent={() => <ExpandMoreIcon></ExpandMoreIcon>}
            labelId="demo-simple-select-label"
            id="demo-simple-select"
            value={selectedCategory}
            label="Age"
            onChange={handleChange}
            style={{ color: "#0D8380" }}
          >
            {defaultCategories.map((c, i) => (
              <MenuItem key={i} value={c.key}>
                {c.name_no}
              </MenuItem>
            ))}
          </Select>
        </FormControl>
      </div>
    </div>
  );
};

export default FilterDropdown;
