import React, { useState, useContext } from "react";
import CategoryButton from "./CategoryButton";
import { PoiType } from "../../utils/types";
import { filterIcon } from "./icons";
import { UtilsContextType, UtilsContext } from "../context/UtilsContext";

declare type CSSProperties = any;

interface Props {
  onFilter: (poiType: PoiType) => void;
  clearFilter: () => void;
}

const flexColStyle: CSSProperties = {
  display: "flex",
  flexDirection: "column",
  flexGrow: 0,
};

const menuWrapperStyle: CSSProperties = {
  position: "fixed",
  zIndex: 10,
  bottom: "1rem",
  left: "1rem",
  fontSize: "1.25rem",
};

const categoryButtonStyle: CSSProperties = {
  margin: ".4rem",
  display: "inline-flex",
  lineHeight: "1.1rem",
  alignItems: "center",
  padding: ".2em .4em .2em .2em",
  height: "1.75rem",
  // background: "#c5dbdb",
  background: "white",
  border: "none",
  width: "auto",
  fontSize: "1em",
  fontFamily: "Helvetica-Bold, Helvetica",
  borderRadius: "1.2em",
  borderStyle: "solid .5rem black",
};

const svgIconStyle: CSSProperties = {
  height: 23,
  width: 23,
};

const closeButtonStyle = {
  margin: categoryButtonStyle.margin,
  width: categoryButtonStyle.height,
  height: categoryButtonStyle.height,
  padding: categoryButtonStyle.padding,
  border: "none",
  background: "transparent",
  borderRadius: categoryButtonStyle.height,
};

const filterMenuButtons = {
  display: "flex",
};

const buttonTextStyle = {
  margin: ".5rem",
  color: "#088380",
  fontWeight: "bold",
  fontSize: 15,
};

function FilterButton(props: Props) {
  const { onFilter, clearFilter } = props;
  const [open, setOpen] = useState(false);
  const { currentFilter, filterCategories } = useContext(
    UtilsContext
  ) as UtilsContextType;

  const handleClearFilter = () => {
    setOpen(false);
    clearFilter();
  };

  const svgProps = {
    version: "1.1",
    height: "100%",
    // viewBox: "0 0 65.0 65.0",
    viewBox: "0 0 122 122",
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
  };
  const eventIconFilterProps = {
    height: 20,
    width: 20,
    viewBox: "0 0 65.0 65.0",
  };

  const FilterDisplay = () => {
    return (
      <div style={filterMenuButtons}>
        <button onClick={() => setOpen(true)} style={categoryButtonStyle}>
          {filterCategories()
            .find((t) => t.type === currentFilter)
            ?.icon(
              currentFilter === PoiType.EVENTS ? eventIconFilterProps : svgProps
            ) || filterIcon()}
          <span style={buttonTextStyle}>
            {filterCategories().find((t) => t.type === currentFilter)?.text ||
              "Filter"}
          </span>
        </button>
        {/* {currentFilter !== PoiType.No_FILTER && (
          <button style={closeButtonStyle} onClick={handleClearFilter}>
            <svg
              style={svgIconStyle}
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 41 41"
              fill="none"
            >
              <circle
                cx="20.5"
                cy="20.5"
                r="20"
                fill="#D8D8D8"
                stroke="#979797"
              />
              <path
                d="M11.5586 28.9662L29.0008 11.5537"
                stroke="#1A1A1A"
                strokeWidth="6.25"
                strokeLinecap="round"
              />
              <path
                d="M11.5586 11.5537L29.0008 28.9662"
                stroke="#1A1A1A"
                strokeWidth="6.25"
                strokeLinecap="round"
              />
            </svg>
          </button>
        )} */}
      </div>
    );
  };

  return (
    <div style={menuWrapperStyle}>
      {open ? (
        <div style={flexColStyle}>
          <button style={closeButtonStyle} onClick={() => setOpen(false)}>
            <svg
              style={svgIconStyle}
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 41 41"
              fill="none"
            >
              <circle
                cx="20.5"
                cy="20.5"
                r="20"
                fill="#D8D8D8"
                stroke="#979797"
              />
              <path
                d="M11.5586 28.9662L29.0008 11.5537"
                stroke="#1A1A1A"
                strokeWidth="6.25"
                strokeLinecap="round"
              />
              <path
                d="M11.5586 11.5537L29.0008 28.9662"
                stroke="#1A1A1A"
                strokeWidth="6.25"
                strokeLinecap="round"
              />
            </svg>
          </button>
          {filterCategories().map(({ text, type, iconType }, i) => (
            <div key={i}>
              <CategoryButton
                text={text}
                type={type}
                icon={iconType}
                onClick={() => {
                  setOpen(false);
                  onFilter(type);
                }}
              />
            </div>
          ))}
        </div>
      ) : (
        <FilterDisplay />
      )}
    </div>
  );
}

export { FilterButton };
