import React from "react";
import { PoiType } from "../../utils/types";
import {
  activitiesIcon,
  cultureIcon,
  defaultIcon,
  foodIcon,
  localProductsIcon,
  natureIcon,
  transportIcon,
  eventIcon,
} from "./icons";

declare type CSSProperties = any;

const buttonTextStyle = {
  margin: ".5rem",
  color: "black",
};

export type FilteCategory = {
  text: string;
  type: PoiType;
  icon: IconType;
  width?: number;
};

export type CategoryButtonProps = { onClick: () => void } & FilteCategory;
export enum IconType {
  ACTIVITIES,
  CULTURE,
  FOOD,
  NATURE,
  LOCAL_PRODUCTS,
  TRANSPORT,
  EVENT,
  DEFAULT,
}

function loadIcon(icon: IconType, props?: any) {
  const eventProps = {
    width: 30,
    height: 30,
    viewBox: "0 0 61.0 61.0",
  };
  const transportProps = {
    width: 30,
    height: 30,
    viewBox: "0 0 110 110",
  };
  switch (icon) {
    case IconType.ACTIVITIES:
      return activitiesIcon(props);
    case IconType.CULTURE:
      return cultureIcon(props);
    case IconType.FOOD:
      return foodIcon(props);
    case IconType.LOCAL_PRODUCTS:
      return localProductsIcon(props);
    case IconType.NATURE:
      return natureIcon(props);
    case IconType.TRANSPORT:
      return transportIcon(transportProps);
    case IconType.EVENT:
      return eventIcon(eventProps);
    default:
      return defaultIcon();
  }
}

function CategoryButton(props: CategoryButtonProps) {
  const { text, type, icon, onClick, width } = props;

  const categoryButtonStyle: CSSProperties = {
    margin: ".4rem",
    display: "inline-flex",
    lineHeight: "1.1rem",
    alignItems: "center",
    padding: ".2em .4em .2em .2em",
    height: "1.90em",
    background: "#c5dbdb",
    border: "none",
    width: width || "auto",

    fontFamily: "Helvetica-Bold, Helvetica",
    borderRadius: "1.2em",
    borderStyle: "solid .5rem black",
    fontSize: "1em",
    "&:hover": {
      background: "yellow",
      color: "black",
    },
  };

  const svgProps = {
    version: "1.1",
    height: "100%",
    // viewBox: "0 0 65.0 65.0",
    viewBox: "0 0 122 122",
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
  };

  return (
    <button key={type} style={categoryButtonStyle} onClick={onClick}>
      {/* <svg viewBox="0 0 122 122" style={svgIconStyle}> */}
      {loadIcon(icon, svgProps)}
      {/* </svg> */}

      <span style={buttonTextStyle}>{text}</span>
    </button>
  );
}

export default CategoryButton;
