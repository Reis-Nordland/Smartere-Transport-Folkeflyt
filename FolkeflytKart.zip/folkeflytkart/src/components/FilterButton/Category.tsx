import React, { useContext } from "react";
import { PoiType } from "../../utils/types";
import {
  activitiesIcon,
  cultureIcon,
  defaultIcon,
  foodIcon,
  localProductsIcon,
  natureIcon,
  transportIcon,
} from "../FilterButton/icons";
import { UtilsContext, UtilsContextType } from "../context/UtilsContext";
import { loadCategoryText } from "../Categories/Categories";
declare type CSSProperties = any;
const buttonTextStyle = {
  margin: ".5rem",
};

const categoryButtonStyle: CSSProperties = {
  margin: ".4rem",
  display: "inline-flex",
  lineHeight: "1.1rem",
  alignItems: "center",
  padding: ".2em .4em .2em .2em",
  height: "1.75em",
  border: "none",
  width: "auto",
  fontFamily: "Helvetica-Bold, Helvetica",
  borderRadius: "1.2em",
  borderStyle: "solid .5rem black",
  fontSize: "1em",
};

const svgIconStyle: CSSProperties = {
  height: "100%",
};

function loadCategoryIcon(type: PoiType, props: any) {
  switch (type) {
    case PoiType.ACTIVITIES:
      return activitiesIcon(props);
    case PoiType.CULTURE:
      return cultureIcon(props);
    case PoiType.FOOD:
      return foodIcon(props);
    case PoiType.LOCAL_PRODUCTS:
      return localProductsIcon(props);
    case PoiType.NATURE:
      return natureIcon(props);
    case PoiType.TRANSPORT:
      return transportIcon(props);
    default:
      return defaultIcon();
  }
}

type Props = {
  type: PoiType;
};

const svgProps = {
  version: "1.1",
  height: "100%",
  viewBox: "0 0 65.0 65.0",
  xmlns: "http://www.w3.org/2000/svg",
  xmlnsXlink: "http://www.w3.org/1999/xlink",
};
function Category(props: Props) {
  const { type } = props;
  const { language } = useContext(UtilsContext) as UtilsContextType;
  return (
    <div key={type} style={categoryButtonStyle}>
      {loadCategoryIcon(type, svgProps)}
      <span style={buttonTextStyle}>{loadCategoryText(type)}</span>
    </div>
  );
}

export default Category;
