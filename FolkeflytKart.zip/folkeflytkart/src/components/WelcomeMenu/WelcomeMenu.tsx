import React, { useContext, useEffect, useState } from "react";
import { PoiType } from "../../utils/types";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import Slide from "@mui/material/Slide";
import CardMedia from "@mui/material/CardMedia";
import { UtilsContextType, UtilsContext } from "../context/UtilsContext";
import { text } from "../../utils/language";
import DialogTitle from "@mui/material/DialogTitle";
import Dialog from "@mui/material/Dialog";
import LanguageOptions from "./LanguageOptions";
import DialogContent from "@mui/material/DialogContent";
import IconButton from "@mui/material/IconButton";
import CloseIcon from "@mui/icons-material/Close";
import HelpOutlineIcon from "@mui/icons-material/HelpOutline";
// import { translateText } from "../../services/translate";
import CategoryOptions from "./CategoryOptions";
import { translateText } from "../../services/api";

const style = {
  cardContainer: {
    position: "fixed" as "fixed",
    top: 20,
    zIndex: 1001,
    height: "70vh",
    width: "100vw",
    boxShadow: "none",
    backgroundColor: "rgba(255,255,255,0.0)",
    display: "flex",
    alignItems: "center",
  },
  infoCard: {
    fontSize: "1.5rem",
    backgroundColor: "rgba(255,255,255,0.5)",
    borderRadius: "29px",
    marginBottom: "10px",
    maxWidth: "90vw",
  },
  innerContainer: {
    margin: "auto",
    maxWidth: "90vw",
    display: "flex",
    alignItems: "center",
  },
  content: {
    backgroundColor: "#193E47",
    color: "#ffffff",
    fontSize: 20,
    textAlign: "center" as "center",
    height: 555,
  },
  header: {
    color: "#BFDCDC",
    fontSize: 20,
    marginTop: 10,
  },
  closeButton: {
    position: "absolute" as "absolute",
    right: "0.5rem",
    top: "0.5rem",
    color: "grey",
  },
  aboutWrapper: {
    color: "#BFDCDC",
    fontSize: 15,
    marginTop: 15,
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
  },
};

interface Props {
  onFilter: (poiType: PoiType) => void;
  clearFilter: () => void;
  showWelcomeMenu: boolean;
  setShowWelcomeMenu: (state: boolean) => void;
}

const WelcomeMenu = (props: Props) => {
  const { onFilter, showWelcomeMenu, setShowWelcomeMenu } = props;
  const { language } = useContext(UtilsContext) as UtilsContextType;

  const [openDialog, setOpenDialog] = useState(false);
  const [contentText, setcontentText] = useState({
    cityGuideTitle: "",
    welcomeText: "",
    infoText: "",
  });

  useEffect(() => {
    if (language === "en" || language === "nb") {
      setcontentText({
        cityGuideTitle:
          language === "en"
            ? text.welcomePageText.cityGuide_ENG
            : text.welcomePageText.cityGuide,
        welcomeText:
          language === "en" ? text.welcomeText_ENG : text.welcomeText_NO,
        infoText:
          language === "en"
            ? text.welcomePageText.whatIsThis_ENG
            : text.welcomePageText.whatIsThis,
      });
    } else {
      translateTexts();
    }
    // eslint-disable-next-line
  }, [language]);

  const handleClose = () => {
    setOpenDialog(false);
  };
  const handleClickFilter = (type: PoiType) => {
    onFilter(type);
    setShowWelcomeMenu(false);
  };

  const translateTexts = async () => {
    const response = await translateText(
      `${text.welcomePageText.cityGuide} | ${text.welcomePageText.whatDoYouWantToSee} | ${text.welcomePageText.whatIsThis}`,
      language
    );
    const listWithTranslatedText = response[0].translations[0].text.split("|");

    setcontentText({
      cityGuideTitle: listWithTranslatedText[0],
      welcomeText: listWithTranslatedText[1],
      infoText: listWithTranslatedText[2],
    });
  };

  return (
    <Slide direction="up" in={showWelcomeMenu} mountOnEnter unmountOnExit>
      <div style={style.cardContainer}>
        <div style={style.innerContainer}>
          <Card style={style.infoCard}>
            <CardMedia
              component="img"
              height="60"
              src={require("../../data/headerlogo.png")}
            />

            <CardContent style={style.content}>
              <LanguageOptions />
              <p style={style.header}>{contentText.cityGuideTitle}</p>
              <p style={{ textAlign: "center" }}>{contentText.welcomeText}</p>
              <CategoryOptions handleClickFilter={handleClickFilter} />
              <div
                style={style.aboutWrapper}
                onClick={() => setOpenDialog(true)}
              >
                <HelpOutlineIcon style={{ height: 20 }} />
                {contentText.infoText}
              </div>
              <Dialog open={openDialog} onClose={handleClose}>
                <DialogTitle>
                  {language === "nb" ? "Om" : "About"}
                  <IconButton
                    id="closeDialog"
                    aria-label="close"
                    style={style.closeButton}
                    onClick={handleClose}
                  >
                    <CloseIcon />
                  </IconButton>
                </DialogTitle>
                <DialogContent>
                  {language === "nb" ? text.aboutText_NO : text.aboutText_ENG}
                  <br></br>
                </DialogContent>
              </Dialog>
              <br></br>
            </CardContent>
          </Card>
        </div>
      </div>
    </Slide>
  );
};

export default WelcomeMenu;
