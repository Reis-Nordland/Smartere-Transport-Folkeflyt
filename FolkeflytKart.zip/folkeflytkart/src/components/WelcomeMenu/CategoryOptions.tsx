import React, { useContext } from "react";
import { UtilsContextType, UtilsContext } from "../context/UtilsContext";
import CategoryButton from "../FilterButton/CategoryButton";

interface Props {
  handleClickFilter: (type: any) => void;
}

const CategoryOptions: React.FC<Props> = ({ handleClickFilter }) => {
  const { filterCategories } = useContext(UtilsContext) as UtilsContextType;

  return (
    <div>
      {filterCategories().map(({ text, type, iconType }, i) => (
        <div key={i}>
          <CategoryButton
            text={text}
            type={type}
            icon={iconType}
            onClick={() => handleClickFilter(type)}
            width={250}
          />
        </div>
      ))}
    </div>
  );
};

export default CategoryOptions;
