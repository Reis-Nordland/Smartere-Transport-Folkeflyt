import React, { useContext, useState } from "react";
import { UtilsContextType, UtilsContext } from "../context/UtilsContext";
import LanguageIcon from "@mui/icons-material/Language";
import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogTitle from "@mui/material/DialogTitle";
import OutlinedInput from "@mui/material/OutlinedInput";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";
import { languages } from "../../utils/languages";
const style = {
  language: {
    textAlign: "left" as "left",
    fontSize: 15,
    marginLeft: 40,
    display: "flex",
    alignItems: "center",
  },
};
const LanguageOptions = () => {
  const { language, setLanguage } = useContext(
    UtilsContext
  ) as UtilsContextType;

  const [open, setOpen] = useState(false);

  const handleClickMenu = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  const handleChange = (event: any) => {
    const { value } = event.target;
    setLanguage(value);
  };
  return (
    <div style={style.language}>
      <LanguageIcon
        style={{
          color: "#BFDCDC",
          width: 17,
          marginRight: 4,
        }}
        onClick={handleClickMenu}
      />
      {/* <span
        style={{
          color: "#BFDCDC",
        }}
        onClick={() => setLanguage("nb")}
      >
        {language}
      </span> */}
      {/* {language === "nb" && (
        <>
          <span
            style={{
              color: "#BFDCDC",
            }}
            onClick={() => setLanguage("en")}
          >
            English
          </span>
        </>
      )} */}
      <Dialog disableEscapeKeyDown open={open} onClose={handleClose}>
        <DialogTitle>Select language</DialogTitle>
        <DialogContent>
          <Box component="form" sx={{ display: "flex", flexWrap: "wrap" }}>
            <FormControl sx={{ m: 1, minWidth: 120 }}>
              <Select
                native
                value={language}
                onChange={handleChange}
                input={<OutlinedInput id="dialog" />}
              >
                {languages.map((l, i) => (
                  <option key={i} value={l.code}>
                    {l.name}
                  </option>
                ))}
              </Select>
            </FormControl>
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose}>Ok</Button>
        </DialogActions>
      </Dialog>
    </div>
  );
};
export default LanguageOptions;
