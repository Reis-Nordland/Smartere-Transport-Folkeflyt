import React, { useContext, useEffect, useState } from "react";
import Chip from "@mui/material/Chip";
import { PoiType } from "../../utils/types";
import { UtilsContextType, UtilsContext } from "../context/UtilsContext";

interface Props {
  features: any;
  getPoiType: (type: any) => {
    icon: any;
    style: {
      background: string;
      color: string;
    };
  };
  handleClickLocation: (data: Object) => void;
}

const ChipsMenu: React.FC<Props> = ({
  features,
  getPoiType,
  handleClickLocation,
}) => {
  const { currentFilter } = useContext(UtilsContext) as UtilsContextType;
  const visibleChipsCount = 7;
  const [visibleChips, setVisibleChips] = useState(visibleChipsCount);
  const [expandedChipsList, setExpandedChipsList] = useState(false);
  const allLocationChips = features.filter((c: any) => {
    if (currentFilter === PoiType.EVENTS) {
      // return c.getProperties().data.events;
      return null;
    } else {
      return c.getProperties().data.type === currentFilter;
    }
  });

  useEffect(() => {
    setExpandedChipsList(false);
    setVisibleChips(visibleChipsCount);
  }, [currentFilter]);

  const chipsCount = allLocationChips.length;

  const handleExpandClick = () => {
    setExpandedChipsList(true);
    setVisibleChips(chipsCount);
  };
  const handleCollapseClick = () => {
    setExpandedChipsList(false);
    setVisibleChips(visibleChipsCount);
  };

  const expandChipsColor = (currentFilter: any) => {
    switch (currentFilter) {
      case "events":
        return {
          background: "#FED644",
          color: "black",
        };
      case "lokale_produkter":
        return { background: "#895FC6", color: "white" };
      case "natur":
        return { background: "#92D355", color: "black" };
      case "mat":
        return { background: "#F68D9B", color: "black" };
      case "kultur":
        return { background: "#F8C81B", color: "black" };
      case "aktiviteter":
        return { background: "#0CBAD9", color: "black" };
      case "transport":
        return { background: "#438A88", color: "white" };
    }
  };
  return (
    <div
      style={{
        position: "fixed",
        zIndex: 10,
        top: "1rem",
        left: "1rem",
      }}
    >
      {allLocationChips.slice(0, visibleChips).map((f: any, i: number) => (
        <Chip
          key={i}
          style={
            currentFilter === "events"
              ? {
                  marginRight: 4,
                  marginBottom: 4,
                  border: " 1px solid grey",
                  background: "#FED644",
                  color: "black",
                }
              : {
                  marginRight: 4,
                  marginBottom: 4,
                  border: " 1px solid grey",
                  ...getPoiType(f.getProperties().data.type).style,
                }
          }
          label={f.getProperties().data.name}
          color="primary"
          onClick={() => handleClickLocation(f.getProperties().data)}
        />
      ))}
      {expandedChipsList && (
        <Chip
          color="primary"
          style={{
            fontSize: 15,
            border: " 1px solid grey",
            fontWeight: 700,
            ...expandChipsColor(currentFilter),
          }}
          label="<"
          onClick={handleCollapseClick}
        />
      )}
      {chipsCount > visibleChips && (
        <Chip
          style={{
            fontSize: 15,
            fontWeight: 700,
            border: " 1px solid grey",
            ...expandChipsColor(currentFilter),
          }}
          label="..."
          onClick={handleExpandClick}
        />
      )}
    </div>
  );
};

export default ChipsMenu;
