import React, { useContext, useEffect, useState } from "react";
import Card from "@mui/material/Card";
import CardHeader from "@mui/material/CardHeader";
import CardActions from "@mui/material/CardActions";
import IconButton from "@mui/material/IconButton";
import Button from "@mui/material/Button";
import Slide from "@mui/material/Slide";
import { Coordinates } from "../../utils/types";
import Category from "../Categories/Categories";
import { Poi, Directions } from "../../utils/types";
import CloseIcon from "@mui/icons-material/Close";
import { text } from "../../utils/language";
import { UtilsContextType, UtilsContext } from "../context/UtilsContext";
import { MapContext, MapContextType } from "../context/MapContext";
import CircularProgress from "@mui/material/CircularProgress";
import PopupContent from "./PopupContent";
import { decode } from "@googlemaps/polyline-codec";
// import { controller } from "../../services/api";
import PopupContentForBusStop from "./PopupContentForBusStop";
// import { translateText } from "../../services/translate";
import { translateText } from "../../services/api";

interface Props {
  showDialog: boolean;
  onWayfindClick: (coordinates: Coordinates) => void;
  currentLocation: Coordinates;
  toCoordinates: Coordinates;
  loading: boolean;
  onToggleDialog: (showDialog: boolean) => void;
  setClickedPoint: (state: any) => void;
  clickedPoint: Poi;
  setTransportRoutes: (state: any) => void;
  transportRoutes: {
    walkRoute: Directions[];
    bikeRoute: Directions[];
    busRoute: Directions[];
  };
  fetchingTransportRoutes: boolean;
}

const Popup: React.FC<Props> = ({
  showDialog,
  onToggleDialog,
  fetchingTransportRoutes,
  onWayfindClick,
  toCoordinates,
  currentLocation,
  clickedPoint,
  setClickedPoint,
  loading,
  transportRoutes,
}) => {
  const isBusStopPoint = clickedPoint.pictureLink === undefined;
  const style = {
    button: {
      background: "#0D8380",
      color: "white",
      borderRadius: "30px",
      fontWeight: "bold",
      fontSize: "1.2em",
      boxShadow: "none",
      padding: "10px 40px 8px 40px",
      minWidth: 231,
      height: 52,
    },
    card: {
      minWidth: "275",
      background: "#EDE9ED",
      position: "fixed" as "fixed",
      bottom: 0,
      borderRadius: "29px 29px 0px 0px",
      zIndex: 1001,
      height: isBusStopPoint ? "20vh" : "60vh",
      width: "100vw",
    },
    cardActions: {
      display: "flex",
      flexDirection: "column" as "column",
      alignItems: "center" as "center",
      justifyContent: "center" as "center",
      height: 50,
    },
    cardHeader: {
      paddingBottom: 0,
    },
  };
  const { type, description } = clickedPoint;
  const [translatedText, setTranslatedText] = useState({
    translatedDescription: description,
    wayfindingButtonText: text.wayfindButtonText_no,
  });

  const { language } = useContext(UtilsContext) as UtilsContextType;
  const { centerMap } = useContext(MapContext) as MapContextType;

  const fallbackButtonText = text.wayfindButtonText_eng;
  const handleWayfindingClick = () => {
    onWayfindClick(toCoordinates);
    calculateCenterBetweenPoints();
  };

  const translateDescription = async () => {
    if (sessionStorage.getItem(clickedPoint.name) === null) {
      const percentEncodedDescription = description.includes("&")
        ? description.replace("&", "%26")
        : description;
      const response = await translateText(
        `${percentEncodedDescription} | ${text.wayfindButtonText_no}`,
        language
      );
      const listWithTranslatedText =
        response[0].translations[0].text.split("|");
      setTranslatedText({
        translatedDescription: listWithTranslatedText[0],
        wayfindingButtonText: listWithTranslatedText[1],
      });
      sessionStorage.setItem(
        clickedPoint.name,
        response[0].translations[0].text
      );
    } else {
      const cachedText = sessionStorage.getItem(clickedPoint.name);
      const formattedText = cachedText?.split("|");
      setTranslatedText({
        translatedDescription: formattedText ? formattedText[0] : "",
        wayfindingButtonText: formattedText ? formattedText[1] : "",
      });
    }
  };

  useEffect(() => {
    if (language === "nb") {
      return;
    } else {
      translateDescription();
    }
    //eslint-disable-next-line
  }, [clickedPoint]);

  const calculateCenterBetweenPoints = () => {
    let zoomLevel = 13.5;
    // const zoomThreshold = 0.3;

    const zoomThreshold = {
      min: 0.05,
      medium: 0.15,
      max: 0.3,
    };

    const coordinatesList = decode(
      transportRoutes.walkRoute[0].legs[0].polyLine.code
    );
    const latitudeList = coordinatesList.map((coords) => coords[0]);
    const longitudeList = coordinatesList.map((coords) => coords[1]);

    const toMaxLatitudeInPolyline = Math.max(...latitudeList);
    // const toMinLatitudeInPolyline = Math.min(...latitudeList);
    const toMaxLongitudeInPolyline = Math.max(...longitudeList);
    const toMinLongitudeInPolyline = Math.min(...longitudeList);

    let toDestionationLongitude = 0;
    if (toCoordinates.longitude! > currentLocation.longitude!) {
      toDestionationLongitude = toMaxLongitudeInPolyline;
    } else if (toCoordinates.longitude! < currentLocation.longitude!) {
      toDestionationLongitude = toMinLongitudeInPolyline;
    }

    //TODO: Do the same procedure for latitude in case point is far north/south
    const diffLongitude = Math.abs(
      currentLocation.longitude! - toDestionationLongitude
    );

    if (diffLongitude > zoomThreshold.max) {
      zoomLevel = 10;
    }
    if (
      diffLongitude > zoomThreshold.medium &&
      diffLongitude < zoomThreshold.max
    ) {
      zoomLevel = 11;
    }
    if (
      diffLongitude > zoomThreshold.min &&
      diffLongitude < zoomThreshold.medium
    ) {
      zoomLevel = 12.5;
    }

    const averageLatitude =
      (currentLocation.latitude! + toMaxLatitudeInPolyline) / 2;
    const averageLongitude =
      (currentLocation.longitude! + toDestionationLongitude) / 2;

    centerMap(averageLatitude, averageLongitude, zoomLevel);
  };

  const handleClosePopup = () => {
    onToggleDialog(!showDialog);
    setClickedPoint(null);
    // controller.abort();
  };

  return (
    <Slide direction="up" in={showDialog} mountOnEnter unmountOnExit>
      <Card style={style.card}>
        <>
          <CardHeader
            style={style.cardHeader}
            avatar={<Category type={type} />}
            action={
              <IconButton onClick={handleClosePopup}>
                <CloseIcon />
              </IconButton>
            }
          />
          {!isBusStopPoint ? (
            <PopupContent
              clickedPoint={clickedPoint}
              transportRoutes={transportRoutes}
              fetchingTransportRoutes={fetchingTransportRoutes}
              translatedDescription={translatedText.translatedDescription}
            />
          ) : (
            <PopupContentForBusStop clickedPoint={clickedPoint} />
          )}

          {!isBusStopPoint && (
            <CardActions style={style.cardActions}>
              {!fetchingTransportRoutes && transportRoutes.busRoute.length > 0 && (
                <Button
                  variant="contained"
                  style={
                    language === "en"
                      ? { ...style.button, width: 273.5 }
                      : style.button
                  }
                  onClick={handleWayfindingClick}
                >
                  {loading ? (
                    <CircularProgress color="inherit" size={30} />
                  ) : (
                    translatedText.wayfindingButtonText || fallbackButtonText
                  )}
                </Button>
              )}
            </CardActions>
          )}
        </>
      </Card>
    </Slide>
  );
};

export default Popup;
