import React from "react";
import { Poi } from "../../utils/types";
import { Typography } from "@mui/material";

interface Props {
  clickedPoint: Poi;
}

const EventList: React.FC<Props> = ({ clickedPoint }) => {
  return (
    <div>
      {clickedPoint.events && (
        <div style={{ marginLeft: 20, marginRight: 20 }}>
          <Typography
            style={{ fontWeight: "bold", marginTop: 10, marginLeft: 10 }}
          >
            Kulturnatt 2022
          </Typography>
          {clickedPoint.events.map((e, key) => (
            <div
              key={key}
              style={{ display: "table", clear: "both", width: 250 }}
            >
              <div
                style={{
                  float: "left",
                  width: "20%",
                  paddingLeft: 10,
                  paddingBottom: 10,
                }}
              >
                {e.startTime}
              </div>
              <div
                style={{
                  float: "left",
                  width: "80%",
                  paddingLeft: 10,
                  paddingBottom: 10,
                }}
              >
                {e.name}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default EventList;
