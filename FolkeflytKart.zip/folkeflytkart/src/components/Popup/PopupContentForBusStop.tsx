import React from "react";
import CardContent from "@mui/material/CardContent";
import DirectionsBusIcon from "@mui/icons-material/DirectionsBus";
import { Typography } from "@mui/material";

const style = {
  content: {
    display: "flex",
    flexDirection: "column" as "column",
    alignItems: "center",
    justifyContent: "center",
    paddingTop: 0,
  },
};

interface Props {
  clickedPoint: any;
}
const PopupContentForBusStop: React.FC<Props> = ({ clickedPoint }) => {
  return (
    <CardContent style={style.content}>
      <Typography style={{ marginBottom: 16 }}>
        {clickedPoint.name.value}
      </Typography>
      <DirectionsBusIcon style={{ width: 50 }} />
    </CardContent>
  );
};

export default PopupContentForBusStop;
