import React, { useContext, useState } from "react";
import ArrowDropDownIcon from "@mui/icons-material/ArrowDropDown";
import ArrowDropUpIcon from "@mui/icons-material/ArrowDropUp";
import { text } from "../../utils/language";
import LinkIcon from "@mui/icons-material/Link";
import OpenInNewIcon from "@mui/icons-material/OpenInNew";
import { UtilsContextType, UtilsContext } from "../context/UtilsContext";

const style = {
  iconWrapper: {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-around",
    width: "100%",
  },
  outlinedText: {
    color: "black",
  },
  apningstider: {
    marginBottom: "4px",
    marginTop: 8,
    color: "#0D8380",
  },
  alignText: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
  },
  openingHourWrapper: {
    marginBottom: 6,
    textAlign: "center" as "center",
  },
};

const dayMapper = [
  { name: "Mandag", key: "monday" },
  { name: "Tirsdag", key: "tuesday" },
  { name: "Onsdag", key: "wednesday" },
  { name: "Torsdag", key: "thursday" },
  { name: "Fredag", key: "friday" },
  { name: "Lørdag", key: "saturday" },
  { name: "Søndag", key: "sunday" },
];

const getCurrentDay = () => {
  const currentDay = new Date().getDay();
  switch (currentDay) {
    case 0:
      return "sunday";
    case 1:
      return "monday";
    case 2:
      return "tuesday";
    case 3:
      return "wednesday";
    case 4:
      return "thursday";
    case 5:
      return "friday";
    case 6:
      return "saturday";
    default:
      return "monday";
  }
};

interface Props {
  openingHours: any;
}
const OpeningHours: React.FC<Props> = ({ openingHours }) => {
  const [expandedDateList, setExpandedDateList] = useState(false);

  const { language } = useContext(UtilsContext) as UtilsContextType;

  return (
    <div style={style.openingHourWrapper}>
      <p style={style.apningstider}>
        {language === "en" ? text.openingHours_eng : text.openingHours_no}
      </p>
      <span
        onClick={() => setExpandedDateList(!expandedDateList)}
        style={{ display: "flex" }}
      >
        {!!openingHours
          ? ` ${
              language === "en" ? text.today_eng : text.today_no
            }: ${openingHours[getCurrentDay()].opens.slice(
              0,
              2
            )}:${openingHours[getCurrentDay()].opens.slice(2)} - ${openingHours[
              getCurrentDay()
            ].closes.slice(0, 2)}:${openingHours[getCurrentDay()].closes.slice(
              2
            )}`
          : "..."}
        {expandedDateList ? <ArrowDropUpIcon /> : <ArrowDropDownIcon />}
      </span>
      {expandedDateList && (
        <ul style={{ listStyleType: "none", paddingLeft: 0 }}>
          {dayMapper.map((day, i) => (
            <li
              style={{
                display: "flex",
                justifyContent: "space-between",
              }}
              key={i}
            >
              <span>{day.name}</span>
              <span>
                {openingHours[day.key].opens
                  ? `${openingHours[day.key].opens.slice(0, 2)}:${openingHours[
                      day.key
                    ].opens.slice(2)} -
        ${openingHours[day.key].closes.slice(0, 2)}:${openingHours[
                      day.key
                    ].closes.slice(2)}`
                  : "stengt"}
              </span>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default OpeningHours;
