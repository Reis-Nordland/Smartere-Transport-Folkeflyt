import React from "react";
import DirectionsBusIcon from "@mui/icons-material/DirectionsBus";
import DirectionsBikeIcon from "@mui/icons-material/DirectionsBike";
import DirectionsWalkIcon from "@mui/icons-material/DirectionsWalk";

interface Props {
  transportTimes: {
    walkingTime: number;
    busTime: number;
    bikeTime: number;
  };
  iconSize?: "small" | "medium" | "large" | undefined;
  fontSize?: number;
  justifyContent?: string;
  marginLeft?: number;
}
const TransportModeTimes: React.FC<Props> = ({
  transportTimes,
  iconSize = "medium",
  fontSize = 16,
  justifyContent = "space-around",
  marginLeft,
}) => {
  const style = {
    outlinedText: {
      color: "#0D8380",
      fontSize: fontSize,
    },
    alignText: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-around",
      marginLeft: marginLeft || 0,
    },
    iconWrapper: {
      display: "flex",
      alignItems: "center",
      justifyContent: justifyContent,
      width: "100%",
    },
  };

  return (
    <div style={style.iconWrapper}>
      <div style={style.alignText}>
        <DirectionsWalkIcon fontSize={iconSize} />
        <span style={style.outlinedText}>
          {transportTimes.walkingTime || "..."} min
        </span>
      </div>
      <div style={style.alignText}>
        <DirectionsBusIcon fontSize={iconSize} />
        <span style={style.outlinedText}>
          {transportTimes.busTime || "..."} min
        </span>
      </div>
      <div style={style.alignText}>
        <DirectionsBikeIcon style={{ marginRight: 4 }} fontSize={iconSize} />
        <span style={style.outlinedText}>
          {transportTimes.bikeTime || "..."} min
        </span>
      </div>
    </div>
  );
};

export default TransportModeTimes;
