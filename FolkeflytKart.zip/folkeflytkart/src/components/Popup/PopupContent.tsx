import React, { useContext } from "react";
import CardContent from "@mui/material/CardContent";
import CardMedia from "@mui/material/CardMedia";
import DirectionsBusIcon from "@mui/icons-material/DirectionsBus";
import DirectionsBikeIcon from "@mui/icons-material/DirectionsBike";
import DirectionsWalkIcon from "@mui/icons-material/DirectionsWalk";
import { Typography } from "@mui/material";
import { UtilsContextType, UtilsContext } from "../context/UtilsContext";
import { Poi, Directions, TransportModeKeys } from "../../utils/types";
import LinkIcon from "@mui/icons-material/Link";
import { transportIcon } from "../FilterButton/icons";

const style = {
  iconWrapper: {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-around",
    width: "100%",
  },
  outlinedText: {
    color: "black",
  },
  alignText: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
  },
  content: {
    display: "flex",
    flexDirection: "column" as "column",
    alignItems: "center",
    justifyContent: "center",
    paddingTop: 0,
  },
  cardMedia: {
    margin: "auto",
    maxHeight: "200px",
    maxWidth: "325px",
    paddingBottom: "10px",
  },
  root: {
    maxHeight: "75%",
    overflow: "auto",
  },
  description: {
    textAlign: "center" as "center",
    marginTop: 8,
  },
  name: {
    fontWeight: "bold",
    fontSize: 30,
  },
};

interface Props {
  clickedPoint: Poi;
  fetchingTransportRoutes: boolean;
  transportRoutes: {
    walkRoute: Directions[];
    bikeRoute: Directions[];
    busRoute: Directions[];
  };
  translatedDescription: string;
}

const PopupContent: React.FC<Props> = ({
  clickedPoint,
  fetchingTransportRoutes,
  transportRoutes,
  translatedDescription,
}) => {
  const { name, pictureLink, description } = clickedPoint;
  const { language } = useContext(UtilsContext) as UtilsContextType;
  const transportModes = [
    {
      key: TransportModeKeys.WALK,
      icon: <DirectionsWalkIcon />,
    },
    {
      key: TransportModeKeys.BUS,
      icon: <DirectionsBusIcon />,
    },
    {
      key: TransportModeKeys.BIKE,
      icon: <DirectionsBikeIcon style={{ marginRight: 4 }} />,
    },
  ];

  return (
    <div style={style.root}>
      <CardContent style={style.content}>
        {pictureLink && pictureLink.length !== 0 && (
          <CardMedia
            component="img"
            image={pictureLink}
            style={style.cardMedia}
          />
        )}
        <Typography variant="h4" align={"center"} style={style.name}>
          {name}
        </Typography>
        {/* <OpeningHours openingHours={openingHours} /> */}
        {clickedPoint.url && (
          <div style={{ display: "flex" }}>
            <LinkIcon style={{ color: "#0D8380", marginRight: 4 }} />
            {/* <OpenInNewIcon
              style={{ color: "#0D8380", marginRight: 4 }}
            /> */}
            <a
              style={{
                textDecoration: "none",
                color: "#0D8380",
                marginBottom: 10,
              }}
              href={clickedPoint.url}
              target="_blank"
              rel="noopener noreferrer"
            >
              {language === "nb" ? "Nettside" : "Website"}
            </a>
          </div>
        )}
        {/* <EventList clickedPoint={clickedPoint}/> */}
        <div style={style.iconWrapper}>
          {transportModes.map((mode, key) => (
            <div style={style.alignText} key={key}>
              {mode.icon}
              <span style={style.outlinedText}>
                {` ${
                  transportRoutes.busRoute.length === 0
                    ? "..."
                    : Math.floor(transportRoutes[mode.key][0]?.duration / 60)
                } min`}
              </span>
            </div>
          ))}
        </div>
        <Typography style={style.description}>
          {language === "nb" ? description : translatedDescription}
        </Typography>
      </CardContent>
    </div>
  );
};

export default PopupContent;
