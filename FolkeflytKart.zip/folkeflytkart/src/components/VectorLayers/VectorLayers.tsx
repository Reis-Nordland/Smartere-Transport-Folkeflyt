import React from "react";
import VectorLayer from "../../components/context/VectorLayer";
import { Vector as VectorSource } from "ol/source";
import { Icon, Style } from "ol/style";
import { getPoiType } from "../../utils/MapHelpers";
import { PoiType } from "../../utils/types";

interface Props {
  categories: any;
  features: any;
  clickedPoint: any;
  wayFinderState: any;
}
const VectorLayers: React.FC<Props> = ({
  categories,
  features,
  wayFinderState,
  clickedPoint,
}) => {
  return (
    <>
      {categories.map((category: any, i: number) => (
        <div key={i}>
          <VectorLayer
            source={
              new VectorSource({
                features: features.filter((feature: any) => {
                  const properties = feature.getProperties();
                  if (wayFinderState.active) {
                    return properties.data.id === clickedPoint?.id;
                  }
                  if (
                    category.key === PoiType.EVENTS &&
                    properties.data.events
                  ) {
                    return null;
                    // return feature;
                  } else {
                    return properties.data.type === category.key;
                  }
                }),
              })
            }
            features={features.filter((feature: any) => {
              const properties = feature.getProperties();
              return properties.data.type === category.key;
            })}
            type={category.key}
            style={
              new Style({
                image: new Icon({
                  anchor: [0.5, 46],
                  anchorXUnits: "fraction",
                  anchorYUnits: "pixels",
                  opacity: 0.95,
                  src: getPoiType(category.key).icon,
                }),
              })
            }
            zIndex={0}
          />
        </div>
      ))}
    </>
  );
};

export default VectorLayers;
