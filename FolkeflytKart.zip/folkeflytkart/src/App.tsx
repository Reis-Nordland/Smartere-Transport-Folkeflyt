import React, { useState, useEffect, useContext } from "react";
import { fetchAllPois, fetchStopPlaces } from "./services/api";
import { Poi, PoiType, Coordinates } from "./utils/types";
import { MapContextProvider } from "./components/context/MapContext";
import TileLayer from "./components/context/TileLayerContext";
import VectorLayer from "./components/context/VectorLayer";
import Layers from "./components/context/Layers";
import { fromLonLat } from "ol/proj";
import OSM from "ol/source/OSM";
import Feature from "ol/Feature";
import { Point } from "ol/geom";
import { FilterButton } from "./components/FilterButton/FilterButton";
import WayfindingMenu from "./components/Wayfinding/WayfindingMenu";
import WelcomeMenu from "./components/WelcomeMenu/WelcomeMenu";
import ChipsMenu from "./components/ChipsMenu/ChipsMenu";
import PointListView from "./components/PointListView/PointListView";
import ListViewButton from "./components/ListViewButton/ListViewButton";
import {
  getPoiType,
  drawPolylineLayer,
  showAllTransportStopPlaces,
} from "./utils/MapHelpers";
import { styles } from "./utils/MapHelpers";
import { defaultCategories } from "./components/PointListView/PointListView";
import FilterDropdown from "./components/FilterButton/Dropdown/FilterDropdown";
import { getCurrentLocation } from "./utils/getLocation";
import HomeButton from "./components/HomeButton/HomeButton";
import VectorLayers from "./components/VectorLayers/VectorLayers";
import {
  UtilsContext,
  UtilsContextType,
} from "./components/context/UtilsContext";
import VectorSource from "ol/source/Vector";
import { Icon, Style } from "ol/style";
import BusStopIcon from "./data/busstop.svg";

function App() {
  const placeholderCoordinates = {
    latitude: 67.272768,
    longitude: 14.371151,
  };
  const [showDialog, setShowDialog] = useState(false);
  const [features, setFeatures] = useState<Feature[]>([]);
  const [clickedPoint, setClickedPoint] = useState<Poi>();
  const [showFilterButton, setShowFilterButton] = useState(true);
  const [showWelcomeMenu, setShowWelcomeMenu] = useState(true);
  const [zoomLevel, setZoomLevel] = useState(13);
  const [allPoints, setAllPoints] = useState<Poi[]>([]);
  const [showList, setShowList] = useState(false);
  const [mapCoordinates, setMapCoordinates] = useState(
    fromLonLat([14.387754, 67.280572])
  );
  const [categories, setCategories] = useState(defaultCategories);
  const [drawedLine, setDrawedLine] = useState<boolean>(false);
  const [vectorSourceList, setVectorSourceList] = useState([]);
  const [transportStopPlaces, setTranssportStopPlaces] = useState<Feature[]>(
    []
  );
  const [currLocation, setCurrLocation] = useState(placeholderCoordinates) as [
    Coordinates,
    any
  ];

  const [wayFinderState, setWayFinderState] = useState<{
    active: boolean;
    toCoordinates: any;
    selectedTransportMode: any;
  }>({ active: false, toCoordinates: [], selectedTransportMode: "" });

  const { setCurrentFilter, currentFilter } = useContext(
    UtilsContext
  ) as UtilsContextType;

  const mapDataToPoints = (points: Poi[]) => {
    const numberOfPoints = points.length;
    const features = new Array(numberOfPoints);

    for (let i = 0; i < numberOfPoints; i++) {
      const longitude = Number(points[i].coordinates.longitude);
      const latitude = Number(points[i].coordinates.latitude);
      const coord = fromLonLat([longitude, latitude]);

      features[i] = new Feature(new Point(coord));
      features[i].setProperties({ data: points[i] });
    }
    setFeatures(features);
  };

  const getAllLocations = async () => {
    const points = await fetchAllPois();
    setAllPoints(points);
    mapDataToPoints(points);
  };

  useEffect(() => {
    getAllLocations();
    // eslint-disable-next-line
  }, []);

  const handleClickLocation = (point: any) => {
    setClickedPoint(point);
    setShowDialog(true);
    setZoomLevel(15);

    if (point.centroid) {
      setMapCoordinates(
        fromLonLat([
          point.centroid.location.longitude,
          point.centroid.location.latitude,
        ])
      );
    } else {
      setMapCoordinates(
        fromLonLat([point.coordinates.longitude, point.coordinates.latitude])
      );
    }
  };

  const handleFilter = async (poiType: PoiType) => {
    setCategories(() => defaultCategories.filter((c) => c.key === poiType));
    setCurrentFilter(poiType);
  };
  const handleClearFilter = () => {
    setCategories(defaultCategories);
    setCurrentFilter(PoiType.No_FILTER);
  };

  const addPolylineLayer = (
    routes: any,
    findFastestRoute: boolean,
    busLineIndex: number = 0
  ) => {
    if (drawedLine) {
      setDrawedLine(false);
    }

    const vectorSourcesList = drawPolylineLayer(
      routes,
      findFastestRoute,
      busLineIndex
    );

    setVectorSourceList(vectorSourcesList);
  };

  useEffect(() => {
    getCurrentLocation().then((location) => {
      const locationIsOutsideBodø =
        !location ||
        location.longitude > 15 ||
        location.longitude < 14 ||
        location.latitude > 68 ||
        location.latitude < 67;

      if (locationIsOutsideBodø) {
        location = placeholderCoordinates;
      }
      setCurrLocation(location);
    });
    //eslint-disable-next-line
  }, []);

  const onHomeButtonClick = () => {
    setZoomLevel(13);
    setMapCoordinates(fromLonLat([14.387754, 67.280572]));
    setShowWelcomeMenu(true);
  };

  useEffect(() => {
    setDrawedLine(true);
  }, [vectorSourceList]);

  const getStopPlaces = async () => {
    const res = await fetchStopPlaces();
    const data = await res.json();
    const transportFeatures = showAllTransportStopPlaces(data);
    setTranssportStopPlaces(transportFeatures);
  };

  useEffect(() => {
    getStopPlaces();
  }, []);

  return (
    <>
      {features && (
        <MapContextProvider
          zoom={zoomLevel}
          handleClickLocation={handleClickLocation}
          center={mapCoordinates}
          clickedPoint={clickedPoint}
        >
          {!wayFinderState.active && !showWelcomeMenu && (
            <>
              <ListViewButton showList={showList} setShowList={setShowList} />
              <HomeButton onHomeButtonClick={onHomeButtonClick} />
              <FilterButton
                onFilter={handleFilter}
                clearFilter={handleClearFilter}
              />
              <ChipsMenu
                getPoiType={getPoiType}
                handleClickLocation={handleClickLocation}
                features={features}
              />
            </>
          )}
          {showList && (
            <PointListView
              points={allPoints}
              currentLocation={currLocation}
              setFilter={handleFilter}
            />
          )}
          {showDialog && clickedPoint && (
            <WayfindingMenu
              setShowFilterButton={setShowFilterButton}
              setDrawedLine={setDrawedLine}
              addPolylineLayer={addPolylineLayer}
              clickedPoint={clickedPoint}
              setClickedPoint={setClickedPoint}
              clearFilter={handleClearFilter}
              currentLocation={currLocation}
              setWayFinderState={setWayFinderState}
              wayFinderState={wayFinderState}
            />
          )}
          <Layers>
            <TileLayer source={new OSM()} zIndex={0} />
            <VectorLayers
              categories={categories}
              clickedPoint={clickedPoint}
              features={features}
              wayFinderState={wayFinderState}
            />
            {drawedLine &&
              vectorSourceList.map((vectorFeature: any, i) => (
                <div key={i}>
                  <VectorLayer
                    source={vectorFeature.source}
                    style={function () {
                      return styles[vectorFeature.mode];
                    }}
                  />
                </div>
              ))}
            {transportStopPlaces &&
              currentFilter === PoiType.TRANSPORT &&
              !wayFinderState.active && (
                <VectorLayer
                  source={
                    new VectorSource({
                      features: transportStopPlaces,
                    })
                  }
                  style={
                    new Style({
                      image: new Icon({
                        anchor: [0.5, 46],
                        anchorXUnits: "fraction",
                        anchorYUnits: "pixels",
                        opacity: 0.95,
                        src: BusStopIcon,
                      }),
                    })
                  }
                />
              )}
            <WelcomeMenu
              showWelcomeMenu={showWelcomeMenu}
              setShowWelcomeMenu={setShowWelcomeMenu}
              clearFilter={handleClearFilter}
              onFilter={handleFilter}
            />
          </Layers>
        </MapContextProvider>
      )}
    </>
  );
}

export default App;
