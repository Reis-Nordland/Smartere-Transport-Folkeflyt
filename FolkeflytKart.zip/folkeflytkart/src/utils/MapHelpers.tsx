import KulturIkon from "../data/ikon-kultur.svg";
import MatIkon from "../data/ikon-mat.svg";
import NaturIkon from "../data/ikon-natur.svg";
import AktivitetIkon from "../data/ikon-aktiviteter.svg";
import TransportIkon from "../data/ikon-transport-tog.svg";
import LokaleProdukterIkon from "../data/ikon-shopping.svg";
import KulturnattMarker from "../data/marker-kulturnatt.svg";
import { Style, Stroke } from "ol/style";
import { PoiType } from "./types";
import { decode } from "@googlemaps/polyline-codec";
import Feature from "ol/Feature";
import { LineString } from "ol/geom";
import { Vector as VectorSource } from "ol/source";
import { Point } from "ol/geom";
import { fromLonLat } from "ol/proj";

export const styles: Record<string, Style> = {
  route: new Style({
    stroke: new Stroke({
      width: 6,
      color: [237, 212, 0, 0.8],
    }),
  }),
  bus: new Style({
    stroke: new Stroke({
      width: 6,
      // color: [237, 212, 0, 0.8],
      color: [25, 25, 112, 0.8],
    }),
  }),
  foot: new Style({
    stroke: new Stroke({
      width: 6,
      color: [25, 25, 112, 0.8],
      lineDash: [1, 10],
    }),
  }),
  bicycle: new Style({
    stroke: new Stroke({
      width: 6,
      color: [25, 25, 112, 0.8],
      lineDash: [5, 12],
    }),
  }),
};
export const getPoiType = (
  type: string,
  filter?: any,
  transportType?: string
) => {
  switch (type) {
    case PoiType.CULTURE:
      return {
        icon: KulturIkon,
        style: { background: "#F8C81B", color: "black" },
      };
    case PoiType.FOOD:
      return {
        icon: MatIkon,
        style: { background: "#F68D9B", color: "black" },
      };
    case PoiType.TRANSPORT:
      return {
        icon: TransportIkon,
        style: { background: "#438A88", color: "white" },
      };
    // if (transportType === "båt") return TransportIkon;
    // if (transportType === "fly") return NaturIkon;
    // break;
    case PoiType.ACTIVITIES:
      return {
        icon: AktivitetIkon,
        style: { background: "#0CBAD9", color: "black" },
      };
    case PoiType.LOCAL_PRODUCTS:
      return {
        icon: LokaleProdukterIkon,
        style: { background: "#895FC6", color: "white" },
      };
    case PoiType.NATURE:
      return {
        icon: NaturIkon,
        style: { background: "#92D355", color: "black" },
      };
    case PoiType.EVENTS:
      return {
        icon: KulturnattMarker,
        style: { background: "#92D355", color: "black" },
      };
    default:
      return {
        icon: NaturIkon,
        style: { background: "#438A88", color: "white" },
      };
  }
};

export function calculateDistance(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
) {
  var p = 0.017453292519943295; // Math.PI / 180
  var c = Math.cos;
  var a =
    0.5 -
    c((lat2 - lat1) * p) / 2 +
    (c(lat1 * p) * c(lat2 * p) * (1 - c((lon2 - lon1) * p))) / 2;

  return 12742 * Math.asin(Math.sqrt(a)); // 2 * R; R = 6371 km
}

export const drawPolylineLayer = (
  routes: any,
  findFastestRoute: boolean,
  busLineIndex: number = 0
) => {
  let routeLegs;

  if (findFastestRoute) {
    const durationList = routes.map((r: any) => r.duration);
    const fastestRoute = Math.min(...durationList);

    routeLegs = routes.find((r: any) => r.duration === fastestRoute).legs;
  } else {
    routeLegs = routes[busLineIndex].legs;
  }

  const coordinatesInRoute = [];
  const vectorSourcesList: any = [];

  for (let i = 0; i < routeLegs.length; i++) {
    const pointsPolyline = routeLegs[i].polyLine.code;
    const decodedCoordinates = decode(pointsPolyline);
    const formattedCoordinates = decodedCoordinates.map((coords) =>
      coords.reverse()
    );
    coordinatesInRoute.push(...formattedCoordinates);

    const line = new LineString(formattedCoordinates).transform(
      "EPSG:4326",
      "EPSG:3857"
    );

    const routeFeature = new Feature({
      type: "route",
      geometry: line,
    });

    vectorSourcesList.push({
      source: new VectorSource({
        features: [routeFeature],
      }),
      mode: routeLegs[i].transportMode,
    });
  }
  return vectorSourcesList;
};

export const showAllTransportStopPlaces = (stopPlaces: any[]) => {
  const stopPlacesLength = stopPlaces.length;
  const features = new Array(stopPlacesLength);

  for (let i = 0; i < stopPlacesLength; i++) {
    const longitude = Number(stopPlaces[i].centroid.location.longitude);
    const latitude = Number(stopPlaces[i].centroid.location.latitude);
    const coord = fromLonLat([longitude, latitude]);

    features[i] = new Feature(new Point(coord));
    features[i].setProperties({ data: stopPlaces[i] });
  }
  return features;
};
