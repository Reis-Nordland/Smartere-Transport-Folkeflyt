export const text = {
  openingHours_no: "Åpningstider",
  openingHours_eng: "Opening hours",
  today_no: "I dag",
  today_eng: "Today",
  wayfindButtonText_eng: "Show me the way",
  wayfindButtonText_no: "Vis meg veien",
  homeButton_eng: "Home",
  homeButton_no: "Hjem",
  welcomeText_NO: "Hva ser du etter?",
  welcomeText_ENG: "What are you looking for?",
  nextBusHeader_ENG: "Next bus",
  nextBusHeader_NO: "Neste buss",
  aboutText_NO:
    "Byguide er et initiativ fra Bodø Kommune. En prototype ble lansert 21. oktober I forbindelse med arrangementet Kulturnatt. Det jobbes med å lage en fullversjon av løsningen.",
  aboutText_ENG:
    "City guide is an initiative from Bodø Municipality. A prototype was launched 21. October during Culture night event.",
  welcomePageText: {
    cityGuide: "Byguide",
    cityGuide_ENG: "City guide",
    whatDoYouWantToSee: "Hva ser du etter?",
    whatIsThis: "Hva er dette?",
    whatIsThis_ENG: "What is this?",
  },
};
