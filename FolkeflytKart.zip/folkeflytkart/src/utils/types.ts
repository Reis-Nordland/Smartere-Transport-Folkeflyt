import { Categories_EN, Categories_NO } from "./enums";

export interface Poi {
  _Id: string;
  id: string;
  name: string;
  coordinates: Coordinates;
  adress: string;
  type: PoiType;
  openingHours: any;
  weather: string[];
  season: string[];
  duration: number;
  description: string;
  pictureName: null;
  pictureLink: string;
  weatherSymbol: number;
  transportType: null;
  estimatedTransportTime: number;
  startTime: null;
  tags: null;
  url?: string;
  events?: any[];
}

export interface Coordinates {
  latitude?: number;
  longitude?: number;
  error?: boolean;
}

export interface OpeningHours {
  monday: Day;
  tuesday: Day;
  wednesday: Day;
  thursday: Day;
  friday: Day;
  saturday: Day;
  sunday: Day;
  closedOnHoliday: string;
}

export interface Day {
  opens: string;
  closes: string;
}

export type CategoryState = {
  events: Categories_EN | Categories_NO;
  localProducts: Categories_EN | Categories_NO;
  activities: Categories_EN | Categories_NO;
  nature: Categories_EN | Categories_NO;
  food: Categories_EN | Categories_NO;
  culture: Categories_EN | Categories_NO;
  transport: Categories_EN | Categories_NO;
};

export enum PoiType {
  ACTIVITIES = "aktiviteter",
  No_FILTER = "no_filter",
  AIRPORT = "airport",
  BIKE_STAND = "bike_stand",
  BUS_STOP = "bus_stop",
  CULTURE = "kultur",
  FOOD = "mat",
  LOCAL_PRODUCTS = "lokale_produkter",
  NATURE = "natur",
  PORT = "port",
  SHOPPING_MALL = "shopping_mall",
  TRANSPORT = "transport",
  EVENTS = "events",
}

export enum TransportMode {
  WALK = "walk",
  BUS = "publictransport",
  BIKE = "bike",
}
export enum TransportModeKeys {
  WALK = "walkRoute",
  BUS = "busRoute",
  BIKE = "bikeRoute",
}

export interface PolyLine {
  length: number;
  code: string;
}

export interface Leg {
  transportMode: string;
  duration: number;
  distance: number;
  startTime: Date;
  line: null;
  lineDirection: null;
  numStops: number;
  fromPlaceName: string;
  toPlaceName: string;
  polyLine: PolyLine;
}

export type WayfindPoint = {
  name: string;
  description: string;
  coordinates?: Coordinates;
  openingHours?: any;
  type?: PoiType;
  pictureLink?: string;
};

export interface Directions {
  startTime: Date;
  duration: number;
  walkDistance: number;
  legs: Leg[];
}

export type PoiTypeFilter = PoiType | null;
