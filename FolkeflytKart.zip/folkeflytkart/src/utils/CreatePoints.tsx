import Point from "ol/geom/Point";
import { Vector as VectorLayer } from "ol/layer";
import { Vector as VectorSource } from "ol/source";
import { Style, Icon } from "ol/style";
import { fromLonLat } from "ol/proj";
import Feature from "ol/Feature";
import { Poi } from "../utils/types";

const createPoints = (points: Poi[]) => {
  const count = points.length;
  const features = new Array(count);

  for (let i = 0; i < count; ++i) {
    const longitude = Number(points[i].coordinates.longitude);
    const latitude = Number(points[i].coordinates.latitude);
    const coord = fromLonLat([longitude, latitude]);

    features[i] = new Feature(new Point(coord));
    features[i].setProperties({ data: points[i] });
  }

  const source = new VectorSource({
    features: features,
  });

  const createMarker = (point: string) => {
    return new Style({
      image: new Icon({
        anchor: [0.5, 46],
        anchorXUnits: "fraction",
        anchorYUnits: "pixels",
        opacity: 0.95,
        src: "",
      }),
    });
  };

  const pointsLayer = new VectorLayer({
    source: source,
    style: createMarker("mymarker"),
  });

  return pointsLayer;
};

export default createPoints;
