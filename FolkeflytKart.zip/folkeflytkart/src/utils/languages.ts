export const languages = [
  {
    name: "Afrikaans",
    code: "af",
  },
  {
    name: "Albanian",
    code: "sq",
  },
  {
    name: "Amharic",
    code: "am",
  },
  {
    name: "Arabic",
    code: "ar",
  },
  {
    name: "Armenian",
    code: "hy",
  },
  {
    name: "Assamese",
    code: "as",
  },
  {
    name: "Azerbaijani",
    code: "az",
  },
  {
    name: "Bangla",
    code: "bn",
  },
  {
    name: "Bashkir",
    code: "ba",
  },
  {
    name: "Basque",
    code: "eu",
  },
  {
    name: "Bosnian",
    code: "bs",
  },
  {
    name: "Bulgarian",
    code: "bg",
  },
  {
    name: "Cantonese",
    code: "yue",
  },
  {
    name: "Catalan",
    code: "ca",
  },
  {
    name: "Chinese",
    code: "zh-hans",
  },
  {
    name: "Croatian",
    code: "hr",
  },
  {
    name: "Czech",
    code: "cs",
  },
  {
    name: "Danish",
    code: "da",
  },
  {
    name: "Dari",
    code: "prs",
  },
  {
    name: "Divehi",
    code: "dv",
  },
  {
    name: "Dutch",
    code: "nl",
  },
  {
    name: "English",
    code: "en",
  },
  {
    name: "Estonian",
    code: "et",
  },
  {
    name: "Faroese",
    code: "fo",
  },
  {
    name: "Fijian",
    code: "fj",
  },
  {
    name: "Finnish",
    code: "fi",
  },
  {
    name: "French",
    code: "fr",
  },
  {
    name: "Galician",
    code: "gl",
  },
  {
    name: "German",
    code: "de",
  },
  {
    name: "Hindi",
    code: "hi",
  },
  {
    name: "Hungarian",
    code: "hu",
  },
  {
    name: "Icelandic",
    code: "is",
  },
  {
    name: "Indonesian",
    code: "id",
  },
  {
    name: "Italian",
    code: "it",
  },
  {
    name: "Japanese",
    code: "ja",
  },
  {
    name: "Korean",
    code: "ko",
  },
  {
    name: "Latvian",
    code: "lv",
  },
  {
    name: "Lithuanian",
    code: "lt",
  },
  {
    name: "Macedonian",
    code: "mk",
  },
  {
    name: "Nepali",
    code: "ne",
  },
  {
    name: "Norwegian",
    code: "nb",
  },
  {
    name: "Polish",
    code: "pl",
  },
  {
    name: "Portuguese",
    code: "pt",
  },
  {
    name: "Russian",
    code: "ru",
  },
  {
    name: "Spanish",
    code: "es",
  },
  {
    name: "Swedish",
    code: "sv",
  },
  {
    name: "Thai",
    code: "th",
  },
  {
    name: "Turkish",
    code: "tr",
  },
  {
    name: "Ukrainian",
    code: "uk",
  },
  {
    name: "Vietnamese",
    code: "vi",
  },
  {
    name: "Zulu",
    code: "zu",
  },
];
