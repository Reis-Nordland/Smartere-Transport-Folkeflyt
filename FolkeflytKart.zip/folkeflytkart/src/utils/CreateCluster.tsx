import Feature from "ol/Feature";
import Point from "ol/geom/Point";
import { Vector as VectorLayer } from "ol/layer";
import { Cluster, Vector as VectorSource } from "ol/source";
import { Circle as CircleStyle, Fill, Stroke, Style, Text } from "ol/style";
import View from "ol/View";
import Map from "ol/Map";
import TileLayer from "ol/layer/Tile";
import OSM from "ol/source/OSM";
import { fromLonLat } from "ol/proj";

const styleCache: any = {};

const getClusterSize = (size: any) => {
  if (size === 1) {
    return 15;
  } else if (size > 200) {
    return 40;
  } else {
    return 15 + 25 * (size / 200);
  }
};

const createClusters = (activities: [any]) => {
  const count = activities.length;
  const features = new Array(count);

  for (let i = 0; i < count; ++i) {
    const longitude = Number(activities[i].activityAreaLongitude);
    const latitude = Number(activities[i].activityAreaLatitude);
    const coord = fromLonLat([longitude, latitude]);

    features[i] = new Feature(new Point(coord));
    features[i].setProperties({ data: activities[i] });
  }

  const source = new VectorSource({
    features: features,
  });

  const clusterSource = new Cluster({
    distance: parseInt("50", 10),
    minDistance: parseInt("50", 10),
    source: source,
  });

  const clusters = new VectorLayer({
    source: clusterSource,
    style: function (feature) {
      const size = feature.get("features").length;
      let style = styleCache[size];
      if (!style) {
        style = new Style({
          image: new CircleStyle({
            radius: getClusterSize(size),
            stroke: new Stroke({
              color: "#fff",
            }),
            fill: new Fill({
              color: "#003e7e",
            }),
          }),
          text: new Text({
            text: size.toString(),
            fill: new Fill({
              color: "#fff",
            }),
          }),
        });
        styleCache[size] = style;
      }
      return style;
    },
  });

  return clusters;
};

export { createClusters };
