export enum Categories_EN {
  EVENTS = "Events",
  LOCAL_PRODUCTS = "Shopping",
  ACTIVITIES = "Activities",
  NATURE = "Nature",
  FOOD = "Food",
  CULTURE = "Culture",
  Transport = "Transport",
}
export enum Categories_NO {
  EVENTS = "Arrangementer",
  LOCAL_PRODUCTS = "Shopping",
  ACTIVITIES = "Aktiviteter",
  NATURE = "Natur",
  FOOD = "Mat",
  CULTURE = "Kultur",
  Transport = "Transport",
}
