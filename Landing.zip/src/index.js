import React from "react";
import ReactDOM from "react-dom";
import GenericTile from "react-generic-tile";

import ArNavigatorSvg from "./icon-components/ar-navigator";
import SwaggerSvg from "./icon-components/swagger";
import SmartereTransportSvg from "./icon-components/smarteretransport";

import "./styles.css";

function App() {
  return (
    <div className="App">
      <h1>Velkommen til Folkeflyt!</h1>
      <h2>
        Klikk på rutene under for å komme videre til nettsider relatert til Folkeflyt
      </h2>
      <div className="flex">
        <GenericTile
          header="Folkeflyt utviklerportal"
          subheader="Utviklerportalen gir tilgang til APIer i Folkeflyt"
          footer="Løsningen er i pilotfasen"
          icon={<SwaggerSvg/>}
          onClick={() =>
            (window.location = "https://folkeflyt.developer.azure-api.net")
          }
        />
        <GenericTile
          header="Folkeflyt - Applikasjon for utvidet virkelighet"
          subheader="Denne applikasjonen gjør det mulig å se attraksjoner i Bodø i utvidet virkelighet"
          footer="Løsningen er i pilotfasen"
          icon={<ArNavigatorSvg/>}
          onClick={() => (window.location = "https://folkeflyt.com")}
        />
        <GenericTile
          header="Smartere transport Bodø"
          subheader="Hjemmesiden for Smartere Transport Bodø. Folkeflyt er en del av dette prosjektet."
          icon={<SmartereTransportSvg/>}
          onClick={() =>
            (window.location = "https://www.smarteretransportbodo.no")
          }
        />
      </div>
    </div>
  );
}

const rootElement = document.getElementById("root");
ReactDOM.render(<App />, rootElement);
