﻿using System;

namespace Models
{
    public class Trip
    {
        DateTime time;
        public DateTime Time { get => time; set => time = value; }
        public Location From { get; set; }

        public Location To { get; set; }


    }

    public class Location
    {
        public string Name { get; set; }
        public string Id { get; set; }
        public InputCoordinates Coordinates { get; set; }
    }

    public class InputCoordinates
    {
        public double Latitude { get; set; }
        public double Longitude { get; set; }
    }
}
