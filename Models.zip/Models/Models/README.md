﻿To push a new version of this package do the following.
1. Open a CMD prompt in the folder of the nuget package
2.nuget.exe push -Source https://pkgs.dev.azure.com/STB-Folkeflyt/_packaging/Folkeflyt/nuget/v3/index.json -ApiKey AzureDevOps FolkeflytModels.1.0.3.nupkg

PS: Dont forget to version the NuGet package