﻿using Azure;
using Azure.Data.Tables;
using DataAccess.Services;
using Microsoft.AspNetCore.Mvc;
using DataAccess.Models;
using DataAccess.Models.Mappers;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DataAccess.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class DataController : ControllerBase
    {
        private readonly ITableStorageAccess _tableStorageAccess;

        public DataController(ITableStorageAccess tableStorageAccess)
        {
            _tableStorageAccess = tableStorageAccess;
        }

        /// <summary>
        /// Get data from Avinor
        /// </summary>
        /// <remarks>
        /// This is data from Avinor
        /// </remarks>
        [HttpGet("Avinor")]
        public Pageable<TableEntity> GetAvinorData(string filter = null, int? maxResults = null)
        { 
            var avinorTableFields = new List<string> { "Name", "Location" };
            return _tableStorageAccess.GetTableEntity("avinordata", filter, maxResults, avinorTableFields);
        }

        /// <summary>
        /// Get data from Telenor
        /// </summary>
        /// <remarks>
        /// This is data from Telenor
        /// </remarks>
        [HttpGet("Telenor")]
        public Pageable<TableEntity> GetTelenorData(string filter = null, int? maxResults = null)
        {
            var avinorTableFields = new List<string> { "Name", "Location" };
            return _tableStorageAccess.GetTableEntity("avinordata", filter, maxResults, avinorTableFields);
        }
    }
}
