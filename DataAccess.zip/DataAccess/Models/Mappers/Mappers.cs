﻿using Azure.Data.Tables;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DataAccess.Models.Mappers
{
    public static class Mappers
    {
        public static TestModel ToAvinorModel(this TableEntity t)
        {
            return new TestModel()
            {
                Location = t.GetString("Location"),
                Name = t.GetString("Name")
            };
        }
    }
}
