﻿using Azure;
using Azure.Data.Tables;
using DataAccess.Models;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DataAccess.Services
{
    public class TableStorageAccess : ITableStorageAccess
    {

        private IConfiguration _config;

        public TableStorageAccess(IConfiguration config)
        {
            _config = config;
        }

        //private string storageUri => _config["StorageUri"];
        //private string accountName => _config["StorageAccountName"];
        //private string storageAccountKey => _config["TableAccountKey"];
        private string connectionString => _config["StorageConnectionString"];
        //private string tableName => _config["TableName"];


        public Pageable<TableEntity> GetTableEntity(string tableName, string filter, int? maxResults, List<string> select)
        {
            var client = CreateTableClient(tableName);
            return client.Query<TableEntity>(filter: filter, maxPerPage: maxResults, select: select);
        }


        private TableClient CreateTableClient(string tableName)
        {
            return new TableClient(
                connectionString,
                tableName
                );
        }
    }
}
