﻿using Azure;
using Azure.Data.Tables;
using System.Collections.Generic;

namespace DataAccess.Services
{
    public interface ITableStorageAccess
    {
        Pageable<TableEntity> GetTableEntity(string tableName, string filter, int? maxResults, List<string> select);
    }
}