﻿using Newtonsoft.Json;

namespace AstronomyLightConditions.Models
{
    public class Rootobject
    {
        public int Version { get; set; }

        public Billing Billing { get; set; }
        
        public Location[] Locations { get; set; }
    }

    public class Billing
    {
        public int Credits { get; set; }
    }

    public class Location
    {
        public string Id { get; set; }

        public Geo Geo { get; set; }

        public string Matchparam { get; set; }

        public Astronomy Astronomy { get; set; }
    }

    public class Geo
    {
        public string Name { get; set; }
        public Country Country { get; set; }
        public float Latitude { get; set; }
        public float Longitude { get; set; }
        public string ZoneName { get; set; }

    }

    public class Country
    {
        public string Id { get; set; }
        public string Name { get; set; }
    }

    public class Astronomy
    {
        public Object[] Objects { get; set; }
    }

    public class Object
    {
        public string Name { get; set; }
        public Day[] Days { get; set; }
    }

    public class Day
    {
        public string Date { get; set; }
        public Event[] Events { get; set; }
    }

    public class Event
    {
        public string Type { get; set; }
        public int Hour { get; set; }
        public int Min { get; set; }
        public int Sec { get; set; }
        public float Azimuth { get; set; }
    }
}
