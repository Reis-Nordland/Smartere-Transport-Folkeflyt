﻿using AstronomyLightConditions.Models;
using System.Collections.Specialized;
using System.Threading.Tasks;

namespace AstronomyLightConditions.Facades
{
    public interface IAstronomyFacade
    {

        Task FetchAndCacheNewData();

        Task<Rootobject> GetRootData();
    }
}