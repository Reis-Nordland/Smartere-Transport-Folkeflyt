﻿using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Net;
using System.Runtime.Caching;
using System.Security.Cryptography;
using System.Web;
using System.Threading.Tasks;
using AstronomyLightConditions.Models;
using System.Net.Http;

namespace AstronomyLightConditions.Facades.Implementation
{
    public class AstronomyFacade : IAstronomyFacade
    {
        private readonly IConfiguration _configuration;
        private readonly IHttpClientFactory _clientFactory;

        public AstronomyFacade(IHttpClientFactory clientFactory, IConfiguration configuration)
        {
            _clientFactory = clientFactory;
            _configuration = configuration;
        }

        private string CacheKey => _configuration["CacheKey"];
        private string Entrypoint => _configuration["XmlTimeUrl"];
        private string Accesskey => _configuration["AccessKey"];
        private string Secretkey => _configuration["SecretKey"];

        private async Task<string> FetchData(string service, NameValueCollection iargs)
        {
            // Hash computation
            var utcNowTime = DateTime.UtcNow;
            var timestamp = utcNowTime.ToString("o");
            var message = Accesskey + service + timestamp;
            var hmac = new HMACSHA1(System.Text.Encoding.ASCII.GetBytes(Secretkey));
            var hash = hmac.ComputeHash(System.Text.Encoding.ASCII.GetBytes(message));

            // Copy arguments and add authentication parameters
            var args = new NameValueCollection(iargs);
            args.Set("accesskey", Accesskey);
            args.Set("timestamp", timestamp);
            args.Set("signature", Convert.ToBase64String(hash));
            args.Set("startdt", utcNowTime.ToString("yyyy-MM-dd"));

            // Generate URI from the arguments
            List<string> items = new List<string>();
            foreach (string key in args.AllKeys)
                items.Add(string.Concat(HttpUtility.UrlEncode(key), "=", HttpUtility.UrlEncode(args[key])));

            UriBuilder uri = new UriBuilder(Entrypoint + service);
            uri.Query = string.Join("&", items.ToArray());

            var httpClient = _clientFactory.CreateClient();

            var response = await httpClient.GetAsync(uri.Uri);
            var content = await response.Content.ReadAsStringAsync();

            return content;
        }

        public async Task<Rootobject> GetRootData()
        {
            string timedata = await FetchData("astronomy", new NameValueCollection { { "placeid", "norway/bodo" }, { "out", "js" }, { "object", "sun" }, { "types", "all" } });
            var astronomyData = JsonConvert.DeserializeObject<Rootobject>(timedata);
            return astronomyData;
        }

        public async Task FetchAndCacheNewData() // TODO: Refactor such that all references use the (identical) implementation in CacheService.cs
        {
            string timedata = await FetchData("astronomy", new NameValueCollection { { "placeid", "norway/bodo" }, { "out", "js" }, { "object", "sun" }, { "types", "all" }, { "version", "1" } });
            var astronomyData = JsonConvert.DeserializeObject<Rootobject>(timedata);
            MemoryCacher.Set(CacheKey, astronomyData, DateTimeOffset.UtcNow.AddDays(1));
        }
    }
}