﻿using System;
using Newtonsoft.Json;

namespace AstronomyLightConditions.Dtos
{
    public class LightConditionsDto
    { 
        [JsonProperty("civil_twilight_morning")]
        public TimestampDto civilTwilightMorning { get; set; }
        
        [JsonProperty("sunup")]
        public TimestampDto sunup { get; set; }

        [JsonProperty("sundown")]
        public TimestampDto sundown { get; set; }

        [JsonProperty("civil_twilight_evening")]
        public TimestampDto civilTwilightEvening { get; set; }

    }
    public class TimestampDto
    {
        public int hour { get; set; }
        public int minute { get; set; }
    }
}
