﻿using System;
using Newtonsoft.Json;

namespace AstronomyLightConditions.Dtos
{
    public class LightConditionsDateTimeDto
    { 
        [JsonProperty("civil_twilight_morning")]
        public DateTime? civilTwilightMorning { get; set; }
        
        [JsonProperty("sunup")]
        public DateTime? sunup { get; set; }

        [JsonProperty("sundown")]
        public DateTime? sundown { get; set; }

        [JsonProperty("civil_twilight_evening")]
        public DateTime? civilTwilightEvening { get; set; }

    }
}
