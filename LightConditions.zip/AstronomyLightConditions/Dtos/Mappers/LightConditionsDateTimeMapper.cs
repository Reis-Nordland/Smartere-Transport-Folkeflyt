﻿using System;
using AstronomyLightConditions.Models;
using System.Linq;

namespace AstronomyLightConditions.Dtos
{
    public static class LightConditionsDateTimeMapper
    {

        public static LightConditionsDateTimeDto ToDateTimeDto(this Rootobject rootobject)
        {
            var events = rootobject.Locations.FirstOrDefault(x => x.Geo.Name == "Bodø").Astronomy.Objects.FirstOrDefault(x => x.Name == "sun").Days[0].Events;
            var currentDay = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 0, 0, 0);

            return new LightConditionsDateTimeDto
            {
                civilTwilightMorning = TimestampDtoMapper(events.FirstOrDefault(e => e.Type == "twi6_start"), currentDay),
                sunup = TimestampDtoMapper(events.FirstOrDefault(e => e.Type == "rise"), currentDay),
                sundown = TimestampDtoMapper(events.FirstOrDefault(e => e.Type == "set"), currentDay),
                civilTwilightEvening = TimestampDtoMapper(events.FirstOrDefault(e => e.Type == "twi6_end"), currentDay),
            };
        }

        public static DateTime? TimestampDtoMapper(Event e, DateTime currentDay)
        {
            if (e == null)
            {
                return null;
            }
            var response = currentDay.AddHours(e.Hour).AddMinutes(e.Min);
#if !DEBUG
            response = TimeZoneInfo.ConvertTimeToUtc(response, TimeZoneInfo.FindSystemTimeZoneById("Europe/Stockholm"));
#endif
            return response;
        }
    }
}
