﻿using AstronomyLightConditions.Models;
using System.Linq;

namespace AstronomyLightConditions.Dtos
{
    public static class LightConditionsMapper
    {
        public static LightConditionsDto ToDto(this Rootobject rootobject)
        {
            var events = rootobject.Locations.First(x => x.Geo.Name == "Bodø").Astronomy.Objects.First(x => x.Name == "sun").Days[0].Events;

            return new LightConditionsDto
            {
                civilTwilightMorning = TimestampDtoMapper(events.FirstOrDefault(e => e.Type == "twi6_start")),
                sunup = TimestampDtoMapper(events.FirstOrDefault(e => e.Type == "rise")),
                sundown = TimestampDtoMapper(events.FirstOrDefault(e => e.Type == "set")),
                civilTwilightEvening = TimestampDtoMapper(events.FirstOrDefault(e => e.Type == "twi6_end")),
            };
        }

        public static TimestampDto TimestampDtoMapper(Event e)
        {
            if (e == null)
            {
                return null;
            }
            return new TimestampDto
            {
                hour = e.Hour,
                minute = e.Min
            };
        }
    }
}
