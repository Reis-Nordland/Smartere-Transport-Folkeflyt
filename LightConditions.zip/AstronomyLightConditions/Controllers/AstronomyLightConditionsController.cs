﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Configuration;
using AstronomyLightConditions.Models;
using AstronomyLightConditions.Facades;
using AstronomyLightConditions.Services;
using AstronomyLightConditions.Dtos;
using System.Threading.Tasks;
using System.ComponentModel;

namespace AstronomyLightConditions.Controllers
{
    [ApiController]
    public class AstronomyLightConditionsController : Controller
    {
      
        private readonly ILogger<AstronomyLightConditionsController> _logger;
        private readonly IAstronomyFacade _facade;
        private readonly ICacheService _cacheService;
        private readonly ILightConditionService _lightConditionService;

        public AstronomyLightConditionsController(ILogger<AstronomyLightConditionsController> logger, IAstronomyFacade facade, 
            ICacheService cacheService, ILightConditionService lightConditionService)
        {
            _logger = logger;
            _facade = facade;
            _cacheService = cacheService;
            _lightConditionService = lightConditionService;
        }

        //[Route("GetRootObject")]
        //[HttpGet]
        //public async Task<Rootobject> GetRootObject()
        //{
        //    var result = await _facade.GetRootData();
        //    return result;
        //}

        //[Route("FetchAndCache")]
        //[HttpGet]
        //public async Task<OkResult> FetchAndCache()
        //{
        //    await _cacheService.FetchAndCacheNewData();
        //    return Ok();
        //}

        //[Route("GetCachedData")]
        //[HttpGet]
        //public Rootobject GetCachedData()
        //{
        //    var results = _cacheService.GetCachedData();
        //    return results;
        //}

        /// <summary>
        /// Get light conditions
        /// </summary>
        /// <remarks>
        /// Sunrise, sunset and twilight times (local time) for the current day loaded from cache
        /// </remarks>
        [Route("LightConditions")]
        [HttpGet]
        public LightConditionsDto GetLightConditionsFromCache()
        {
            return _lightConditionService.GetLightConditionsFromCache();
        }

        /// <summary>
        /// Get light conditions in UTC format
        /// </summary>
        /// <remarks>
        /// Datetime formatted sunrise, sunset and twilight times (UTC) for the current day
        /// </remarks>
        [Route("DateTimeLightConditions")]
        [HttpGet]
        /// Only returns UTC time when not debugging
        public LightConditionsDateTimeDto GetDateTimeLightConditionsFromCache()
        {
            return _lightConditionService.GetDateTimeFormatFromCache();
        }
    }
}
