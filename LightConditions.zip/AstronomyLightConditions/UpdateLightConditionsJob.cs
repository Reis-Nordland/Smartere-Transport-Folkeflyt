﻿using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Configuration;
using System.Threading;
using System.Threading.Tasks;
using AstronomyLightConditions.Facades;
using AstronomyLightConditions.Services;

namespace AstronomyLightConditions
{
    public class UpdateLightConditionsJob : CronJobService
    {
        private readonly ILogger<UpdateLightConditionsJob> _logger;
        private readonly IAstronomyFacade _api;
        private readonly ILightConditionService _lightConditionService;

        public UpdateLightConditionsJob(
            IScheduleConfig<UpdateLightConditionsJob> config, 
            ILogger<UpdateLightConditionsJob> logger,
            IAstronomyFacade api,
            ILightConditionService lightConditionService)
            : base(config.CronExpression, config.TimeZoneInfo)
        {
            _logger = logger;
            _api = api;
            _lightConditionService = lightConditionService;
        }


        public override async Task DoWork(CancellationToken cancellationToken)
        {
            await _api.FetchAndCacheNewData();
            _logger.LogInformation("Updated astronomyData");
        }
    }
}