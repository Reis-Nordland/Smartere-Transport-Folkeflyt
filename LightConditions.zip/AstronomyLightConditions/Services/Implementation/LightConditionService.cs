﻿using AstronomyLightConditions.Dtos;
using AstronomyLightConditions.Facades;
using System.Threading.Tasks;

namespace AstronomyLightConditions.Services.Implementation
{
    public class LightConditionService : ILightConditionService
    {
        private readonly IAstronomyFacade _astronomyFacade;
        private readonly ICacheService _cacheService;

        public LightConditionService(IAstronomyFacade astronomyFacade, ICacheService cacheService)
        {
            _astronomyFacade = astronomyFacade;
            _cacheService = cacheService;
        }

        public async Task<LightConditionsDto> GetLightConditionsFromApi()
        {
            var results = await _astronomyFacade.GetRootData();
            return results.ToDto();

        }

        public LightConditionsDto GetLightConditionsFromCache()
        {
            var results = _cacheService.GetCachedData();
            return results.ToDto();
        }

        public LightConditionsDateTimeDto GetDateTimeFormatFromCache()
        {
            var results = _cacheService.GetCachedData();
            return results.ToDateTimeDto();
        }

    }
}