﻿using AstronomyLightConditions.Models;
using AstronomyLightConditions.Facades;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using System.Runtime.Caching;

namespace AstronomyLightConditions.Services.Implementation
{
    public class CacheService : ICacheService
    {
        private readonly IConfiguration _configuration;
        private readonly IAstronomyFacade _astronomyFacade;

        public CacheService(IAstronomyFacade facade, IConfiguration configuration)
        {
            _astronomyFacade = facade;
            _configuration = configuration;
        }

        private string CacheKey => _configuration["CacheKey"];

        public async Task FetchAndCacheNewData()
        {
            var astronomyData = await _astronomyFacade.GetRootData();
            MemoryCacher.Set(CacheKey, astronomyData, DateTimeOffset.UtcNow.AddDays(1));
        }

        public Rootobject GetCachedData()
        {
            var result =  MemoryCacher.GetValue(CacheKey);
            return (Rootobject)result;
        }
    }
}
