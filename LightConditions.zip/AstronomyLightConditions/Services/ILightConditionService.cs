﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AstronomyLightConditions.Models;
using AstronomyLightConditions.Dtos;

namespace AstronomyLightConditions.Services
{
    public interface ILightConditionService
    {
        LightConditionsDateTimeDto GetDateTimeFormatFromCache();
        Task<LightConditionsDto> GetLightConditionsFromApi();
        LightConditionsDto GetLightConditionsFromCache();
    }
}
