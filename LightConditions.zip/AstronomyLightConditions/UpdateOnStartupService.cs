using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Configuration;
using System.Threading;
using System.Threading.Tasks;
using AstronomyLightConditions.Facades;

namespace AstronomyLightConditions
{
    public class UpdateOnStartupService : IHostedService
    {
        // We need to inject the IServiceProvider so we can create 
        // the scoped service, MyDbContext
        private readonly ILogger<UpdateOnStartupService> _logger;
        private readonly IAstronomyFacade _facade;

        public UpdateOnStartupService(ILogger<UpdateOnStartupService> logger, IAstronomyFacade facade)
        {
            _logger = logger;
            _facade = facade;
        }

        public async Task StartAsync(CancellationToken cancellationToken)
        {
            await _facade.FetchAndCacheNewData();
            _logger.LogInformation("Updated astronomyData");
        }

        // noop
        public Task StopAsync(CancellationToken cancellationToken) => Task.CompletedTask;
    }
}