using System;
using AstronomyLightConditions.Facades;
using AstronomyLightConditions.Facades.Implementation;
using AstronomyLightConditions.Services;
using AstronomyLightConditions.Services.Implementation;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

[assembly: ApiConventionType(typeof(DefaultApiConventions))]
namespace AstronomyLightConditions
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddHttpClient();
            services.AddTransient<IAstronomyFacade, AstronomyFacade>();
            services.AddTransient<ILightConditionService, LightConditionService>();
            services.AddTransient<ICacheService, CacheService>();
            services.AddControllers();

            // Cronjob for fetching and caching data, runs at 01.30 (UTC) every day
            services.AddCronJob<UpdateLightConditionsJob>(c =>
            {
                c.TimeZoneInfo = TimeZoneInfo.Local;
                c.CronExpression = @"30 1 * * *";
            });

            // Fetch and cache data on startup as well
            services.AddHostedService<UpdateOnStartupService>();

            // Register the Swagger services
            services.AddSwaggerDocument(config =>
            {
                config.PostProcess = document =>
                {
                    document.Info.Version = "v1";
                    document.Info.Title = "Light Conditions API";
                    document.Info.Description = "Get light condition information such as sun up and down and twilight hours";
                    document.Info.TermsOfService = "None";
                };
            });
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseHttpsRedirection();

            app.UseRouting();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });

            // Register the Swagger generator and the Swagger UI middlewares
            app.UseOpenApi();
            app.UseSwaggerUi3();
        }
    }
}
