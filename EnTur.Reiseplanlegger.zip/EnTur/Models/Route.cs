﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EnTur.Models
{
    public class Route
    {

        /// <summary>
        /// Start time of trip.
        /// </summary>
        public DateTime StartTime { get; set; }
        
        /// <summary>
        /// Duration in seconds.
        /// </summary>
        public double Duration { get; set; }

        /// <summary>
        /// Distance covered by walking, in meters.
        /// </summary>
        public double WalkDistance { get; set; }

        public Leg[] Legs { get; set; }
    }

    public class Leg
    {

        /// <summary>
        /// Transport mode: Either foot, bicycle, bus or rail.
        /// </summary>
        public string TransportMode { get; set; }

        /// <summary>
        /// Duration in seconds.
        /// </summary>
        public double Duration { get; set; }

        /// <summary>
        /// Distance in meters.
        /// </summary>
        public double Distance { get; set; }

        /// <summary>
        /// Estimated start time, specifically estimated departure time if public transport.
        /// </summary>
        public DateTime StartTime { get; set; }

        /// <summary>
        /// The code of the line taken, if public transport.
        /// </summary>
        public string Line { get; set; }

        /// <summary>
        /// The direction of the line (i.e. the terminal station), if public transport.
        /// </summary>
        public string LineDirection { get; set; }

        /// <summary>
        /// Number of stops inbetween departure and arrival, if public transport.
        /// </summary>
        public int NumStops { get; set; }

        /// <summary>
        /// The name of the station travelled from, if applicable.
        /// </summary>
        public string FromPlaceName { get; set; }

        /// <summary>
        /// The name of the station travelled to, if applicable.
        /// </summary>
        public string ToPlaceName { get; set; }

        public PolyLineCode PolyLine { get; set; }

    }

    public class PolyLineCode
    {
        /// <summary>
        /// The amount of points on the line.
        /// </summary>
        public int Length { get; set; }

        /// <summary>
        /// The encoded polyline (http://code.google.com/apis/maps/documentation/polylinealgorithm.html).
        /// Be aware that the string could contain escape characters (https://www.freeformatter.com/javascript-escape.html).
        /// </summary>
        public string Code { get; set; }
    }
}
