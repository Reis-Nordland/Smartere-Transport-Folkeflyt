﻿using EnTur.Facades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EnTur.Models
{
    public class SpareTimeSuggestion
    {
        public Route Journey { get; set; }

        public PoiDto VisitLocation { get; set; }
    }
}
