﻿using MongoDB.Bson.Serialization.Attributes;
using EnTur.Facades.Otto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EnTur.Models
{
    public class BetweenOttoStationsRoute
    {
        [BsonElement("_id")]
        public string Id { get; set; }

        [BsonElement("originOttoStatio")]
        public LocationsResponseDto OriginOttoStation { get; set; }
        
        [BsonElement("destinationOttoStation")]
        public LocationsResponseDto DestinationOttoStation { get; set; }

        [BsonElement("originCoordinates")]
        public Coordinates OriginCoordinates { get; set; }

        [BsonElement("destinationCoordinates")]
        public Coordinates DestinationCoordinates { get; set; }


        //public Coordinates OriginCoordinates()
        //{
        //    return new Coordinates
        //    {
        //        Latitude = Convert.ToDouble(FromOttoStationLocation.Latitude),
        //        Longitude = Convert.ToDouble(FromOttoStationLocation.Longitude)
        //    };
        //}

        //public Coordinates DestinationCoordinates()
        //{
        //    return new Coordinates
        //    {
        //        Latitude = Convert.ToDouble(FromOttoStationLocation.Latitude),
        //        Longitude = Convert.ToDouble(FromOttoStationLocation.Longitude)
        //    };
        //}
    }
}
