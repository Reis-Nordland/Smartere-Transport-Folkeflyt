using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using EnTur.Configuration;
using EnTur.Facades;
using EnTur.Facades.Entur;
using EnTur.Facades.Otto;
using EnTur.Facades.Weather;
using EnTur.Services;
using EnTur.Services.Implementation;

[assembly: ApiConventionType(typeof(DefaultApiConventions))]
namespace EnTur
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        readonly string MyAllowSpecificOrigins = "_myAllowSpecificOrigins";

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.Configure<DatabaseOptions>(Configuration.GetSection("DatabaseOptions"));
            services.Configure<EnTurApiOptions>(Configuration.GetSection("EnTurApi"));
            services.Configure<FolkeflytApiOptions>(Configuration.GetSection("FolkeFlytApis"));
            services.AddHttpClient();

//#if DEBUG
            services.AddCors(o => o.AddPolicy("MyPolicy", builder =>
            {
                builder.AllowAnyOrigin()
                       .AllowAnyMethod()
                       .AllowAnyHeader();
            }));
//#endif
            services.AddControllers();
            services.AddTransient<IDataService, DataService>();
            services.AddTransient<IDirectionsService, DirectionsService>();
            services.AddTransient<IOttoService, OttoService>();
            services.AddTransient<IEnTurFacade, EnTurFacade>();
            services.AddTransient<IWeatherFacade, WeatherFacade>();
            services.AddTransient<IOttoFacade, OttoFacade>();
            services.AddTransient<IPoiFacade, PoiFacade>();


            // Register the Swagger services
            services.AddSwaggerDocument(config =>
            {
                config.PostProcess = document =>
                {
                    document.Info.Version = "v1";
                    document.Info.Title = "Reiseplanlegger API";
                    document.Info.Description = "Travel suggestions for how to get from A to B";
                    document.Info.TermsOfService = "None";
                };
            });
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseHttpsRedirection();

            app.UseRouting();

//#if DEBUG
            app.UseCors(MyAllowSpecificOrigins);
            //#endif

            app.UseAuthentication();
            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
            
            // Register the Swagger generator and the Swagger UI middlewares
            app.UseOpenApi();
            app.UseSwaggerUi3();
        }
    }
}
