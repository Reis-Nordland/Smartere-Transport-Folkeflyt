﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MongoDB.Bson;
using MongoDB.Driver;
using EnTur.Dtos;
using EnTur.Facades.EnTur;
using EnTur.Models;
namespace EnTur.Services
{
    public interface IDataService
    {
        Task UpsertRoute(EnTurJourneyPlanResult data);
        Task<EnTurJourneyPlanResult> GetRoute(string id);
    }
}
