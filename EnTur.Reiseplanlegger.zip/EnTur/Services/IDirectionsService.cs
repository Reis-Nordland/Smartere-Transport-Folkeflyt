﻿using EnTur.Facades.EnTur;
using EnTur.Models;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace EnTur.Services
{
    public interface IDirectionsService
    {
        //Task DecideRoute(double fromLat, double fromLon, double toLat, double toLon, double minutesAvailable, string transportMode);
        Task<Route[]> OttoRoutes(Coordinates origin, Coordinates destination, double maximumWalkingDistanceInMeters, string vehicleType);
        Task<List<SpareTimeSuggestion>> SpareTimeSuggestions(Coordinates origin, Coordinates destination, DateTime deadline, string poiType, string transportType);
    }
}