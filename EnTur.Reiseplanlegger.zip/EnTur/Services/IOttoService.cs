﻿using EnTur.Facades.EnTur;
using EnTur.Models;
using System.Threading.Tasks;

namespace EnTur.Services
{
    public interface IOttoService
    {
        Task<BetweenOttoStationsRoute> FindViableOttoRoute(Coordinates origin, Coordinates destination, double acceptableWalkLengthInMeters, string vehicleType);
        Task GenerateAndSaveAllOttoRoutes();
        Task<EnTurJourneyPlanResult> GetCachedOttoRoute(BetweenOttoStationsRoute route);
    }
}