﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Security.Authentication;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using MongoDB.Bson;
using MongoDB.Driver;
using EnTur.Configuration;
using EnTur.Dtos;
using EnTur.Facades.EnTur;
using EnTur.Mappers;
using EnTur.Models;

namespace EnTur.Services.Implementation
{
    public class DataService : IDataService
    {
        private readonly DatabaseOptions _configuration;
        private readonly MongoClient _client;
        private readonly IMongoDatabase _database;

        public DataService(IOptions<DatabaseOptions> configuration)
        {
            _configuration = configuration.Value;
            _client = GetClient();
            _database = _client.GetDatabase(_configuration.Database);
        }


        public async Task UpsertRoute(EnTurJourneyPlanResult data)
        {
            var collection = _database.GetCollection<EnTurJourneyPlanResult>(_configuration.OttoRouteCollection);

            try
            {
                await collection.ReplaceOneAsync(
                    route => route.Id == data.Id,
                    data,
                    new ReplaceOptions { IsUpsert = true });
            }
            catch (MongoCommandException ex)
            {
                throw ex;
            }
        }

        public async Task<EnTurJourneyPlanResult> GetRoute(string id)
        {
            var collection = _database.GetCollection<EnTurJourneyPlanResult>(_configuration.OttoRouteCollection);

            var filter = Builders<EnTurJourneyPlanResult>.Filter.Eq("_id", id);

            var item = await collection.FindAsync<EnTurJourneyPlanResult>(filter);
 
            return await item.FirstOrDefaultAsync();

        }

        private MongoClient GetClient()
        {
            var settings = new MongoClientSettings
            {
                Server = new MongoServerAddress(_configuration.Host, 10255),
                UseSsl = true,
                SslSettings = new SslSettings { EnabledSslProtocols = SslProtocols.Tls12 },
                Credentials = new List<MongoCredential>
                {
                    new MongoCredential("SCRAM-SHA-1",
                        new MongoInternalIdentity(_configuration.Database, _configuration.Username),
                        new PasswordEvidence(_configuration.Password))
                }

            };

            return new MongoClient(settings);
        }
    }
}