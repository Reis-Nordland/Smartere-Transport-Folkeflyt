﻿using Microsoft.Extensions.Configuration;
using EnTur.Facades;
using EnTur.Facades.EnTur;
using EnTur.Facades.Otto;
using EnTur.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EnTur.Services.Implementation
{
    public class OttoService : IOttoService
    {

        private readonly IConfiguration _configuration;
        private readonly IDataService _dataService;
        private readonly IOttoFacade _ottoFacade;
        private readonly IEnTurFacade _enTurFacade;

        public OttoService(IConfiguration configuration, IDataService dataService, IOttoFacade ottoFacade, IEnTurFacade enTurFacade)
        {
            _configuration = configuration;
            _dataService = dataService;
            _ottoFacade = ottoFacade;
            _enTurFacade = enTurFacade;
        }

        public async Task<BetweenOttoStationsRoute> FindViableOttoRoute(Coordinates origin, Coordinates destination, double acceptableWalkLengthInMeters, string vehicleType)
        {
            var originStation = await _ottoFacade.FindClosest(origin, vehicleType);
            var destinationStation = await _ottoFacade.FindClosest(destination, vehicleType);

            if (originStation.DistanceInMeter + destinationStation.DistanceInMeter > acceptableWalkLengthInMeters
                || originStation.Location is null
                || destinationStation.Location is null)
            {
                return null;
            }

            return new BetweenOttoStationsRoute
            {
                OriginOttoStation = originStation.Location,
                DestinationOttoStation = destinationStation.Location,
                OriginCoordinates = new Coordinates(
                    originStation.Location.Latitude,
                    originStation.Location.Longitude
                    ),
                DestinationCoordinates = new Coordinates
                (
                    destinationStation.Location.Latitude,
                    destinationStation.Location.Longitude
                ),
            };
        }

        public async Task GenerateAndSaveAllOttoRoutes()
        {
            var stations = await _ottoFacade.GetAllStationsInBodo();
            foreach (LocationsResponseDto originStation in stations)
            {
                foreach (LocationsResponseDto destinationStation in stations)
                {
                    if (originStation == destinationStation) continue;

                    var route = await _enTurFacade.GetTripPlanner(
                        new Coordinates(originStation.Latitude, originStation.Longitude),
                        new Coordinates(destinationStation.Latitude, destinationStation.Longitude),
                        transportType: "bike");

                    route.Id = $"{originStation.Id}to{destinationStation.Id}";

                    await _dataService.UpsertRoute(route);
                }

            }
        }

        public async Task<EnTurJourneyPlanResult> GetCachedOttoRoute(BetweenOttoStationsRoute route)
        {
            var id = $"{route.OriginOttoStation.Id}to{route.DestinationOttoStation.Id}";
            return await _dataService.GetRoute(id);
        }
    }
}
