﻿using Microsoft.Extensions.Configuration;
using Newtonsoft.Json.Linq;
using EnTur.Facades;
using EnTur.Facades.EnTur;
using EnTur.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using EnTur.Mappers.EnturToRouteMapper;

namespace EnTur.Services.Implementation
{
    public class DirectionsService : IDirectionsService
    {

        private readonly IConfiguration _configuration;
        private readonly IWeatherFacade _weatherFacade;
        private readonly IOttoService _ottoService;
        private readonly IEnTurFacade _enTurFacade;
        private readonly IPoiFacade _poiFacade;

        public DirectionsService(IConfiguration configuration, IWeatherFacade weatherFacade, IOttoService ottoService, IEnTurFacade enTurFacade, IPoiFacade poiFacade)
        {
            _configuration = configuration;
            _weatherFacade = weatherFacade;
            _ottoService = ottoService;
            _enTurFacade = enTurFacade;
            _poiFacade = poiFacade;
        }

        public async Task<Route[]> OttoRoutes(Coordinates origin, Coordinates destination, double maximumWalkingDistanceInMeters, string vehicleType)
        {
            // Otto
            var fullOttoJourney = new Route();

            var ottoRoute = await _ottoService.FindViableOttoRoute(origin, destination, maximumWalkingDistanceInMeters, vehicleType);
            if (ottoRoute != null)
            {
                fullOttoJourney.Legs = new Leg[3];

                var firstPartByFoot = (await _enTurFacade.GetTripPlanner(
                    origin,
                    ottoRoute.OriginCoordinates,
                    "walk"))
                    .Trip.TripPatterns.FirstOrDefault();

                var bikeBetweenOttoStations = (await _ottoService.GetCachedOttoRoute(ottoRoute))
                    .Trip.TripPatterns.FirstOrDefault();

                var lastPartByFoot = (await _enTurFacade.GetTripPlanner(
                    ottoRoute.DestinationCoordinates,
                    destination,
                    "walk"))
                    .Trip.TripPatterns.FirstOrDefault();

                
                fullOttoJourney.Legs[0] = firstPartByFoot
                    .Legs.FirstOrDefault()
                    .FromEnturLegsToLeg();

                fullOttoJourney.Legs[0].ToPlaceName = ottoRoute.OriginOttoStation.Name;


                fullOttoJourney.Legs[1] = bikeBetweenOttoStations
                    .Legs.FirstOrDefault()
                    .FromEnturLegsToLeg();

                fullOttoJourney.Legs[1].FromPlaceName = ottoRoute.OriginOttoStation.Name;
                fullOttoJourney.Legs[1].ToPlaceName = ottoRoute.DestinationOttoStation.Name;


                fullOttoJourney.Legs[2] = lastPartByFoot
                    .Legs.FirstOrDefault()
                    .FromEnturLegsToLeg();

                fullOttoJourney.Legs[2].FromPlaceName = ottoRoute.DestinationOttoStation.Name;


                fullOttoJourney.StartTime = DateTime.UtcNow;
                fullOttoJourney.Duration = firstPartByFoot.Duration + bikeBetweenOttoStations.Duration + lastPartByFoot.Duration;
                fullOttoJourney.WalkDistance = firstPartByFoot.WalkDistance + lastPartByFoot.WalkDistance;
            }

            return new Route[] {fullOttoJourney };
        }

        public async Task<List<SpareTimeSuggestion>> SpareTimeSuggestions(Coordinates origin, Coordinates destination, DateTime deadline, string poiType, string transportType)
        {
            // The unit used for time is seconds. The "duration" field in POI objects is in minutes, so it is corrected when used.

            deadline = deadline.ToUniversalTime();
            var timeToSpend = (deadline - DateTime.UtcNow).TotalSeconds;
            
            if (timeToSpend <= 0)
            {
                throw new ArgumentException($"The selected deadline {deadline} is earlier than the current time.");
            }

            var suggestionsList = new List<SpareTimeSuggestion>();

            var locations = await _poiFacade.GetPoi(poiType);

            var timeToGetDirectlyToDestination = (await _enTurFacade.GetTripPlanner(origin, destination, transportType))
                .Trip.TripPatterns.FirstOrDefault().Duration;

            // Return empty list of suggestions if we don't even have time to travel directly to the destination
            if (timeToGetDirectlyToDestination > timeToSpend)
            {
                return suggestionsList;
            }

            // Upper bound of how much time we we have to spare after travel
            var maxTimeAtPoi = timeToSpend - timeToGetDirectlyToDestination;

            var potentiallyViableLocations = locations.Where(loc => loc.duration*60 < maxTimeAtPoi);

            foreach (PoiDto location in potentiallyViableLocations)
            {
                var tripToPoi = (await _enTurFacade.GetTripPlanner(origin, location.coordinates, transportType))
                    .Trip.TripPatterns.FirstOrDefault();

                // Continue evaluation only if the estimated time required to stay at the POI is less than what we have spare after travelling there
                if (location.duration*60 < timeToSpend - tripToPoi.Duration) 
                {
                    var departureTime = tripToPoi.StartTime.AddSeconds(tripToPoi.Duration).AddMinutes(location.duration);

                    var tripFromPoi = (await _enTurFacade.GetTripPlanner(location.coordinates, destination, transportType, departureTime))
                        .Trip.TripPatterns.FirstOrDefault();

                    if (tripFromPoi.StartTime.AddSeconds(tripFromPoi.Duration).ToUniversalTime() <= deadline)
                    {
                        var fullRoute = tripToPoi.MultipleEnturToOneRoute(tripFromPoi);
                        suggestionsList.Add(new SpareTimeSuggestion{
                            Journey = fullRoute,
                            VisitLocation = location
                        }
                        );
                    }
                }
            }

            return suggestionsList;
        }


//        public async Task DecideRoute(double fromLat, double fromLon, double toLat, double toLon, double minutesAvailable, string transportMode)
//        {
//            var season = GetSeason();
//            var weather = await GetWeatherCategory(minutesAvailable / 60);
//            var dayOfWeek = DateTime.Now.DayOfWeek.ToString().ToLower();

//            if (String.IsNullOrEmpty(transportMode))
//            {
//                transportMode = GetTransportType(weather);
//            }

//            DateTime timeOfDayDatetime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, DateTime.Now.Hour, DateTime.Now.Minute, 0);
//#if !DEBUG
//            timeOfDayDatetime = TimeZoneInfo.ConvertTimeFromUtc(timeOfDayDatetime, TimeZoneInfo.FindSystemTimeZoneById("Europe/Stockholm"));
//#endif
//            var timeOfDay = timeOfDayDatetime.ToString().Substring(11, 5).Remove(2, 1);
//        }


        //private string GetSeason()
        //{
        //    int month = Int32.Parse(DateTime.Now.Month.ToString());
        //    if (month > 11 || month < 3)
        //        return "winter";
        //    if (month < 6)
        //        return "spring";
        //    if (month < 9)
        //        return "summer";
        //    if (month < 12)
        //        return "fall";
        //    return "unknownmonth";
        //}

        //private async Task<string> GetWeatherCategory(double hourDuration)
        //{
        //    if (hourDuration > 8)
        //        hourDuration = 12;
        //    else if (hourDuration > 3)
        //        hourDuration = 6;
        //    else
        //        hourDuration = 1;

        //    var weather = await _weatherFacade.GetWeatherForecast((int)hourDuration);

        //    try
        //    {


        //        if (weather.precipitation.precipitationAmount > 0)
        //            return "badweather";
        //        if (weather.windSpeed > 9)
        //            return "badweather";
        //        if (weather.temperature < -15)
        //            return "badweather";
        //        //15 = fog
        //        if (weather.weatherSymbol.number > 4 && weather.weatherSymbol.number != 15)
        //            return "badweather";
        //        if (weather.weatherSymbol.number > 2)
        //            return "neutralweather";
        //        if (weather.weatherSymbol.number > 0)
        //            return "goodweather";
        //        return "neutralweather";
        //    }
        //    catch
        //    {
        //        return "neutralweather";
        //    }
        //}
        //private string GetTransportType(string weather)
        //{
        //    if (weather == "goodweather" || weather == "neutralweather")
        //    {
        //        return "walk";
        //    }
        //    else
        //    {
        //        return "transit";
        //    }
        //}
    }
}
