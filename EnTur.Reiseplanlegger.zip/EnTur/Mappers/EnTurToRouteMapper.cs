﻿using EnTur.Facades.EnTur;
using EnTur.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EnTur.Mappers.EnturToRouteMapper
{
    public static class EnturToRouteMapper
    {
        public static IEnumerable<Route> FromEnturToRoute(this EnTurJourneyPlanResult dto)
        {
            //return dto.Trip.TripPatterns.FirstOrDefault().FromEnTurTripPatternToRoute();
            return dto.Trip.TripPatterns.Select(tripPattern => FromEnturTripPatternToRoute(tripPattern));
        }

        public static Route FromEnturTripPatternToRoute(this EnTurTripPattern dto)
        {
            return new Route
            {
                StartTime = dto.StartTime,
                Duration = dto.Duration,
                WalkDistance = dto.WalkDistance,
                Legs = dto.Legs.Select(leg => leg.FromEnturLegsToLeg()).ToArray()
            };
        }

        public static Leg FromEnturLegsToLeg(this EnTurLegs dto)
        {
            return new Leg
            {
                TransportMode = dto.Mode,
                Duration = dto.Duration,
                Distance = dto.Distance,
                StartTime = dto.ExpectedStartTime,
                Line = dto.Line?.PublicCode,
                LineDirection = dto.FromEstimatedCall?.DestinationDisplay?.FrontText,
                NumStops = dto.IntermediateQuays.Length,
                FromPlaceName = dto.FromPlace.Name,
                ToPlaceName = dto.ToPlace.Name,
                PolyLine = new PolyLineCode
                {
                    Length = dto.PointsOnLink.Length,
                    Code = dto.PointsOnLink.Points
                }
            };
        }

        /// <summary>
        /// Adds together multiple EnTurJourneyPlanResult objects into a single Route object with correct values for duration etc.
        /// </summary>
        /// <param name="firstTripPattern"></param>
        /// <param name="subsequentTripPatterns"></param>
        /// <returns></returns>
        /// 
        public static Route MultipleEnturToOneRoute(this EnTurTripPattern firstTripPattern, EnTurTripPattern subsequentTripPatterns)
        {
            var firstRoute = firstTripPattern.FromEnturTripPatternToRoute();
            var subsequentRoute = subsequentTripPatterns.FromEnturTripPatternToRoute();


            var legsList = firstRoute.Legs.ToList();

            legsList.AddRange(subsequentRoute.Legs);
            
            return new Route
            {
                Duration = (subsequentRoute.StartTime - firstRoute.StartTime).TotalSeconds + subsequentRoute.Duration,
                StartTime = firstRoute.StartTime,
                Legs = legsList.ToArray(),
                WalkDistance = firstRoute.WalkDistance + subsequentRoute.WalkDistance
            };
        }

        public static Route MultipleEnturToOneRoute(this EnTurTripPattern firstTripPattern, List<EnTurTripPattern> subsequentTripPatterns)
        {
            var firstRoute = firstTripPattern.FromEnturTripPatternToRoute();

            var legsList = firstRoute.Legs.ToList();

            List<Route> subsequentRoutes = subsequentTripPatterns.Select(x => x.FromEnturTripPatternToRoute()).ToList();

            foreach (Route subsequentRoute in subsequentRoutes)
            {
                legsList.AddRange(subsequentRoute.Legs);
            }

            return new Route
            {
                Duration = (subsequentRoutes.Last().StartTime - firstRoute.StartTime).TotalSeconds + subsequentRoutes.Last().Duration,
                StartTime = firstRoute.StartTime,
                Legs = legsList.ToArray(),
                WalkDistance = firstRoute.WalkDistance + subsequentRoutes.Sum(route => route.WalkDistance)
            };
        }

    }
}
