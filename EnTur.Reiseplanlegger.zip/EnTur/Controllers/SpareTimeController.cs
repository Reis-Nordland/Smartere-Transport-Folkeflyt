﻿using EnTur.Facades;
using EnTur.Models;
using EnTur.Services;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EnTur.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class SpareTimeController : ControllerBase
    {
        private readonly IDirectionsService _directionsService;

        public SpareTimeController(IDirectionsService directionsService)
        {
            _directionsService = directionsService;
        }

        /// <summary>
        /// Get suggested places to visit
        /// </summary>
        /// <param name="fromLat">
        /// Latitude of your current location.
        /// </param>
        /// <param name="fromLon">
        /// Longitude of your current location.
        /// </param>
        /// <param name="toLat">
        /// Latitude of your destination, i.e. where you have to be after your spare time. For example the train station or harbor.
        /// </param>
        /// <param name="toLon">
        /// Longitude of your destination, i.e. where you have to be after your spare time. For example the train station or harbor.
        /// </param>
        /// <param name="type">
        /// The type of location you would like to visit in your spare time.
        /// </param>
        /// <param name="spareMinutes">
        /// Amount of time (in minutes) until you have to be at your destination.
        /// </param>
        /// <returns></returns>
        /// <remarks>
        /// Get a list of suggested places to visit (with suggested journey plan) while spending time in Bodø. Typical use case is something like arriving at the airport and transferring to the train station with a couple of hours spare time. 
        /// Takes in your current location, your destination, the type of location you want to visit and the amount of time you have before you have to be at your destination.
        /// </remarks>
        [HttpGet]
        public async Task<List<SpareTimeSuggestion>> SpareTime(double fromLat = 67.27201106674154,
            double fromLon = 14.351895205688761,
            double toLat = 67.28863567665056,
            double toLon = 14.39420973532621,
            string type = "mat",
            int spareMinutes = 120
           )
        {
            return await _directionsService.SpareTimeSuggestions(new Coordinates(fromLat, fromLon),
                new Coordinates(toLat, toLon),
                DateTime.UtcNow.AddMinutes(spareMinutes),
                type,
                "publictransport");
        }
    }
}
