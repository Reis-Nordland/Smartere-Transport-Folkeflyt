﻿using EnTur.Facades;
using EnTur.Models;
using EnTur.Services;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace EnTur.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class HealthController : ControllerBase
    {
        private readonly IDirectionsService _directionsService;
        private readonly IEnTurFacade _enTurFacade;
        private readonly IOttoFacade _ottoFacade;
        private readonly IOttoService _ottoService;

        public HealthController(IDirectionsService directionsService, IEnTurFacade enTurFacade, IOttoFacade ottoFacade, IOttoService ottoService)
        {
            _directionsService = directionsService;
            _enTurFacade = enTurFacade;
            _ottoFacade = ottoFacade;
            _ottoService = ottoService;
        }


        /// <summary>
        /// Health
        /// </summary>
        /// <remarks>
        /// Check health of the service
        /// </remarks>
        [HttpGet]
        public async Task<IActionResult> GetHealth()
        {
            var tripArray = await _directionsService.OttoRoutes(
                new Coordinates(67.27201106674154, 14.351895205688761),
                new Coordinates(67.28863567665056, 14.39420973532621), 
                10000000,
                "bike_or_scooter");

            var trip = tripArray[0];

            // Checks Folkeflyt Otto API, EnTur API and database connections
            if (trip.Legs[0] != null && trip.Legs[1] != null)
            {
                return Ok();
            }
            return StatusCode(500, "Internal Server Error.");
        }
    }
}




