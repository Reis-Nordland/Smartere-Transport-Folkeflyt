﻿using Newtonsoft.Json.Converters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace EnTur.Controllers
{

        [JsonConverter(typeof(StringEnumConverter))]
        public enum OttoVehicleTypeEnum
        {
            [EnumMember(Value = "bike")]
            bike,
            [EnumMember(Value = "scooter")]
            scooter,
            [EnumMember(Value = "bike_or_scooter")]
            bike_or_scooter,

    }
}
