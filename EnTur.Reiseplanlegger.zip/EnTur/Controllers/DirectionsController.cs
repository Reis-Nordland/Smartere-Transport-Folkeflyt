﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using EnTur.Controllers;
using EnTur.Facades;
using EnTur.Facades.EnTur;
using EnTur.Facades.Otto;
using EnTur.Mappers.EnturToRouteMapper;
using EnTur.Models;
using EnTur.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EnTur.Controllers
{
    [EnableCors("MyPolicy")]
    [ApiController]
    [Route("[controller]")]
    public class DirectionsController : ControllerBase
    {
        private readonly IDirectionsService _directionsService;
        private readonly IEnTurFacade _enTurFacade;
        private readonly IOttoService _ottoService;

        public DirectionsController(IDirectionsService directionsService, IEnTurFacade enTurFacade, IOttoService ottoService)
        {
            _directionsService = directionsService;
            _enTurFacade = enTurFacade;
            _ottoService = ottoService;
        }

        /// <summary>
        /// Get the optimal route from A to B given the transport mode and minutes available
        /// </summary>
        /// <remarks>
        /// This operation decides the optimal route from A to B given the transport mode and minutes available using the EnTur API in the background
        /// </remarks>
        [HttpGet()]
        public async Task<IEnumerable<Route>> RouteFinder(
            double fromLat = 67.27201106674154,
            double fromLon = 14.351895205688761,
            double toLat = 67.28863567665056,
            double toLon = 14.39420973532621,
            TransportTypeEnum transportType = TransportTypeEnum.walk)
        {
            return (await _enTurFacade.GetTripPlanner(new Coordinates(fromLat, fromLon), new Coordinates(toLat, toLon), Convert.ToString(transportType))).FromEnturToRoute();
        }

        /// <summary>
        /// Otto wayfinder
        /// </summary>
        /// <param name="vehicle_type">
        /// The desired vehicle to use. Defaults to bike_or_scooter if omitted.
        /// </param>
        /// <param name="fromLat"></param>
        /// <param name="fromLon"></param>
        /// <param name="toLat"></param>
        /// <param name="toLon"></param>
        /// <param name="maxWalkDistance">
        /// Maximum walking distance (to and from Otto locations) in meters.
        /// </param>
        /// <remarks>
        /// Finds the closest Otto stations to go from/to, and shows directions for the whole journey.
        /// </remarks>
        [HttpGet("FindOttoRoute")]
        public async Task<Route[]> OttoJourney(
            OttoVehicleTypeEnum? vehicle_type,
            double fromLat = 67.27201106674154,
            double fromLon = 14.351895205688761,
            double toLat = 67.28863567665056,
            double toLon = 14.39420973532621,
            double maxWalkDistance = 1000000
            )
        {

            string vehicleType;

            if (vehicle_type == null || vehicle_type == OttoVehicleTypeEnum.bike_or_scooter)
            {
                vehicleType = "any_except_car"; // The name for "bike or scooter" in the Otto API
            }
            else
            {
                vehicleType = Convert.ToString(vehicle_type);
            }


            return await _directionsService.OttoRoutes(
                new Coordinates(fromLat, fromLon),
                new Coordinates(toLat, toLon),
                maxWalkDistance,
                vehicleType);
        }


        [HttpGet("SaveOttoRoutes")]
        public async Task SaveOttoRoutes()
        {
            await _ottoService.GenerateAndSaveAllOttoRoutes();
        }

    }
}
