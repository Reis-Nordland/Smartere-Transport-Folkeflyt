﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EnTur.Configuration
{
    public class FolkeflytApiOptions
    {
        public string WeatherForecastUrl { get; set; }
        public string OttoBaseUrl { get; set; }
        public string PoiBaseUrl { get; set; }
        public string ApiKey { get; set; }
    }
}
