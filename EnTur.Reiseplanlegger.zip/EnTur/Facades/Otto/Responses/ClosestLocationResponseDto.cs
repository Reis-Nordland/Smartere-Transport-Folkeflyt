﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EnTur.Facades.Otto
{
    public class ClosestLocationResponseDto
    {
        public LocationsResponseDto Location { get; set; }
        public double DistanceInMeter { get; set; }
    }
}
