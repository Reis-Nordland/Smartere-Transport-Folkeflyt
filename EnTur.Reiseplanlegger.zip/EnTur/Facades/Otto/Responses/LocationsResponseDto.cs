﻿using System;
using Newtonsoft.Json;

namespace EnTur.Facades.Otto
{
    public class LocationsResponseDto
    {
        [JsonProperty("id")]
        public int Id { get; set; }

        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("address")]
        public string Address { get; set; }

        [JsonProperty("latitude")]
        public double Latitude { get; set; }

        [JsonProperty("longitude")]
        public double Longitude { get; set; }

        [JsonProperty("locked_garage")]
        public bool LockedGarage { get; set; }

        [JsonProperty("favourite")]
        public bool Favourite { get; set; }

        [JsonProperty("vehicle_support")]
        public VehicleSupportDto SupportedVehicles { get; set; }

        [JsonProperty("has_remote_opener")]
        public bool HasRemoteOpener { get; set; }
    }

    public class VehicleSupportDto
    {
        [JsonProperty("car")]
        public bool Car { get; set; }

        [JsonProperty("bike")]
        public bool Bike { get; set; }

        [JsonProperty("scooter")]
        public bool Scooter { get; set; }
    }
}
