﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using EnTur.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using EnTur.Models;

namespace EnTur.Facades.Otto
{
    public class OttoFacade : IOttoFacade
    {
        private readonly FolkeflytApiOptions _folkeflytApiOptions;
        private readonly IHttpClientFactory _clientFactory;

        public OttoFacade(IOptions<FolkeflytApiOptions> folkeflytApiOptions, IHttpClientFactory clientFactory)
        {
            _folkeflytApiOptions = folkeflytApiOptions.Value;
            _clientFactory = clientFactory;
        }

        public async Task<List<LocationsResponseDto>> GetAllStationsInBodo()
        {
            var httpClient = _clientFactory.CreateClient();
            string baseUrl = _folkeflytApiOptions.OttoBaseUrl;
            string requestUrl = baseUrl + $"/BodoLocations?vehicle_type=any_except_car";

            httpClient.DefaultRequestHeaders.Add("Ocp-Apim-Subscription-Key", _folkeflytApiOptions.ApiKey);

            var response = await httpClient.GetAsync(requestUrl);
            var content = await response.Content.ReadAsStringAsync();

            return JsonConvert.DeserializeObject<LocationsResponseDto[]>(content).ToList();
        }


        public async Task<ClosestLocationResponseDto> FindClosest(Coordinates coordinates, string vehicleType)
        {
            var httpClient = _clientFactory.CreateClient();
            string baseUrl = _folkeflytApiOptions.OttoBaseUrl;
            string requestUrl = baseUrl + $"/FindClosest?latitude={coordinates.Latitude}&longitude={coordinates.Longitude}&vehicle_type={vehicleType}";

            httpClient.DefaultRequestHeaders.Add("Ocp-Apim-Subscription-Key", _folkeflytApiOptions.ApiKey);

            var response = await httpClient.GetAsync(requestUrl);
            var content = await response.Content.ReadAsStringAsync();

            return JsonConvert.DeserializeObject<ClosestLocationResponseDto>(content);
        }


    }
}
