﻿using EnTur.Configuration;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace EnTur.Facades
{
    public class PoiFacade : IPoiFacade
    {
        private readonly FolkeflytApiOptions _folkeflytApiOptions;
        private readonly IHttpClientFactory _clientFactory;

        public PoiFacade(IOptions<FolkeflytApiOptions> folkeflytApiOptions, IHttpClientFactory clientFactory)
        {
            _folkeflytApiOptions = folkeflytApiOptions.Value;
            _clientFactory = clientFactory;
        }

        public async Task<PoiDto[]> GetPoi(string type)
        {
            var httpClient = _clientFactory.CreateClient();
            string baseUrl = _folkeflytApiOptions.PoiBaseUrl;
            string apiUrl = baseUrl + "/POI?type=" + type;

            httpClient.DefaultRequestHeaders.Add("Ocp-Apim-Subscription-Key", _folkeflytApiOptions.ApiKey);// = new AuthenticationHeaderValue("Ocp-Apim-Subscription-Key", "cbdfb5b8cf6845afa89eabf921b8a9ed"); // _configuration["WeatherForecastSubscriptionKey"]);

            var response = await httpClient.GetAsync(apiUrl);
            var content = await response.Content.ReadAsStringAsync();

            return JsonConvert.DeserializeObject<PoiDto[]>(content);
        }
    }
}
