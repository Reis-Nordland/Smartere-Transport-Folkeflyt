﻿
using EnTur.Models;

namespace EnTur.Facades
{
    public class PoiDto
    {

        public string id { get; set; }

        public string name { get; set; }

        public Coordinates coordinates { get; set; }  // using Coordinates model from Entur.Models

        public string adress { get; set; }

        public string type { get; set; }

        public OpeningHours openingHours { get; set; }

        public string[] weather { get; set; }

        public string[] season { get; set; }

        public float duration { get; set; }

        public string description { get; set; }

        public string pictureName { get; set; }

        public string pictureLink { get; set; }

        public string Url { get; set; }

    }

    public class OpeningHours
    {
        public Day monday { get; set; }

        public Day tuesday { get; set; }

        public Day wednesday { get; set; }

        public Day thursday { get; set; }

        public Day friday { get; set; }

        public Day saturday { get; set; }

        public Day sunday { get; set; }

        public string closedOnHoliday { get; set; }
    }

    public class Day
    {
        public string opens { get; set; }
        public string closes { get; set; }
    }
}
