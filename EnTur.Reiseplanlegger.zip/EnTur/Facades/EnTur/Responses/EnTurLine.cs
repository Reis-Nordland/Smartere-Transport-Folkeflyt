﻿namespace EnTur.Facades.EnTur
{ 
    public class EnTurLine
    {
        public string Id { get; set; }
        public string PublicCode { get; set; }
    }
}