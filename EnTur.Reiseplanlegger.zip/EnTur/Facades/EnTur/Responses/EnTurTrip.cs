﻿namespace EnTur.Facades.EnTur
{
    public class EnTurTrip
    {
        public EnTurTripPattern[] TripPatterns { get; set; }
    }
}