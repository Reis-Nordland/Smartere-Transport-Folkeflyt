﻿using MongoDB.Bson.Serialization.Attributes;

namespace EnTur.Facades.EnTur
{
    public class EnTurJourneyPlanResult
    {
        [BsonElement("_id")]
        public string Id { get; set; }

        [BsonElement("trip")]
        public EnTurTrip Trip { get; set; }
    }
}