﻿namespace EnTur.Facades.EnTur
{
    public class EnTurPlace
    {
        public string Name { get; set; }
    }
}