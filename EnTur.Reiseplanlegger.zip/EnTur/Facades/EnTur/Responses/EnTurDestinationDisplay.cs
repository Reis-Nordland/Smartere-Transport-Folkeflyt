﻿namespace EnTur.Facades.EnTur
{
    public class EnTurDestinationDisplay
    {
        public string FrontText { get; set; }
    }
}