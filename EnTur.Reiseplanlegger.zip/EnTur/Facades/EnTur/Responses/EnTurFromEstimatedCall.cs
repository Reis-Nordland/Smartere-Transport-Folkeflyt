﻿namespace EnTur.Facades.EnTur
{
    public class EnTurFromEstimatedCall
    {
        public EnTurDestinationDisplay DestinationDisplay { get; set; }
    }
}