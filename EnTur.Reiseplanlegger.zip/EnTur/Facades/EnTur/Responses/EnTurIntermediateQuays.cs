﻿namespace EnTur.Facades.EnTur
{
    public class EnTurIntermediateQuay
    {
        public string Name { get; set; }
    }
}