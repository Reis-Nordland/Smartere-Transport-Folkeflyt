﻿using System;

namespace EnTur.Facades.EnTur
{
    public class EnTurLegs
    {
        public string Mode { get; set; }
        public double Distance { get; set; }
        public double Duration { get; set; }
        public DateTime ExpectedStartTime { get; set; }

        public EnTurLine Line { get; set; }
        public EnTurFromEstimatedCall FromEstimatedCall { get; set; }
        public EnTurPointsOnLink PointsOnLink { get; set; }
        public EnTurIntermediateQuay[] IntermediateQuays { get; set; }
        public EnTurPlace FromPlace { get; set; }
        public EnTurPlace ToPlace { get; set; }

    }
}