﻿namespace EnTur.Facades.EnTur
{
    public class EnTurPointsOnLink
    {
        public string Points { get; set; }
        public int Length { get; set; }
    }
}