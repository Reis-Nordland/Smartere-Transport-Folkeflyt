﻿using GraphQL;
using GraphQL.Client.Http;
using GraphQL.Client.Serializer.Newtonsoft;
using Microsoft.Extensions.Options;
using Newtonsoft.Json.Linq;
using EnTur.Configuration;
using EnTur.Facades.EnTur;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EnTur.Models;

namespace EnTur.Facades.Entur
{
    public class EnTurFacade : IEnTurFacade
    {
        private readonly EnTurApiOptions _apiOptions;

        public EnTurFacade(IOptions<EnTurApiOptions> apiOptions)
        {
            _apiOptions = apiOptions.Value;
        }

        public async Task<EnTurJourneyPlanResult> GetTripPlanner(Coordinates origin, Coordinates destination, string transportType, DateTime? departureTime = null)
        {
            var graphQLClient = new GraphQLHttpClient(_apiOptions.BaseUri, new NewtonsoftJsonSerializer());
            graphQLClient.HttpClient.DefaultRequestHeaders.Add("ET-Client-Name", _apiOptions.ClientName);

            var enturTransportMode = TransportTypeToEnturModeMapper.GetEnturMode(transportType);


            if (departureTime is null)
            {
                departureTime = DateTime.UtcNow;
            }
            

            var request = new GraphQLRequest
            {
                Query = @"{
  trip(
    from: {
    
    coordinates: {
      latitude: " + origin.Latitude.ToString().Replace(',', '.') + @"
      longitude: " + origin.Longitude.ToString().Replace(',', '.') + @"
    }}

    to: {
      
      coordinates: {
      latitude: " + destination.Latitude.ToString().Replace(',', '.') + @"
      longitude: " + destination.Longitude.ToString().Replace(',', '.') + @"
    }
    }
    dateTime: " + "\"" + departureTime?.ToString("yyyy-MM-ddTHH:mm:sszzz") + "\"" + @"
    numTripPatterns: 3
    minimumTransferTime: 180
    walkSpeed: 1.3
    wheelchair: false
    arriveBy: false
    modes: " + enturTransportMode + @"
  )

#### Requested fields
  {
    tripPatterns {
      startTime
      duration
      walkDistance

          legs {
          
            mode
            distance
            duration
            expectedStartTime
            line {
              publicCode
            }
            fromEstimatedCall {
              destinationDisplay {
                frontText
              }
            }
            intermediateQuays {
              name
            }
            pointsOnLink {
              points
              length
            }
            fromPlace {
              name
            }
            toPlace {
              name
            }
        }
    }
  }
}"
            };


            var response = await graphQLClient.SendQueryAsync<EnTurJourneyPlanResult>(request);
            //dynamic travelPlan = JObject.Parse(response.Data.ToString());
            return response.Data;
        }

        internal static class TransportTypeToEnturModeMapper
        {

            public static string GetEnturMode(string transportType)
            {
                switch (transportType)
                {
                    case "walk":
                        return "foot";
                    case "publictransport":
                        return "[bus, foot]";
                    case "bike":
                        return "bicycle";
                    default:
                        return "foot";
                }
            }
        }
    }
}


