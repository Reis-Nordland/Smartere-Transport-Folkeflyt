﻿using EnTur.Facades.EnTur;
using EnTur.Models;
using System;
using System.Threading.Tasks;

namespace EnTur.Facades
{
    public interface IEnTurFacade
    {
        Task<EnTurJourneyPlanResult> GetTripPlanner(Coordinates origin, Coordinates destination, string transportType, DateTime? departureTime = null);
    }
}