﻿using EnTur.Facades.Otto;
using EnTur.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace EnTur.Facades
{
    public interface IOttoFacade
    {
        Task<ClosestLocationResponseDto> FindClosest(Coordinates coordinates, string vehicleType);
        Task<List<LocationsResponseDto>> GetAllStationsInBodo();
    }
}