﻿using System.Threading.Tasks;

namespace EnTur.Facades
{
    public interface IPoiFacade
    {
        Task<PoiDto[]> GetPoi(string type);
    }
}