﻿using EnTur.Facades.Weather;
using System.Threading.Tasks;

namespace EnTur.Facades
{
    public interface IWeatherFacade
    {
        Task<WeatherForecastDto> GetWeatherForecast(int hourDuration);
    }
}