﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace React_Core_Boilerplate__JavaScript_1.Models
{
    public class ServiceUser
    {
        public string Login { get; set; }
    }
}
