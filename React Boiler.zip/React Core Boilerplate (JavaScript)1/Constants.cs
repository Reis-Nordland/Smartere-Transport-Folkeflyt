﻿namespace React_Core_Boilerplate__JavaScript_1
{
    public static class Constants
    {
        public static string AuthorizationCookieKey => "Auth";
        public static string HttpContextServiceUserItemKey => "ServiceUser";
    }
}
