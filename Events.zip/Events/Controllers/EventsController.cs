﻿using Events.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Events.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class EventsController : ControllerBase
    {
        /// <summary>
        /// Events
        /// </summary>>
        /// <remarks>
        /// Get events from Facebook page
        /// </remarks>
        [HttpGet]
        public async Task<string> GetEvents()
        {
            return "Test";
        }
    }
}
