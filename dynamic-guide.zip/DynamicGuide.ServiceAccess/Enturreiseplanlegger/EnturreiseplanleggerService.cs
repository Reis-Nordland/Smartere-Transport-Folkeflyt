﻿using DynamicGuide.ServiceAccess.Enturreiseplanlegger.Client;
using System.Threading.Tasks;

namespace DynamicGuide.ServiceAccess.Enturreiseplanlegger
{
    public class EnturreiseplanleggerService : IEnturreiseplanleggerService
    {
        private readonly IClient _client;

        public EnturreiseplanleggerService(IClient client)
        {
            _client = client;
        }

        public async Task<StopPlace> GetStopPlace(string stopPlaceId, string transportType, int? timeRange, int? numberOfDepartures)
        {
            var results = await _client.StopPlace_GetAsync(stopPlaceId, transportType, timeRange, numberOfDepartures);
            return results;
        }

        public async Task<Estimatedcall> GetNextBus(int? timeRange, int? numberOfDepartures)
        {
            var results = await _client.StopPlace_GetNextBusFromBodøAirportAsync(timeRange, numberOfDepartures);
            return results;
        }
    }
}
