﻿using DynamicGuide.ServiceAccess.Enturreiseplanlegger.Client;
using System.Threading.Tasks;

namespace DynamicGuide.ServiceAccess.Enturreiseplanlegger
{
    public interface IEnturreiseplanleggerService
    {
        Task<StopPlace> GetStopPlace(string stopPlaceId, string transportType, int? timeRange, int? numberOfDepartures);

        Task<Estimatedcall> GetNextBus(int? timeRange, int? numberOfDepartures);
    }
}
