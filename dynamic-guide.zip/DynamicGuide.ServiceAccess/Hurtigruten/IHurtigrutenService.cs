﻿using DynamicGuide.ServiceAccess.Hurtigruten.Client;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace DynamicGuide.ServiceAccess.Hurtigruten
{
    public interface IHurtigrutenService
    {
        Task<ICollection<DepartureModel>> GetTimetable(string dock);
    }
}
