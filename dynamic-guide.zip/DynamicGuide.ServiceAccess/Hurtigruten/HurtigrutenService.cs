﻿using DynamicGuide.ServiceAccess.Hurtigruten.Client;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace DynamicGuide.ServiceAccess.Hurtigruten
{
    public class HurtigrutenService : IHurtigrutenService
    {
        private readonly IClient _client;

        public HurtigrutenService(IClient client)
        {
            _client = client;
        }

        public async Task<ICollection<DepartureModel>> GetTimetable(string dock)
        {
            var results = await _client.Timetable_GetAsync(dock);
            return results;
        }
    }
}
