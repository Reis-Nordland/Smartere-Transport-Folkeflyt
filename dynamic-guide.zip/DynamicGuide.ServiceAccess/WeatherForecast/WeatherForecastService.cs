﻿using System.Threading.Tasks;
using DynamicGuide.ServiceAccess.WeatherForecast.Client;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Core;

namespace DynamicGuide.ServiceAccess.WeatherForecast
{
    public class WeatherForecastService : IWeatherForecastService
    {
        private readonly IClient _client;

        public WeatherForecastService(IClient client)
        {
            _client = client;
        }

        public async Task<WeatherForecastDto> GetWeather(int? startHour, int? hourDuration, double? latitude, double? longitude)
        {
            var results = await _client.Weather_GetAsync(startHour, hourDuration, latitude, longitude);
            return results;
        }
    }
}
