﻿using DynamicGuide.ServiceAccess.WeatherForecast.Client;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace DynamicGuide.ServiceAccess.WeatherForecast
{
    public interface IWeatherForecastService
    {
        Task<WeatherForecastDto> GetWeather(int? startHour, int? hourDuration, double? latitude, double? longitude);
    }
}
