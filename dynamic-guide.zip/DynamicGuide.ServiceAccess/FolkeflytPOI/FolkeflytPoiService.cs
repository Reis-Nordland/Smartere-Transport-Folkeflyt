﻿using DynamicGuide.ServiceAccess.FolkeflytPOI.Client;
using System.Threading.Tasks;

namespace DynamicGuide.ServiceAccess.FolkeflytPOI
{
    public class FolkeflytPoiService : IFolkeflytPoiService
    {
        private readonly IClient _client;

        public FolkeflytPoiService(IClient client)
        {
            _client = client;
        }

        public async Task<Route> GetRoute(string startPOIID, string endPOIID, float? minutesAvailable, string transportMode)
        {
            var results = await _client.Route_GetRouteAsync(startPOIID, endPOIID, minutesAvailable, transportMode);
            return results;
        }
    }
}
