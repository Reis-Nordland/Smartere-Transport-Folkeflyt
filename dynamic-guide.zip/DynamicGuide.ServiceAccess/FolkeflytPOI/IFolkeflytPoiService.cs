﻿using DynamicGuide.ServiceAccess.FolkeflytPOI.Client;
using System.Threading.Tasks;

namespace DynamicGuide.ServiceAccess.FolkeflytPOI
{
    public interface IFolkeflytPoiService
    {
        Task<Route> GetRoute(string startPOIID, string endPOIID, float? minutesAvailable, string transportMode);
    }
}