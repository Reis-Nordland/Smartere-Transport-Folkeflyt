using DynamicGuide.ServiceAccess.Enturreiseplanlegger;
using DynamicGuide.ServiceAccess.Hurtigruten;
using DynamicGuide.ServiceAccess.FolkeflytPOI;
using DynamicGuide.ServiceAccess.WeatherForecast;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.SpaServices.ReactDevelopmentServer;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using System;
using EnturreiseplanleggerClient = DynamicGuide.ServiceAccess.Enturreiseplanlegger.Client;
using FolkeflytPoiClient = DynamicGuide.ServiceAccess.FolkeflytPOI.Client;
using HurtigRutenClient = DynamicGuide.ServiceAccess.Hurtigruten.Client;
using WeatherForecastClient = DynamicGuide.ServiceAccess.WeatherForecast.Client;


namespace DynamicGuide.API
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            var apimSubscriptionHeader = "Ocp-Apim-Subscription-Key";

            services.AddHttpClient<EnturreiseplanleggerClient.IClient, EnturreiseplanleggerClient.Client>("Enturreiseplanlegger", c =>
            {
                c.BaseAddress = new Uri(Configuration["EnturreiseplanleggerApiUrl"]);
                c.DefaultRequestHeaders.Add(apimSubscriptionHeader, Configuration["SubscriptionKey"]);
            });

            services.AddHttpClient<FolkeflytPoiClient.IClient, FolkeflytPoiClient.Client>("FolkeflytPoi", c =>
            {
                c.BaseAddress = new Uri(Configuration["FolkeflytPoiApiUrl"]);
                c.DefaultRequestHeaders.Add(apimSubscriptionHeader, Configuration["SubscriptionKey"]);
            });

            services.AddHttpClient<HurtigRutenClient.IClient, HurtigRutenClient.Client>("HurtigRuten", c =>
            {
                c.BaseAddress = new Uri(Configuration["HurtigrutenApiUrl"]);
                c.DefaultRequestHeaders.Add(apimSubscriptionHeader, Configuration["SubscriptionKey"]);
            });

            services.AddHttpClient<WeatherForecastClient.IClient, WeatherForecastClient.Client>("WeatherForecast", c =>
            {
                c.BaseAddress = new Uri(Configuration["WeatherForecastApiUrl"]);
                c.DefaultRequestHeaders.Add(apimSubscriptionHeader, Configuration["SubscriptionKey"]);
            });

            services.AddTransient<IEnturreiseplanleggerService, EnturreiseplanleggerService>();
            services.AddTransient<IFolkeflytPoiService, FolkeflytPoiService>();
            services.AddTransient<IHurtigrutenService, HurtigrutenService>();
            services.AddTransient<IWeatherForecastService, WeatherForecastService>();

            services.AddControllersWithViews();

            // In production, the React files will be served from this directory
            services.AddSpaStaticFiles(configuration =>
            {
                configuration.RootPath = "ClientApp/build";
            });
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseStaticFiles();
            app.UseSpaStaticFiles();

            app.UseRouting();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllerRoute(
                    name: "default",
                    pattern: "{controller}/{action=Index}/{id?}");
            });

            app.UseSpa(spa =>
            {
                spa.Options.SourcePath = "ClientApp";

                if (env.IsDevelopment())
                {
                    spa.UseReactDevelopmentServer(npmScript: "start");
                }
            });
        }
    }
}
