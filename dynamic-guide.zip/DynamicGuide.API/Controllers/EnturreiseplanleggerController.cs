﻿using DynamicGuide.ServiceAccess.Enturreiseplanlegger;
using DynamicGuide.ServiceAccess.Enturreiseplanlegger.Client;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Threading.Tasks;

namespace DynamicGuide.API.Controllers
{
    [ApiController]
    public class EnturreiseplanleggerController : ControllerBase
    {
        private readonly ILogger<EnturreiseplanleggerController> _logger;
        private readonly IEnturreiseplanleggerService _service;

        public EnturreiseplanleggerController(ILogger<EnturreiseplanleggerController> logger, IEnturreiseplanleggerService service)
        {
            _logger = logger;
            _service = service;
        }

        [HttpGet]
        [Route("api/[controller]/stopplace")]
        public async Task<StopPlace> GetStopPlace(string stopPlaceId, string transportType, int? timeRange, int? numberOfDepartures)
        {
            var data = await _service.GetStopPlace(stopPlaceId, transportType, timeRange, numberOfDepartures);
            return data;
        }

        [HttpGet]
        [Route("api/[controller]/stopplace/nextbus")]
        public async Task<Estimatedcall> GetNextBus(int? timeRange, int? numberOfDepartures)
        {
            var data = await _service.GetNextBus(timeRange, numberOfDepartures);
            return data;
        }
    }
}
