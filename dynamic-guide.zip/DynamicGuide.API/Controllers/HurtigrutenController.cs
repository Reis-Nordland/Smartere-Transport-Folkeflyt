﻿using DynamicGuide.ServiceAccess.Hurtigruten;
using DynamicGuide.ServiceAccess.Hurtigruten.Client;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace DynamicGuide.API.Controllers
{
    [ApiController]
    public class HurtigrutenController : ControllerBase
    {
        private readonly ILogger<HurtigrutenController> _logger;
        private readonly IHurtigrutenService _service;

        public HurtigrutenController(ILogger<HurtigrutenController> logger, IHurtigrutenService service)
        {
            _logger = logger;
            _service = service;
        }

        [HttpGet]
        [Route("api/[controller]/timetable")]
        public async Task<ICollection<DepartureModel>> GetTimetable(string dock = "bodo")
        {
            var data = await _service.GetTimetable(dock);
            return data;
        }
    }
}
