﻿using DynamicGuide.ServiceAccess.WeatherForecast;
using DynamicGuide.ServiceAccess.WeatherForecast.Client;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Threading.Tasks;

namespace DynamicGuide.API.Controllers
{
    [ApiController]
    public class WeatherForecastController : ControllerBase
    {
        private readonly ILogger<WeatherForecastController> _logger;
        private readonly IWeatherForecastService _service;

        public WeatherForecastController(ILogger<WeatherForecastController> logger, IWeatherForecastService service)
        {
            _logger = logger;
            _service = service;
        }

        [HttpGet]
        [Route("api/[controller]/weather")]
        public async Task<WeatherForecastDto> GetWeather(int? startHour, int? hourDuration, double? latitude, double? longitude)
        {
            var data = await _service.GetWeather(startHour, hourDuration, latitude, longitude);
            return data;
        }
    }
}
