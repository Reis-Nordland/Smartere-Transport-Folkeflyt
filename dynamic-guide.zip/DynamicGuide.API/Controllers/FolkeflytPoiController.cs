﻿using DynamicGuide.ServiceAccess.FolkeflytPOI;
using DynamicGuide.ServiceAccess.FolkeflytPOI.Client;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Threading.Tasks;

namespace DynamicGuide.API.Controllers
{
    [ApiController]
    public class FolkeflytPoiController : ControllerBase
    {
        private readonly ILogger<FolkeflytPoiController> _logger;
        private readonly IFolkeflytPoiService _service;

        public FolkeflytPoiController(ILogger<FolkeflytPoiController> logger, IFolkeflytPoiService service)
        {
            _logger = logger;
            _service = service;
        }

        [HttpGet]
        [Route("api/[controller]/route")]
        public async Task<Route> GetRoute(string startPOIID, string endPOIID, float? minutesAvailable, string transportMode)
        {
            var data = await _service.GetRoute(startPOIID, endPOIID, minutesAvailable, transportMode);
            return data;
        }
    }
}
