import React from "react";
import PropTypes from "prop-types";

export default function LuggageSvg({ tittel }) {
  return (
      <div>
        <svg xmlns="http://www.w3.org/2000/svg" xmlnsXlink="http://www.w3.org/1999/xlink" width="228" height="76" viewBox="0 0 228 76">
          <defs>
            <path id="b-luggSvg" d="M28 13h189v49H28z"/>
            <filter id="a-luggSvg" width="118.5%" height="171.4%" x="-9.3%" y="-31.6%" filterUnits="objectBoundingBox">
              <feMorphology in="SourceAlpha" operator="dilate" radius="1" result="shadowSpreadOuter1"/>
              <feOffset dy="2" in="shadowSpreadOuter1" result="shadowOffsetOuter1"/>
              <feGaussianBlur in="shadowOffsetOuter1" result="shadowBlurOuter1" stdDeviation="4.5"/>
              <feColorMatrix in="shadowBlurOuter1" values="0 0 0 0 0.576470588 0 0 0 0 0.584313725 0 0 0 0 0.592156863 0 0 0 0.499399038 0"/>
            </filter>
            <path id="c-luggSvg" d="M0 31h26V0H0z"/>
          </defs>
          <g fill="none" fillRule="evenodd">
            <use fill="#000" filter="url(#a-luggSvg)" xlinkHref="#b-luggSvg"/>
            <use fill="#FFF" xlinkHref="#b-luggSvg"/>
            <text fill="#292929" fontFamily="AvinorBold, Avinor" fontSize="14" >
              <tspan x="80" y="36">Luggage Storage</tspan>
            </text>
            <text fill="#292929" fontFamily="Avinor-Light, Avinor" fontSize="11" fontWeight="300">
              <tspan x="80" y="53">{tittel}</tspan>
            </text>
            <circle cx="38" cy="38" r="38" fill="#FFF" fillOpacity=".682"/>
            <g transform="translate(10 10)">
              <circle cx="28.5" cy="28.5" r="28.5" fill="#7D1B6B"/>
              <g transform="translate(15 13)">
                <path fill="#FFF" d="M4.68 24.58v-6.848c0-.848.863-1.494 1.8-1.494H7.8v9.841H6.48c-.914 0-1.8-.547-1.8-1.5"/>
                <mask id="d-luggSvg" fill="#fff">
                  <use xlinkHref="#c-luggSvg"/>
                </mask>
                <path fill="#FFF" d="M11.446 16.073h2.546v-1.482h-2.546v1.482zm3.27 0v-1.438c0-.526-.433-.857-.967-.857h-2.03c-.528 0-.974.331-.974.857v1.438H8.84v10.006h7.8V16.073h-1.923zM19 26.08h-1.32v-9.842H19c.938 0 1.8.646 1.8 1.494v6.848c0 .952-.884 1.5-1.8 1.5" mask="url(#d-luggSvg)"/>
                <path fill="#FFF" d="M3.038 27.881h19.8v-15.2h-19.8v15.2zM0 31h26V9.841H0V31z" mask="url(#d-luggSvg)"/>
                <path fill="#FFF" d="M6.48 16.238H7.8v9.841H6.48c-.915 0-1.8-.547-1.8-1.5v-6.847c0-.848.863-1.494 1.8-1.494M11.446 16.073h2.546v-1.482h-2.546v1.482zm3.27 0v-1.438c0-.526-.433-.857-.967-.857h-2.03c-.528 0-.974.331-.974.857v1.438H8.84v10.006h7.8V16.073h-1.923zM20.8 17.732v6.848c0 .952-.885 1.5-1.8 1.5h-1.32v-9.842H19c.938 0 1.8.646 1.8 1.494M5.739 5.553c-.695 0-1.25-.535-1.25-1.192 0-.657.555-1.185 1.25-1.185.688 0 1.248.528 1.248 1.185s-.56 1.192-1.248 1.192m16.963-1.81L21.13 2.235h-9.366S10.692 0 7.77 0C5.198 0 3.12 1.984 3.12 4.432c0 2.448 2.078 4.425 4.65 4.425 3.32 0 4.082-2.274 4.082-2.274h1.809l1.444-1.398 1.112 1.076 1.114-1.076 1.114 1.076 1.133-1.095 1.154 1.121.027-.006 1.95-1.881c.222-.213.236-.42-.007-.657" mask="url(#d-luggSvg)"/>
                <path fill="#FFF" d="M11.446 16.073h2.546v-1.482h-2.546v1.482zm3.27 0v-1.438c0-.526-.433-.857-.967-.857h-2.03c-.528 0-.974.331-.974.857v1.438H8.84v10.006h7.8V16.073h-1.923zM7.8 16.238v9.841H6.48c-.914 0-1.8-.547-1.8-1.5v-6.847c0-.848.863-1.494 1.8-1.494H7.8zM20.8 17.732v6.848c0 .952-.885 1.5-1.8 1.5h-1.32v-9.842H19c.938 0 1.8.646 1.8 1.494" mask="url(#d-luggSvg)"/>
              </g>
            </g>
          </g>
        </svg>
      </div>
  );
}

LuggageSvg.propTypes = {
  tittel: PropTypes.string
};
