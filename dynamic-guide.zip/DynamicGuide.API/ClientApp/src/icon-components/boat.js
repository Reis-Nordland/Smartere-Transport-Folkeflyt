import React from "react";
export default function BoatSvg() {
  return (
      <div
          style={{
            padding: '2rem 0',
            marginRight: '0.5rem'
          }}
      >
        <svg width="55px" height="55px" viewBox="0 0 55 55" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlnsXlink="http://www.w3.org/1999/xlink">
          <title>F6E651FF-C882-479C-8426-61058D26CB5A</title>
          <desc>Created with sketchtool.</desc>
          <defs>
            <polygon id="path-1" points="7.74647887e-05 0.185915493 54.9891549 0.185915493 54.9891549 55 7.74647887e-05 55"></polygon>
          </defs>
          <g id="Page-1" stroke="none" strokeWidth="1" fill="none" fillRule="evenodd">
            <g id="Startpage-1920x1080-Copy" transform="translate(-908.000000, -517.000000)">
              <g id="Group-14-Copy" transform="translate(908.000000, 517.000000)">
                <g id="Group-3">
                  <mask id="mask-2" fill="white">
                    <use xlinkHref="#path-1"></use>
                  </mask>
                  <g id="Clip-2"></g>
                  <path d="M27.4946549,55.0003873 C12.3092324,55.0003873 7.74647887e-05,42.7268662 7.74647887e-05,27.5925704 C7.74647887e-05,12.4575 12.3092324,0.185528169 27.4946549,0.185528169 C42.6800775,0.185528169 54.9892324,12.4575 54.9892324,27.5925704 C54.9892324,42.7268662 42.6800775,55.0003873 27.4946549,55.0003873" id="Fill-1" fill="#000000" mask="url(#mask-2)"></path>
                </g>
                <path d="M5.73895491,38 C5.09674949,38 4.82173994,37.5060631 5.12076441,36.9096801 L8.1714338,31 L50,31 L46.3776206,38 L5.73895491,38 Z" id="Fill-4" fill="#FFFFFF"></path>
                <polygon id="Fill-6" fill="#FFFFFF" points="13 29 14.688959 26 41.4005669 26 42 29"></polygon>
                <path d="M23,24 L25.0946966,19.4347455 C25.2010305,19.1998633 25.4496758,19 25.669539,19 L30.7623701,19 C30.9918273,19 31.204495,19.1998633 31.2484676,19.4347455 L32,24 L23,24 Z" id="Fill-8" fill="#FFFFFF"></path>
                <path d="M18.4457731,14.6376783 C18.3729415,14.2203041 18.01024,13.947465 17.6154925,14.0085253 C17.213462,14.074996 16.9388867,14.4676369 17.0117184,14.876509 L18.5178764,24 L20,24 L18.4457731,14.6376783 Z" id="Fill-10" fill="#FFFFFF"></path>
                <path d="M35.445062,14.6376783 C35.3729595,14.2203041 35.002979,13.947465 34.6075076,14.0085253 C34.2127646,14.074996 33.9389207,14.4676369 34.0117515,14.876509 L35.5178929,24 L37,24 L35.445062,14.6376783 Z" id="Fill-12" fill="#FFFFFF"></path>
              </g>
            </g>
          </g>
        </svg>
      </div>
  );
}
