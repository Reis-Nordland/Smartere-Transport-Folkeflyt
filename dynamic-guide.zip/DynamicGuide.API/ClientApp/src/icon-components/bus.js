import React from "react";
import PropTypes from "prop-types";

export default function Bus({ className, viewBox }) {
  return (
    <svg
      className={className}
      viewBox={viewBox}
      xmlns="http://www.w3.org/2000/svg"
    >
      <defs>
        <style>{".cls-2{fill:#fff}"}</style>
      </defs>
      <g id="Layer_2" data-name="Layer 2">
        <g id="Layer_2-2" data-name="Layer 2">
          <path
            d="M58.74 8s-1.07-4.2-1.41-5.52h.79a.4.4 0 0 0 .4-.4V.4a.4.4 0 0 0-.4-.4H.81A.8.8 0 0 0 0 .8v19.56a.81.81 0 0 0 .81.81h7.57a4.26 4.26 0 0 0 8.5 0h19.24a4.26 4.26 0 0 0 8.5 0h13.5a.81.81 0 0 0 .81-.81V10.27A8.51 8.51 0 0 0 58.74 8"
            fill="#113f5f"
          />
          <path
            class="cls-2"
            d="M57.32 12.56a.4.4 0 0 0 .4-.4v-1.94a7.59 7.59 0 0 0-.17-2L56.2 2.87a.4.4 0 0 0-.4-.4h-1.72a.8.8 0 0 0-.81.8v8.48a.8.8 0 0 0 .81.8h3.24zM50 18.71a.8.8 0 0 0 .8-.81V3.23a.8.8 0 0 0-.8-.8h-4.3a.81.81 0 0 0-.81.8V17.9a.81.81 0 0 0 .81.81zM41.73 10.52a.8.8 0 0 0 .81-.8V3.23a.8.8 0 0 0-.81-.8H32a.8.8 0 0 0-.8.8v6.49a.8.8 0 0 0 .8.8zM4 2.43h9.7a.8.8 0 0 1 .8.8v6.49a.8.8 0 0 1-.8.8H4a.8.8 0 0 1-.8-.8V3.24a.81.81 0 0 1 .8-.81zM27.72 10.52a.8.8 0 0 0 .8-.8V3.23a.8.8 0 0 0-.8-.8H18a.8.8 0 0 0-.81.8v6.49a.8.8 0 0 0 .81.8z"
          />
        </g>
      </g>
    </svg>
  );
}

Bus.propTypes = {
  className: PropTypes.string
};

Bus.defaultProps = {
  className: undefined,
  viewBox: "0 0 58.94 25.12"
};
