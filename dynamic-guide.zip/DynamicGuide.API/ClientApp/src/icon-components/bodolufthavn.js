import React from "react";
import {DEFAULT_ZOOM} from "../screens/map/components/simple-map/simple-map";

export default function BodoLufthavn({currentZoom}) {
  return (
      <div>
        <svg xmlns="http://www.w3.org/2000/svg" xmlnsXlink="http://www.w3.org/1999/xlink" width="250" height="250" viewBox="0 0 337 295">
          <defs>
            <filter id="a" width="100%" height="100%" x="0%" y="0%" filterUnits="objectBoundingBox">
              <feGaussianBlur in="SourceGraphic"/>
            </filter>
            <path id="b" d="M0 .343h96.658V133H0z"/>
            <path id="d" d="M0 .187h54.99V55H0z"/>
          </defs>
          <g fill="none" fillRule="evenodd">
            <text fill="#7D1B6B" fontFamily="AvinorBold, Avinor" fontSize="25" transform="translate(65 -48)">
              <tspan x="0" y="288">YOU ARE HERE</tspan>
            </text>
            {
              currentZoom <= DEFAULT_ZOOM &&
              (
                    <>
                      <path fill="#8AD8C5" fillOpacity=".323" d="M29 225l86.81-191a209.951 209.951 0 0 1 89.727 77.398A209.6 209.6 0 0 1 239 225H29z" filter="url(#a)" opacity=".9" transform="rotate(-23 50.536 -64.073)"/>
                      <path stroke="#000" strokeDasharray="11,11" strokeLinecap="square" strokeWidth="3" d="M147.032 207.327L259.5 46.557"/>
                      <text fill="#000" fontFamily="AvinorBold, Avinor" fontSize="18" transform="rotate(20 311.488 258.598)">
                        <tspan x="117.377" y="93.939">5 min</tspan>
                      </text>
                      <g fill="#000">
                        <path d="M176.542 13.307c.512-1.576 1.992-2.507 3.305-2.08 1.313.426 1.963 2.05 1.45 3.625-.511 1.576-1.99 2.507-3.304 2.08-1.313-.426-1.963-2.05-1.45-3.625M180.147 21.14c-.008-1.518-.855-2.873-2.18-3.484-1.323-.61-2.888-.368-4.023.624l-5.29 4.625-1.555 4.788c-.211.65.121 1.34.742 1.543.621.201 1.296-.162 1.507-.812l1.148-3.532 1.157-1.013-3.755 11.557-4.08 4.575c-.602.675-.576 1.715.058 2.322.634.606 1.637.551 2.239-.124l5.34-5.989 1.31-4.03.173 11.94c.015.998.806 1.773 1.768 1.73.962-.042 1.73-.884 1.716-1.882l-.2-13.755 1.571-4.836.033 6.504c-.006.446.221.855.593 1.067.372.213.831.198 1.201-.04.37-.238.592-.66.582-1.106l-.055-10.672z"/>
                      </g>
                    </>
              )
            }
            <g>
              <g transform="translate(97.514 79)">
                <mask id="c" fill="#fff">
                  <use xlinkHref="#b"/>
                </mask>
                <path fill="#7D1B6B" d="M96.658 48.67c0 26.693-48.33 84.33-48.33 84.33S0 75.364 0 48.67C0 21.98 21.636.344 48.328.344c26.692 0 48.33 21.636 48.33 48.328" mask="url(#c)"/>
              </g>
              <path fill="#FFF" d="M119.514 131.001c0-14.361 11.642-26.001 26-26.001 14.36 0 26 11.64 26 26.001 0 14.359-11.64 25.999-26 25.999-14.358 0-26-11.64-26-25.999"/>
            </g>
            <g>
              <g transform="translate(0 240)">
                <mask id="e" fill="#fff">
                  <use xlinkHref="#d"/>
                </mask>
                <path fill="#000" d="M27.495 55c15.185 0 27.496-12.27 27.496-27.405C54.99 12.459 42.68.187 27.495.187 12.31.187 0 12.459 0 27.595 0 42.73 12.31 55 27.495 55" mask="url(#e)"/>
              </g>
              <path fill="#FFF" d="M25.584 247.314c.004-3.1 4.581-3.1 4.578.086v13.01L48 271.357v4.807l-17.753-5.965v9.723l4.11 3.277V287l-6.334-2.01-6.334 2.01v-3.801l4.066-3.277v-9.723L8 276.164v-4.807l17.584-10.947v-13.096z"/>
            </g>
            <text fill="#292929" fontFamily="AvinorBold, Avinor" fontSize="18" transform="translate(0 -48)">
              <tspan x="72" y="327">BODØ AIRPORT</tspan>
            </text>
          </g>
        </svg>
      </div>
  );
}
