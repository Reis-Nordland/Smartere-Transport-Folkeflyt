import React, { Component } from "react";
import styled from "styled-components";
import { getWeather } from "api-requests/weather-api";

const WeatherText = styled.p`
  margin-right: 15px;
  height: 42px;
  font-family: Avinor;
  font-size: 35px;
  color: #ffffff;
  text-align: center;
`;

const WeatherContainer = styled.div`
  display: flex;
  flex-direction: row;
  justify-content: center;
  align-items: center;
`;

class Weather extends Component {
  state = {
    temperature: 0,
    symbol: 1
  };

  async componentDidMount() {
    const request = await getWeather();
    const data = await request.json();

    this.setState(() => ({
      temperature: data.temperature,
        symbol: data.weatherSymbol.text
    }));
  }
  render() {
    return (
      <WeatherContainer>
        <WeatherText>{Math.round(this.state.temperature)} </WeatherText>
        <WeatherText>°C</WeatherText>

        <img
          src={`icons/weather-icons/svg/${this.state.symbol}.svg`}
          alt="Weather Icon"
          width="70"
          style={{ maxWidth: "100%" }}
        />
      </WeatherContainer>
    );
  }
}

export default Weather;
