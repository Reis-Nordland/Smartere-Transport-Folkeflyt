import React, { Component } from "react";
import styled from "styled-components";
import moment from "moment";

const Time = styled.p`
  width: 93px;
  height: 42px;
  font-family: Avinor;
  font-size: 35px;
  font-weight: 500;
  font-style: normal;
  font-stretch: normal;
  line-height: normal;
  letter-spacing: normal;
`;

class Clock extends Component {
  state = {
    time: moment(new Date()).format("HH:mm")
  };

  tick = () => {
    this.setState(() => ({
      time: moment(new Date()).format("HH:mm")
    }));
  };

  componentDidMount() {
    this.intervalID = setInterval(() => this.tick(), 1000);
  }

  componentWillUnmount() {
    clearInterval(this.intervalID);
  }

  render() {
    return <Time>{this.state.time}</Time>;
  }
}

export default Clock;
