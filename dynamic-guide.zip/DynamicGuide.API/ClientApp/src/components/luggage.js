import React, { useContext } from "react";
import styled from "styled-components";
import ToggleButton from "react-toggle-button";
import { AppContext } from "../context/app-context";
import {
  AnimationMixin,
  AnimationMixin1
} from "../screens/home/components/city-center-transfer/city-center-transfer";
import { Event } from "utils/tracking";

const BlackBox = styled.div`
  width: 366px;
  display: flex;
  flex-direction: row;
  justify-content: space-around;
  align-items: center;
  padding: 10px;
  box-shadow: ${props =>
    props.isHighlight
      ? "0px 0px 6px 4px rgb(255, 187, 10)"
      : "2px 4px 9px 1px rgba(0, 0, 0, 0.15)"};
  background-color: #292929;

  ${props => {
    if (props.isHighlight) {
      return AnimationMixin;
    } else {
      return AnimationMixin1;
    }
  }}
`;

const LuggageIcon = styled.img`
  width: 45px;
  height: 54px;
`;

const LuggageText = styled.p`
  font-family: Avinor;
  font-size: 21px;
  font-weight: 500;
  font-style: normal;
  font-stretch: normal;
  line-height: normal;
  letter-spacing: normal;
  color: #ffffff;
`;

const ToggleWrapper = styled.div`
  display: flex;
  flex-direction: column;
  margin-top: 20px;
  justify-content: center;
  align-items: center;
`;

const ToggleText = styled.p`
  font-family: Avinor;
  font-size: 15px;
  color: #ffffff;
`;

const Luggage = () => {
  const { state, dispatch } = useContext(AppContext);
  return (
    <BlackBox isHighlight={state.toggleClickEvent}>
      <LuggageIcon src="/avinor-white-icons/luggage.svg" />
      <LuggageText>Luggage storage</LuggageText>
      <ToggleWrapper>
        <ToggleButton
          value={state.toggle}
          inactiveLabel={""}
          activeLabel={""}
          onToggle={() => {
            Event("Luggage", "Toggle luggage", `${!state.toggle}`);
            dispatch({ type: "toggle" });
          }}
          trackStyle={{
            border: "solid 1.5px white",
            height: 32,
            width: 65
          }}
          thumbStyle={{ height: 29, width: 29 }}
          thumbAnimateRange={[0, 28]}
          colors={{
            active: {
              base: "#7d1b6b"
            }
          }}
        />
        <ToggleText>
          {!state.toggle ? "Show in map" : "Visible in map"}
        </ToggleText>
      </ToggleWrapper>
    </BlackBox>
  );
};

export default Luggage;
