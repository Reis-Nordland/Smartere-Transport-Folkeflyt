import React, { Component } from "react";
import styled from "styled-components";

const Container = styled.div`
  min-height: 849px;
`;

const ContentContainer = styled.div`
  padding: 80px 90px 60px 60px;
  display: flex;
  flex-direction: column;
  position: relative;
`;

const InnerContainer = styled.div`
  display: flex;
  flex-direction: row;
  margin-top: 50px;
`;

const CloseButtonText = styled.p`
  font-family: AvinorLight;
  font-size: 16px;
  color: #292929;
  margin-top: -20px;
`;

const CloseButton = styled.button`
  width: 104px;
  height: 90px;
  background-color: transparent;
  border: none;
  position: fixed;
  top: 0px;
  right: -10px;
  z-index: 100;
`;

const EventImage = styled.img`
  height: auto;
  width: 100%;
  max-height: 400px;
  /* height: 400px; */
`;

const EventTitle = styled.p`
  width: 100%;
  /* word-break: break-all; */
  font-family: "Avinor";
  font-size: 50px;
  font-weight: 500;
  color: #1d1d1d;
`;

const EventTitleContainer = styled.div`
  display: flex;
  flex-direction: column;
  flex: 2;
  width: 100%;
`;

const EventSubtitle = styled.p`
  width: 100%;
  font-family: "AvinorLight";
  font-size: 22px;
  font-weight: 300;
  margin-left: 3px;
  color: #939597;
`;

const EventDescription = styled.p`
  width: 100%;
  height: 95px;
  margin-top: 22px;
  font-family: "AvinorLight";
  font-size: 20px;
  font-weight: 300;
  color: #292929;
`;

const EventOpeningHoursContainer = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  align-items: center;
  /* height: 100px; */
`;

const EventOpeningHours = styled.p`
  width: 198px;
  height: 24px;
  font-family: "Avinor";
  font-size: 20px;
  font-weight: 500;
  margin-bottom: 3px;
  color: #1d1d1d;
`;

const EventHours = styled.div`
  width: 198px;
  height: 24px;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  font-family: "AvinorLight";
  font-size: 20px;
  font-weight: 300;
  margin-bottom: 2px;
  color: #939597;
`;

const EventDescriptionContainer = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  width: 100%;
`;

const EventLink = styled.figcaption`
  font-family: AvinorLight;
  font-size: 15px;
  width: 100%;
`;

class EventInfo extends Component {
  getSource = imgName => {
    let imgSrc = "/images/cafe.jpeg";
    if (imgName) {
      imgSrc = `/events/${imgName}`;
    }
    return imgSrc;
  };
  render() {
    if (!this.props.modalData) {
      return <div>Sorry something went wrong, try again later</div>;
    }
    return (
      <Container>
        <CloseButton onClick={this.props.closeModal}>
          <img src="/avinor-white-icons/close-button.svg" alt="" />
          <CloseButtonText>Close </CloseButtonText>
        </CloseButton>
        <ContentContainer>
          <figure>
            <EventImage src={this.getSource(this.props.modalData.imgName)} />
            {this.props.modalData.imgLink && (
              <EventLink>(kilde: {this.props.modalData.imgLink})</EventLink>
            )}
          </figure>
          <InnerContainer>
            <EventTitleContainer>
              <EventTitle>{this.props.modalData.title}</EventTitle>
              <EventDescriptionContainer>
                <EventSubtitle>{this.props.modalData.type}</EventSubtitle>
                <EventDescription>
                  {this.props.modalData.description}
                  {/* Artisan roastery's coffee shop, with onsite bakery for
                brvveakfast, cakes, eggs and lunchtime snacks. Artisan
                roastery's coffee shop, with onsite bakery for brvveakfast,
                cakes, eggs and lunchtime snacks. */}
                </EventDescription>
              </EventDescriptionContainer>
            </EventTitleContainer>

            <EventOpeningHoursContainer>
              <EventOpeningHours>OPENING HOURS</EventOpeningHours>
              <EventHours>
                <p>Mon</p>
                <p>
                  {this.props.modalData.openingHours.monday.opens}-
                  {this.props.modalData.openingHours.monday.closes}
                </p>
                {/* <p> 0900-1700</p> */}
              </EventHours>
              <EventHours>
                <p>Tue</p>
                <p>
                  {this.props.modalData.openingHours.tuesday.opens}-
                  {this.props.modalData.openingHours.tuesday.closes}
                </p>
                {/* <p> 0900-1700</p> */}
              </EventHours>
              <EventHours>
                <p>Wed</p>
                <p>
                  {this.props.modalData.openingHours.wednesday.opens}-
                  {this.props.modalData.openingHours.wednesday.closes}
                </p>
                {/* <p> 0900-1700</p> */}
              </EventHours>
              <EventHours>
                <p>Thu</p>
                <p>
                  {this.props.modalData.openingHours.thursday.opens}-
                  {this.props.modalData.openingHours.thursday.closes}
                </p>
                {/* <p> 0900-1700</p> */}
              </EventHours>
              <EventHours>
                <p>Fri</p>
                <p>
                  {this.props.modalData.openingHours.friday.opens}-
                  {this.props.modalData.openingHours.friday.closes}
                </p>
                {/* <p> 0900-1700</p> */}
              </EventHours>
              <EventHours>
                <p>Sat</p>
                <p>
                  {this.props.modalData.openingHours.saturday.opens}-
                  {this.props.modalData.openingHours.saturday.closes}
                </p>
              </EventHours>
              <EventHours>
                <p>Sun</p>
                <p>
                  {" "}
                  {this.props.modalData.openingHours.sunday.opens}-
                  {this.props.modalData.openingHours.sunday.closes}
                </p>
              </EventHours>
            </EventOpeningHoursContainer>
          </InnerContainer>
        </ContentContainer>
      </Container>
    );
  }
}

export default EventInfo;
