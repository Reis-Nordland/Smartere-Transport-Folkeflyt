import React, { useContext } from 'react'
import styled from "styled-components";
import {AppContext} from "../../../../context/app-context";
import BoatSvg from "../../../../icon-components/boat";
import StationSvg from "../../../../icon-components/station";
import BodoLufthavn from "../../../../icon-components/bodolufthavn";
import LockerSvg from "../../../../icon-components/lockerSvg";

const LuggaeLockerStyled = styled.div`
    background-color: #292929;
    color: white;
    padding: 1.5rem 1rem 1rem 1rem;
    position: relative;
    top: 1rem;
    right: -0.5rem;
    
    .title {
        font-size: 0.9rem;
        padding-top: 0.5rem;
        padding-bottom: 0.5rem;
        
    }
    
    .opening {
        list-style: none;
        min-width: 7rem;
        .items {
            display: flex;
            justify-content: space-between;        
        }
    }
    
    .locker-svg-wrapper {
        position: absolute;
        top: -1.5rem;
        right: 3rem;
        background-color: black;
        border-radius: 50%;
        padding: 0.75rem;
        
        svg {
            width: 1.5rem;
            height: 1.5rem;
        }
    }
    
    .arrow-left {
      width: 0; 
      height: 0; 
      border-top: 10px solid transparent;
      border-bottom: 10px solid transparent; 
      
      border-right:10px solid #292929; 
      
      position: absolute;
      left: -10px;
      top: 26px;
    }
`;
const LuggageSvgStyled = styled.div`
    position: relative;
    bottom: -4.9rem;
    left: -3.3rem;
`;

const MarkerStyled = styled.div`
    display: flex;
    align-items: center;
    position: ${props => props.position ? props.position: 'relative'};
    top: ${props => props.top ? props.top: '-3rem'};
    right: ${props => props.right ? props.right: '11rem'};
`;

export const TextWrapper = styled.p`
  font-weight: ${props => props.weight ? props.weight : 'bolder'};
  font-size: ${props => props.size ? props.size : '0.95rem'};
  color: ${props => props.color ? props.color : 'initial'};
  min-width: ${props => props.width ? props.width : '120px'};
`;
export const LufthavnMarker = ({ currentZoom, openings }) => {
    const { state } = useContext(AppContext);

    return (
        <MarkerStyled
            position="relative"
            top="-8rem"
            right="7rem"
        >
            <BodoLufthavn currentZoom={currentZoom}/>
            {
                state.toggle
                    ?
                    <LuggageSvgStyled>
                        <LuggaeLockerStyled>
                            <LockerSvg/>
                            <h1 className="title">Luggage Storage</h1>
                            <ul className="opening">
                                {
                                    openings.map((item) => {
                                        return (
                                            <li className="items">
                                                <span className="day">{item.day}</span><span className="hour">{item.hour}</span>
                                            </li>
                                        )
                                    })
                                }

                            </ul>
                            <div className="arrow-left"/>
                        </LuggaeLockerStyled>
                    </LuggageSvgStyled>
                    :
                    null
            }
        </MarkerStyled>
    )
};

export const CustomMarker = ({ text, textWidth, noLuggageStorage, type, openings = [] }) => {
    const { state } = useContext(AppContext);

    return (
        <MarkerStyled>
            <TextWrapper
                width={textWidth}
            >
                {text}
            </TextWrapper>
            {
                type === 'boat'
                ? <BoatSvg/>
                : <StationSvg/>
            }
            {
                state.toggle && !noLuggageStorage
                    ?
                    <LuggaeLockerStyled>
                        <LockerSvg/>
                        <h1 className="title">Luggage Storage</h1>
                        <ul className="opening">
                            {
                                openings.map((item) => {
                                    return (
                                        <li className="items">
                                            <span className="day">{item.day}</span><span className="hour">{item.hour}</span>
                                        </li>
                                    )
                                })
                            }

                        </ul>
                        <div className="arrow-left"/>
                    </LuggaeLockerStyled>
                    :
                    null
            }
        </MarkerStyled>
    )
};
