import React, { Component } from "react";
import config from "config";
import GoogleMapReact from "google-map-react";
import Modal from "react-modal";
import EventInfo from "../event-info/event-info";
import { LufthavnMarker, CustomMarker } from "./styled-components";
import uniqid from "uniqid";
import { Event } from "utils/tracking";

const LUFTHAVN = { lat: 67.272768, lng: 14.367313 };
const SENTRUM_TERMINAL = { lat: 67.284384, lng: 14.372357 };

const customStyles = {
  content: {
    top: "50%",
    left: "50%",
    right: "auto",
    bottom: "auto",
    marginRight: "-50%",
    transform: "translate(-50%, -50%)",
    height: 849,
    width: 855,
    padding: 0
  },
  overlay: {
    zIndex: 1000,
    backgroundColor: "rgba(41, 41, 41, 0.69)"
  }
};

export const DEFAULT_ZOOM = 14;
class SimpleMap extends Component {
  static defaultProps = {
    center: {
      lat: 67.280357,
      lng: 14.404916
    },
    zoom: DEFAULT_ZOOM
  };

  constructor() {
    super();

    this.state = {
      modalIsOpen: false,
      modalData: "",
      key: "my-google-key"
    };
  }

  openModal = modalData => {
    this.setState(() => ({ modalData: modalData, modalIsOpen: true }));
  };

  afterOpenModal = () => {
    // references are now sync'd and can be accessed.
    // this.subtitle.style.color = "#f00";
  };

  closeModal = () => {
    Event("Google maps", "Hide event info by clicking on close-button");
    this.setState({ modalIsOpen: false });
  };

  componentDidMount() {
    Modal.setAppElement("body");
  }

  handleMapsApi = (map, maps, openModal, route) => {
    var lineSymbol = {
      path: "M 0,-1 0,1",
      strokeOpacity: 1,
      strokeColor: "#84216B",
      scale: 4
    };
    var directionsService = new maps.DirectionsService();
    var directionsDisplay = new maps.DirectionsRenderer({
      suppressMarkers: true,
      polylineOptions: {
        strokeOpacity: 0,
        icons: [
          {
            icon: lineSymbol,
            offset: "0",
            repeat: "20px"
          }
        ]
      }
    });

    directionsDisplay.setMap(map);
    const boatterminal = { lat: 67.288342, lng: 14.393748 };
    const bodolufthavn = { lat: 67.272768, lng: 14.367313 };
    const bodobystrand = new maps.LatLng(67.277146, 14.363185);
    const sentrumsterminalen = SENTRUM_TERMINAL;

    let origin = bodolufthavn;
    let destination = sentrumsterminalen;
    let waypoints = [{ location: bodobystrand, stopover: true }];
    if (this.props.route && this.props.route.pois) {
      let pois = this.props.route.pois;

      let first = pois.find((value, index) => index === 0);
      let last = pois.find((value, index) => index === pois.length - 1);
      let middles = pois.filter((value, index) => {
        return index !== 0 && index !== pois.length - 1;
      });

      origin = new maps.LatLng(
        first.coordinates.latitude,
        first.coordinates.longitude
      );
      destination = new maps.LatLng(
        last.coordinates.latitude,
        last.coordinates.longitude
      );
      waypoints = middles.map(waypoint => ({
        location: {
          lat: waypoint.coordinates.latitude,
          lng: waypoint.coordinates.longitude
        },
        stopover: true
      }));
    }

    const circlePOI = {
      url: "/icons/circlePOI.svg"
    };

    const createMarker = (position, title, icon, label, modalData) => {
      let marker = new maps.Marker({
        position: position,
        icon: icon,
        /*icon: {
          url: '/icons/bagasje.svg'
        },*/
        map: map,
        title: title,
        label: {
          text: label,
          color: "white",
          fontFamily: "Avinor",
          fontSize: "1.2rem"
        }
      });

      marker.addListener("click", function() {
        Event("Google maps", "Display event info by clicking on marker");
        openModal(modalData);
      });
    };

    // var aNorth = map
    //   .getBounds()
    //   .getNorthEast()
    //   .lat();
    // var aEast = map
    //   .getBounds()
    //   .getNorthEast()
    //   .lng();
    // var aSouth = map
    //   .getBounds()
    //   .getSouthWest()
    //   .lat();
    // var aWest = map
    //   .getBounds()
    //   .getSouthWest()
    //   .lng();
    // console.log(aNorth, aSouth, aEast, aWest);
    const calcRoute = () => {
      var request = {
        origin: origin,
        destination: destination,
        travelMode: maps.TravelMode["WALKING"],
        waypoints: waypoints
      };
      directionsService.route(request, function(response, status) {
        if (status === "OK") {
          directionsDisplay.setOptions({ preserveViewport: true });
          directionsDisplay.setDirections(response);

          if (route.pois) {
            route.pois.forEach((poi, index) => {
              if (poi.id === "1") {
                return;
              }
              const modalData = {
                title: poi.name,
                type: poi.type,
                description: poi.description,
                openingHours: poi.openingHours,
                imgName: poi.pictureName,
                imgLink: poi.pictureLink
              };
              createMarker(
                new maps.LatLng(
                  poi.coordinates.latitude,
                  poi.coordinates.longitude
                ),
                "",
                circlePOI,
                index.toString(),
                modalData
              );
            });
          }
        }
      });
    };
    calcRoute();
  };

  //forces Google Maps to re-render when new data comes in
  componentDidUpdate(prevProps) {
    if (prevProps.route !== this.props.route) {
      this.setState(() => ({
        key: uniqid("my-google-key")
      }));
    }
  }

  render() {
    return (
      // Important! Always set the container height explicitly
      <div style={{ height: "100%", width: "100%" }} id="myAppElement">
        <GoogleMapReact
          key={this.state.key}
          bootstrapURLKeys={{
            key: config.googleMapsAPIKey
          }}
          defaultCenter={this.props.center}
          defaultZoom={this.props.zoom}
          onChange={value => {
            this.setState(() => {
              return {
                currentZoom: value.zoom
              };
            });
          }}
          options={() => ({
            clickableIcons: false,
            fullscreenControl: false,
            minZoom: this.props.zoom,
            restriction: {
              latLngBounds: {
                north: 67.3993995878751,
                south: 67.1607207669391,
                east: 14.797942517704087,
                west: 14.011889482295828
              },
              strictBounds: false
            },
            styles: [
              {
                featureType: "water",
                elementType: "geometry",
                stylers: [{ color: "#c2e5ff" }]
              },
              {
                featureType: "transit",
                elementType: "labels.text.fill",
                stylers: [{ visibility: "off" }]
              }
            ]
          })}
          yesIWantToUseGoogleMapApiInternals
          onGoogleApiLoaded={({ map, maps }) => {
            this.handleMapsApi(map, maps, this.openModal, this.props.route);
          }}
        >
          <LufthavnMarker
            lat={LUFTHAVN.lat}
            lng={LUFTHAVN.lng}
            text="Du er her"
            currentZoom={this.state.currentZoom}
            openings={[
              { day: "Mon-fri", hour: "03:30-24:00" },
              { day: "Saturday", hour: "07:00-18:00" },
              { day: "Sunday", hour: "08:30-24:00" }
            ]}
          />
          <CustomMarker
            textWidth="120px"
            lat={SENTRUM_TERMINAL.lat}
            lng={SENTRUM_TERMINAL.lng}
            text="BOAT TERMINAL"
            type="boat"
            openings={[{ day: "Open", hour: "07:00-21:00" }]}
          />
          <CustomMarker
            textWidth="90px"
            lat={67.288342}
            lng={14.393748}
            noLuggageStorage={true}
            text="BOAT PORT"
            type="boat"
          />
          <CustomMarker
            lat={67.286315}
            lng={14.390726}
            text="BODØ STATION"
            openings={[
              { day: "Mon-fri", hour: "06:00-24:00" },
              { day: "Saturday", hour: "07:00-24:00" },
              { day: "Sunday", hour: "08:30-21:15" }
            ]}
          />
        </GoogleMapReact>

        <Modal
          isOpen={this.state.modalIsOpen}
          onAfterOpen={this.afterOpenModal}
          onRequestClose={this.closeModal}
          style={customStyles}
          contentLabel="Event info"
        >
          <EventInfo
            closeModal={this.closeModal}
            modalData={this.state.modalData}
          />
        </Modal>
      </div>
    );
  }
}

export default SimpleMap;
