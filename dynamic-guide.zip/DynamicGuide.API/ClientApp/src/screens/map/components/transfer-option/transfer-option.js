import React, { Component } from "react";
import PropTypes from "prop-types";
import styled from "styled-components";

import TimeRow from "screens/home/components/timetable/time-row";

const Box = styled.div`
  display: flex;
  flex-direction: column;
  width: 366px;
  box-shadow: 2px 4px 9px 1px rgba(0, 0, 0, 0.15);
  background-color: ${props => (props.active ? "#7d1b6b" : "#292929")};
  margin-top: 11px;
`;

const Container = styled.div`
  display: flex;
  flex-direction: row;
  justify-content: center;
  align-items: center;
  padding: 30px 27px;
  position: relative;
`;

const TimeLeftText = styled.p`
  font-family: AvinorBold;
  font-size: 22px;

  font-weight: normal;
  font-style: normal;
  font-stretch: normal;
  line-height: normal;
  letter-spacing: normal;
  color: #ffffff;
`;

const AccordionContent = styled.div`
  padding: 20px;
  /* max-height: 0; */
  transition: max-height 0.4s ease-out;
  max-height: 400px;
`;

const AccordionButton = styled.button`
  background-color: transparent;
  border: none;
`;

const QRBox = styled.div`
  width: 105px;
  height: 83px;
  border: solid 1px #979797;
  background-color: #d8d8d8;
`;

const ExtraInfoContainer = styled.div`
  display: flex;
  flex-direction: column;
`;
const ExtraInfoHeader = styled.p`
  font-family: AvinorBold;
  font-size: 15px;
  font-weight: bold;
  font-style: normal;
  font-stretch: normal;
  line-height: normal;
  letter-spacing: normal;
  color: #ffffff;
`;
const ExtraInfoBody = styled.p`
  font-family: Avinor;
  font-size: 15px;
  font-weight: bold;
  font-style: normal;
  font-stretch: normal;
  line-height: normal;
  letter-spacing: normal;
  color: #ffffff;
`;

const InfoGrid = styled.div`
  display: grid;
  grid-template-columns: 1fr 2fr;
  grid-column-gap: 22px;
  padding: 31px 5px 10px 5px;
`;

class TransferOption extends Component {
  render() {
    return (
      <Box
        style={this.props.style}
        active={this.props.active}
        open={this.props.active}
        onClick={this.props.setActive}
      >
        <Container>
          <img
            src={`/avinor-white-icons/${this.props.icon}`}
            alt="transfer icon"
            style={this.props.iconStyle}
          />
          <TimeLeftText>
            {this.props.timeLeft === 0 ? "Now" : `${this.props.timeLeft} min`}
          </TimeLeftText>
          {this.props.isAccordion && (
            <AccordionButton
              // onClick={this.props.toggle}
              style={{ position: "absolute", right: 23 }}
            >
              <img
                src={`/avinor-white-icons/${
                  this.props.open ? "arrow-up" : "arrow-down"
                }.svg`}
                alt="accordion icon"
                style={{ height: 18, width: 35 }}
              />
            </AccordionButton>
          )}
        </Container>
        {this.props.open && (
          <AccordionContent
            // className={`${this.props.open ? "open" : ""}`}
            open={this.props.open}
          >
            {this.props.busRoutes && [
              <TimeRow
                notClickable
                icon="bus.svg"
                iconStyle={{ width: 30, height: 30 }}
                {...this.props.busRow}
              />
            ]}
            <InfoGrid>
              {this.props.QR && (
                <QRBox>
                  <img
                    src={this.props.QR}
                    style={{ height: "100%", width: "100%" }}
                    alt="QR-bus"
                  />
                </QRBox>
              )}
              {this.props.extraInfo && (
                <ExtraInfoContainer>
                  <ExtraInfoContainer>
                    <ExtraInfoHeader>
                      {this.props.extraInfo.header}
                    </ExtraInfoHeader>
                    <ExtraInfoBody>{this.props.extraInfo.body}</ExtraInfoBody>
                  </ExtraInfoContainer>
                  <ExtraInfoContainer style={{ marginTop: 10 }}>
                    <ExtraInfoHeader>Download the app:</ExtraInfoHeader>
                    <ExtraInfoBody>{this.props.extraInfo.app}</ExtraInfoBody>
                  </ExtraInfoContainer>
                </ExtraInfoContainer>
              )}
            </InfoGrid>
          </AccordionContent>
        )}
      </Box>
    );
  }
}

export default TransferOption;

TransferOption.propTypes = {
  open: PropTypes.bool,
  active: PropTypes.bool,
  isAccordion: PropTypes.bool
};

TransferOption.defaultProps = {
  open: false,
  active: false,
  isAccordion: false

  // open: true,
  // active: true,
  // isAccordion: true
};
