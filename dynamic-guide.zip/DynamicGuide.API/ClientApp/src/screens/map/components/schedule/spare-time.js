import React, { Component } from "react";

import styled from "styled-components";

const BlackBox = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  width: 100%;
  min-height: 117px;
  box-shadow: 2px 4px 9px 1px rgba(0, 0, 0, 0.5);
  background-color: #292929;
`;
const Title = styled.p`
  width: 255px;
  height: 28px;
  font-family: Avinor;
  font-size: 23px;
  font-weight: 500;
  color: #ffffff;
`;

const Controller = styled.div`
  display: flex;
  flex-direction: row;
  justify-content: space-around;
  align-items: center;
  height: 40px;
  margin-top: 20px;
  width: 100%;
`;

const Button = styled.button`
  width: 36px;
  height: 37px;
  background-color: transparent;
  outline: none;
  border: none;
`;

const SpareTimeContainer = styled.div`
  display: flex;
  flex-direction: row;
  width: 141px;
`;

const Value = styled.p`
  font-family: AvinorLight;
  font-size: 33px;
  font-weight: 500;
  color: #ffffff;
`;

class SpareTime extends Component {
  render() {
    return (
      <BlackBox>
        <Title>What’s your spare time?</Title>
        <Controller>
          <Button onClick={this.props.decrementSpareTime}>
            <img
              src="/avinor-white-icons/minus.svg"
              style={{ width: "100%", height: "100%" }}
              alt="minus"
            />
          </Button>
          <SpareTimeContainer>
            <Value>{this.props.spareTime}</Value>
            <Value style={{ marginLeft: 14 }}>hours</Value>
          </SpareTimeContainer>
          <Button onClick={this.props.incrementSpareTime}>
            <img
              src="/avinor-white-icons/plus.svg"
              style={{ width: "100%", height: "100%" }}
              alt="plus"
            />
          </Button>
        </Controller>
      </BlackBox>
    );
  }
}

export default SpareTime;
