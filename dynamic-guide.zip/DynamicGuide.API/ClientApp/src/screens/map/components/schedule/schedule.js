import React, { Component } from "react";
import styled from "styled-components";
import VerticalLine from "./vertical-line";
import SpareTime from "./spare-time";
import TimeRow from "screens/home/components/timetable/time-row";
// import Moment from "react-moment";
import moment from "moment";

const OuterContainer = styled.section`
  display: flex;
  flex-direction: column;
  background-color: #292929;
  justify-content: flex-end;
  align-content: flex-end;
  width: 400px;
  max-height: 750px;
  overflow-x: hidden;
  z-index: 1;
  object-fit: contain;
  box-shadow: 0 2px 10px 0 rgba(0, 0, 0, 0.5);
`;

const InnerContainer = styled.div`
  flex: 15;
  background-color: #292929;
  padding: 1rem;
  height: 100%;
  overflow-y: scroll;
  overflow-x: hidden;
  max-width: 100%
  height: 0;
  /* max-height: 100%; */
`;

const TimeRowWrapper = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: 20px;
`;

const SpareTimeTextContainer = styled.div`
  padding: 25px;
  display: flex;
`;

const SpareTimeText = styled.p`
  width: 100%;
  height: 100%;
  font-family: Avinor;
  font-size: 22px;
  font-weight: 500;
  color: #ffffff;
`;

const TotalSpareTime = styled.span`
  font-family: Avinor;
  font-size: 33px;
  font-weight: 500;
  color: #ffffff;
`;

const RouteSuggestionText = styled.p`
  padding: 10px 25px;
  font-family: Avinor;
  font-size: 17px;
  font-weight: 500;
  color: #ffffff;
`;

let directions = [
  {
    id: 1,
    location: "Bodø",
    time: "Now",
    travelMode: "Walk",
    duration: "10 minutes"
  },
  {
    id: 2,
    location: "Bodø Kafe",
    time: "12:30",
    travelMode: "Drive",
    duration: "20 minutes"
  },

  {
    id: 3,
    location: "Bodø Lufthavn",
    time: "15:15",
    travelMode: "Fly",
    duration: "1 hour and 20 minutes"
  }
];
const ErrorText = styled.div`
  font-family: Avinor;
  font-size: 23px;
  font-weight: 500;
  color: #ffffff;
`;

const mapDataToSchedule = route => {
  if (route && route.pois) {
    let mappedData = [];
    route.pois.forEach((poi, index) => {
      var dateTarget = new Date();
      let time = moment(dateTarget).format("HH:mm");
      if (index === 0) {
        // let hours = time.split(":")[0],
        // minutes = time.split(":")[1];
        // dateTarget.setHours(hours);
        // dateTarget.setMinutes(minutes);
      } else {
        let prevElem = mappedData[index - 1];

        dateTarget = moment(prevElem.timeDate)
          .add(prevElem.duration, "minute")
          .add(prevElem.estimatedTransportTime, "minute");
        time = moment(prevElem.timeDate)
          .add(prevElem.duration, "minute")
          .add(prevElem.estimatedTransportTime, "minute")
          .format("HH:mm");
      }

      let mappedObject = {
        id: poi.id,
        location: poi.name,
        time: time,
        timeDate: dateTarget,
        travelMode: poi.transportType,
        duration: poi.duration,
        estimatedTransportTime: poi.estimatedTransportTime,
        weatherSymbol: poi.weatherSymbol
      };
      mappedData.push(mappedObject);
    });
    return mappedData;
  }
  return [];
};

class Schedule extends Component {
  showRoute = () => {
    if (this.props.route) {
      if (
        this.props.route.routeName ===
        "We did not find any route, returning default route"
      ) {
        return <ErrorText>Sorry, we could not find any routes</ErrorText>;
      }
      return (
        <VerticalLine
          directions={directions}
          pois={mapDataToSchedule(this.props.route)}
        />
      );
    } else {
      return (
        <ErrorText>
          Something went wrong, please go back and try again
        </ErrorText>
      );
    }
  };
  render() {
    return (
      <OuterContainer>
        {this.props.timeRow ? (
          [
            <SpareTimeTextContainer key="spare-time-text">
              <SpareTimeText>
                You've got{" "}
                <TotalSpareTime>{this.props.spareTime} </TotalSpareTime> hours
                to spare
              </SpareTimeText>
            </SpareTimeTextContainer>,
            <RouteSuggestionText key="route-suggestion-text">
              Route suggestion:
            </RouteSuggestionText>
          ]
        ) : (
          <SpareTime
            incrementSpareTime={this.props.incrementSpareTime}
            decrementSpareTime={this.props.decrementSpareTime}
            spareTime={this.props.spareTime}
          />
        )}

        <InnerContainer>{this.showRoute()}</InnerContainer>
        <TimeRowWrapper>
          {this.props.timeRow && (
            <TimeRow {...this.props.timeRow} notClickable />
          )}
        </TimeRowWrapper>
      </OuterContainer>
    );
  }
}

export default Schedule;
