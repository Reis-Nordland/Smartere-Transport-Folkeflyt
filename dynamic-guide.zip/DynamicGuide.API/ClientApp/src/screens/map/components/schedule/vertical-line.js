import React, { Component } from "react";
import styled from "styled-components";

const VerticalLine = styled.section`
  width: 45%;
  padding: 20px;
  word-break: break-all;
  color: white;

  ul li::before {
    content: "";
    position: absolute;
    top: 0px;
    bottom: 0px;
    border: 1.5px dashed white;
    height: 100%;
  }

  /* Remove the last line */
  ul li:last-child {
    height: 0;
  }

  /* VERTICAL LINE  */
  ul li {
    list-style-type: none;
    position: relative;
    width: 0px;
    left: 50%;
    background: white;
  }

  /*CIRCLES */
  ul li::after {
    content: "";
    position: absolute;
    left: 50%;
    top: -10px;
    transform: translateX(-45%) translateY(-25%);
    width: 37px;
    height: 38px;
    border-radius: 50%;

    background: #7d1b6b;
  }

  ul li:first-child::after {
    content: "";
    position: absolute;
    left: 50%;
    top: -10px;
    transform: translateX(-40%);
    width: 13px;
    height: 13px;
    border-radius: 50%;
    background: white;
  }

  /* LEFT BOXES */
  ul li > div > div:nth-child(odd) {
    position: relative;
    flex: 0 0 80px; /*width*/
    padding: 15px;
    padding-top: 0;
    background-color: #292929;
    top: -30px;
    left: -120px;
    margin: 20px;
  }

  /* RIGHT BOXES */
  ul li > div > div:nth-child(even) {
    position: relative;
    flex: 0 0 300px; /*width*/
    padding: 15px;
    padding-top: 0;
    background-color: #292929;
    top: -35px;
    left: -130px;
    margin: 20px;
  }

  ul li:first-child > div > div:nth-child(even) {
    top: -25px;
  }
`;

const ContainerForBoxes = styled.div`
  display: flex;
  flex-direction: row;
`;

/* LEFT BOX*/
const TimeAndWeatherContainer = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  min-height: 100px;
  position: relative;
`;

const TimeText = styled.div`
  margin-right: ${props => (props.firstItem ? -30 : -20)}px;
  margin-top: ${props => (props.firstItem ? -5 : 0)}px;
  font-family: "Avinor";
  font-size: 17px;
  font-weight: 500;
  font-style: normal;
  font-stretch: normal;
  line-height: normal;
  letter-spacing: normal;
  color: #ffffff;
`;

const ImageContainer = styled.div`
  position: absolute;
  top: 50%;
  left: 50%;
`;

/******/

/* RIGHT BOX */

const LocationAndRouteContainer = styled.div`
  display: flex;
  flex-direction: column;
  min-height: 100%;
  justify-content: space-between;
  position: relative;
  width: 100%;
`;

const LocationTitle = styled.div`
  margin-top: ${props => (props.firstItem ? -15 : -8)}px;
  margin-left: ${props => (props.firstItem ? -5 : 2)}px;
  width: 100%;
  max-width: 233px;
  word-break: break-all;
  font-size: 17px;
  font-family: AvinorBold;
  font-weight: bold;
  color: #ffffff;
`;

const DurationTitle = styled.span`
  font-size: 15px;
  font-family: AvinorLight;
`;

const HorizontalLine = styled.hr`
  margin-top: 8px;
`;
const TopHorizontalLine = styled.hr`
  margin-bottom: 6px;
`;

const TravelModeText = styled.p`
  margin-left: 10px;
  padding: 10px;
  padding-top: 40px;
  font-family: AvinorLight;
  font-size: 15px;
  font-weight: 300;
  font-style: normal;
  font-stretch: normal;
  line-height: normal;
  letter-spacing: normal;
  color: #ffffff;
`;
/******/

const Number = styled.p`
  color: white;
  position: absolute;
  left: -20px;
  top: 0.5px;
  z-index: 10;
  font-family: AvinorBold;
  font-size: 22px;
  text-align: center;
`;

const TransportIcon = mode => {
  let image;
  if (mode === "bike") {
    image = (
      <img
        src={"/avinor-white-icons/bicycle.svg"}
        alt="transport icon"
        style={{ width: 30, height: 30 }}
      />
    );
  } else if (mode === "publictransport") {
    image = (
      <img
        src={"/avinor-white-icons/bus.svg"}
        alt="transport icon"
        style={{ width: 30, height: 30 }}
      />
    );
  } else {
    image = (
      <img
        src={"/avinor-white-icons/walking-man.svg"}
        alt="transport icon"
        style={{ width: 20, height: 30 }}
      />
    );
  }
  return image;
};

const getTravelModeText = (mode, duration) => {
  if (mode === "bike") {
    return `Bike for ${duration} minutes`;
  } else if (mode === "publictransport") {
    return `${duration} minutes`;
  }
  return `Walk for ${duration} minutes`;
};

// const getDepartureTime = (pois, index) => {
//   var dateTarget = new Date();
//   let result = moment(dateTarget).format("HH:mm");

//   if (index === 0) {
//     // let hours = time.split(":")[0],
//     // minutes = time.split(":")[1];
//     // dateTarget.setHours(hours);
//     // dateTarget.setMinutes(minutes);
//   } else {
//     let prevElem = pois[index - 1];
//     result = moment(dateTarget)
//       .add(prevElem.duration, "minute")
//       .add(prevElem.estimatedTransportTime, "minute")
//       .format("HH:mm");
//   }
//   console.log("departuretime", result);
//   return result;
// };

const ListItem = props => (
  <li>
    <ContainerForBoxes>
      <TimeAndWeatherContainer>
        <TimeText firstItem={props.firstItem}>{props.time}</TimeText>
        {!props.lastItem && (
          <ImageContainer>
            {TransportIcon(props.travelMode)}

            <img
              src={`${window._env_.METAPIURL}/weathericon/1.1/?symbol=${props.weatherSymbol ? props.weatherSymbol : 1 // 1.1 is deprecated
                }&is_night=0&content_type=image/png`} // Used to be "image/svg%2Bxml"
              alt="Weather Icon"
              width="20"
              style={{
                maxWidth: "100%",
                position: "absolute",
                top: -15,
                right: -15
              }}
            />
          </ImageContainer>
        )}
      </TimeAndWeatherContainer>
      )
      <LocationAndRouteContainer>
        {!props.firstItem && <Number>{props.index}</Number>}
        <LocationTitle firstItem={props.firstItem}>
          {!props.firstItem && <TopHorizontalLine />}
          <p>
            {props.location}{" "}
            {!props.lastItem && (
              <DurationTitle>({props.duration} min)</DurationTitle>
            )}
          </p>
          <HorizontalLine />
        </LocationTitle>
        {!props.lastItem && (
          <TravelModeText>
            {getTravelModeText(props.travelMode, props.estimatedTransportTime)}
          </TravelModeText>
        )}
      </LocationAndRouteContainer>
    </ContainerForBoxes>
  </li>
);

class Timeline extends Component {
  render() {
    return (
      <VerticalLine>
        <ul>
          {this.props.pois.map((direction, index) => (
            <ListItem
              {...direction}
              pois={this.props.pois}
              key={index}
              index={index}
              firstItem={index === 0}
              lastItem={index === this.props.pois.length - 1}
            />
          ))}
        </ul>
      </VerticalLine>
    );
  }
}

export default Timeline;
