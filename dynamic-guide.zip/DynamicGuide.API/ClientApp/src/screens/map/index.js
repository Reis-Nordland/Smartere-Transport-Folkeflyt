import Map from './map'

export default Map