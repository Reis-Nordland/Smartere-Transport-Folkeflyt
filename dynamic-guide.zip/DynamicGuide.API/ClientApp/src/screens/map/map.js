import React, { Component } from "react";
import styled from "styled-components";
import Schedule from "./components/schedule/schedule";
import SimpleMap from "./components/simple-map/simple-map";
import TransferOption from "./components/transfer-option/transfer-option";
import Luggage from "components/luggage";
import { getRoutes } from "api-requests/route-api";
import LoadingOverlay from "react-loading-overlay";
import { ErrorMessage } from "../errormessage/errormessage";
import { debounce } from "lodash";
import { getBus } from "api-requests/boat-api";
import moment from "moment";
import { Event, initGA, PageView } from "utils/tracking";

const EndContainer = styled.div`
  z-index: 99;
  position: absolute;
  right: 0;
  top: 10%;
`;

const Grid = styled.div`
  display: grid;
  grid-template-columns: 455px auto;
  grid-template-rows: 1fr;
  grid-template-areas: ". .";
  height: 100%;
  position: relative;
`;

const Sidebar = styled.div`
  display: flex;
  flex-direction: column;
  background-color: #f0f1f3;
  padding: 30px 40px;
`;

const Title = styled.p`
  width: 367px;
  font-family: Avinor;
  font-size: 43px;
  font-weight: 500;

  color: #7d1b6b;
`;
const BackButton = styled.div`
  display: flex;
  flex-direction: row;
  margin-bottom: 40px;
  align-items: center;
  margin-left: -28px;
  width: 130px;
  height: 54px;
`;

const BackButtonTitle = styled.p`
  font-size: 20px;
  font-family: Avinor;

  color: #7d1b6b;
`;

const LuggageWrapper = styled.div`
  margin-top: 11px;
`;

class Map extends Component {
  _isMounted = false;
  constructor(props) {
    super(props);
    this.state = {
      active: "walk",
      bicycleIsOpen: false,
      busIsOpen: false,
      spareTime: 2,
      route: {},
      timeRow: false,
      busRow: null,
      endPoid: 8
    };
  }

  getTransportMode() {
    if (this.state.active === "bicycle") {
      return "bike";
    } else if (this.state.active === "bus") {
      return "publictransport";
    }

    return "walk";
  }

  handleChange = value => () => {
    Event("Change transport route", "Change transport mode", `${value}`);

    this.setState(
      prev => {
        return {
          active: value,
          bicycleIsOpen: !prev.bicycleIsOpen && value === "bicycle",
          busIsOpen: !prev.busIsOpen && value === "bus"
        };
      },
      () => {
        if (this.state.timeRow) {
          this.fetchRoutes(
            1,
            this.state.timeRow.fromPoiId,
            this.state.timeRow.durationInMinutes,
            this.getTransportMode()
          );
        } else {
          this.fetchRoutes(
            1,
            this.state.endPoid,
            this.state.spareTime * 60,
            this.getTransportMode()
          );
        }
      }
    );
  };

  fetchRoutes = async (start, end, minutesAvailable, transportMode) => {
    this.setState(() => ({
      loading: true,
      failure: false
    }));

    try {
      const req = await getRoutes(start, end, minutesAvailable, transportMode);
      const data = await req.json();
      if (this._isMounted) {
        this.setState(() => ({
          route: data,
          failure: false,
          loading: false
        }));
      }
    } catch (e) {
      //if (this._isMounted) {
      //  this.setState(() => ({ failure: true }));
      //}
      console.log("error", e);
    } finally {
      if (this._isMounted) {
        this.setState({ loading: false });
      }
    }
  };

  fetchBus = async () => {
    try {
      let req = await getBus();
      let data = await req.json();

      let now = moment(new Date().toISOString()).utc(); //todays date
      let aimedEnd = moment(
        new Date(data.aimedDepartureTime).toISOString
      ).utc();
      let end = moment(
        new Date(data.expectedDepartureTime).toISOString()
      ).utc(); // bus date
      let status = "";
      let duration = moment.duration(end.diff(now)),
        durationInMinutes = Math.ceil(duration.asMinutes());

      let delay = moment.duration(end.diff(aimedEnd)),
        delayInMinutes = Math.ceil(delay.asMinutes());
      if (delayInMinutes > 0) {
        status = "Delay";
      }
      // if (duration < 0) {
      //   end = moment(new Date(data.expectedDepartureTime).toISOString()).utc();
      //   duration = moment.duration(end.diff(now));
      //   durationInMinutes = Math.ceil(duration.asMinutes());
      // }

      let busRow = {
        // time: time,
        // spareTime: durationInHours,
        // fromPoiId: fromPoiId,
        // status: ""/
        from: "Bodø Airport",
        durationInMinutes: durationInMinutes,
        time: `${durationInMinutes} min`,
        destination: data.destinationDisplay.frontText,
        icon: "bus.svg",
        iconStyle: { width: 38, height: 22, marginRight: 5 },
        status: status
      };
      if (this._isMounted) {
        this.setState(() => ({ busRow: busRow }));
      }
    } catch (e) {
      console.log("error", e);
    }
  };

  async componentDidMount() {
    initGA();
    PageView();
    document.getElementsByTagName("body")[0].style.msContentZooming = "zoom";

    /* Fetch and sets states */
    this._isMounted = true;
    let locationState = this.props.location.state;
    if (locationState && locationState.active) {
      if (locationState.active === "bicycle") {
        this.setState(() => ({ bicycleIsOpen: true, busIsOpen: false }));
      } else if (locationState.active === "bus") {
        this.setState(() => ({ busIsOpen: true, bicycleIsOpen: false }));
      }
      this.setState(() => ({ active: locationState.active }));
    }

    let locationRow = this.props.location.timeRow;

    if (locationRow) {
      this.setState(() => ({
        timeRow: locationRow,
        spareTime: locationRow.spareTime
      }));

      this.fetchRoutes(
        1,
        locationRow.fromPoiId,
        locationRow.spareTime * 60,
        this.getTransportMode()
      );
    } else {
      this.fetchRoutes(
        1,
        this.state.endPoid,
        this.state.spareTime * 60,
        this.getTransportMode()
      );
    }

    this.fetchBus();
    setInterval(this.fetchBus, 30000);
  }

  debouncedFetch = debounce(() => {
    this.fetchRoutes(
      1,
      this.state.endPoid,
      this.state.spareTime * 60,
      this.getTransportMode()
    );
  }, 1000);

  componentWillUnmount() {
    this._isMounted = false;
  }

  incrementSpareTimeBy = value => {
    Event(
      "Change transport route",
      "Increment sparetime by clicking on plus-button"
    );
    this.setState(
      prev => {
        if (prev.spareTime <= 9) {
          return { spareTime: prev.spareTime + value };
        }
      },
      () => {
        this.debouncedFetch();
      }
    );
  };

  decrementSpareTimeBy = value => {
    Event(
      "Change transport route",
      "Decrement sparetime by clicking on minus-button"
    );
    this.setState(
      prev => {
        if (prev.spareTime > 0.5) {
          return { spareTime: prev.spareTime - value };
        }
      },
      () => {
        this.debouncedFetch();
      }
    );
  };

  render() {
    if (this.state.failure) {
      return <ErrorMessage />;
    }
    return (
      <Grid>
        <Sidebar>
          <BackButton
            onClick={() => {
              Event("Navigate to homepage", "Click on backbutton");
              this.props.history.push("/");
            }}
          >
            <img src="/avinor-white-icons/back-button.svg" alt="back button" />
            <BackButtonTitle>Back</BackButtonTitle>
          </BackButton>
          <Title>
            Find your way to the{" "}
            {this.props.location.timeRow
              ? this.props.location.timeRow.from
              : "city centre"}
          </Title>
          <TransferOption
            setActive={this.handleChange("walk")}
            active={this.state.active === "walk"}
            style={{ marginTop: 30 }}
            icon="walking-man.svg"
            iconStyle={{
              width: 25,
              height: 55,
              position: "absolute",
              left: 59
            }}
            timeLeft={"10"}
          />

          <TransferOption
            setActive={this.handleChange("bicycle")}
            active={this.state.active === "bicycle"}
            icon="bicycle.svg"
            iconStyle={{
              width: 68,
              height: 44,
              position: "absolute",
              left: 38
            }}
            isAccordion
            toggle={() =>
              this.setState(prev => ({
                bicycleIsOpen: !prev.bicycleIsOpen,
                busIsOpen: false
              }))
            }
            open={this.state.bicycleIsOpen}
            timeLeft={"6"}
            QR={"/avinor-white-icons/qr-bike.png"}
            extraInfo={{
              header: "Bike prices:",
              body: "20 NOK per hour",
              app: "NordvikGO"
            }}
          />

          <TransferOption
            setActive={this.handleChange("bus")}
            active={this.state.active === "bus"}
            QR={"/avinor-white-icons/qr-bus.svg"}
            icon="bus.svg"
            iconStyle={{
              width: 86,
              height: 35,
              position: "absolute",
              left: 25
            }}
            isAccordion
            toggle={() =>
              this.setState(prev => ({
                busIsOpen: !prev.busIsOpen,
                bicycleIsOpen: false
              }))
            }
            open={this.state.busIsOpen}
            busRow={this.state.busRow}
            timeLeft={
              this.state.busRow !== null &&
              this.state.busRow.durationInMinutes + 5
            }
            busRoutes
            extraInfo={{
              header: "Bus Ticket:",
              body: "36 NOK",
              app: "Billett Nordland"
            }}
          />
          <LuggageWrapper>
            <Luggage
              value={this.props.luggage}
              toggleLuggage={this.props.toggleLuggage}
            />
          </LuggageWrapper>
        </Sidebar>
        <LoadingOverlay
          active={this.state.loading}
          spinner
          text="Please wait..."
        >
          <SimpleMap route={this.state.route} />
          <div>
            <EndContainer>
              <Schedule
                route={this.state.route}
                spareTime={this.state.spareTime}
                incrementSpareTime={() => {
                  this.incrementSpareTimeBy(0.5);
                }}
                decrementSpareTime={() => {
                  this.decrementSpareTimeBy(0.5);
                }}
                timeRow={this.state.timeRow}
              />
            </EndContainer>
          </div>
        </LoadingOverlay>
      </Grid>
    );
  }
}

export default Map;
