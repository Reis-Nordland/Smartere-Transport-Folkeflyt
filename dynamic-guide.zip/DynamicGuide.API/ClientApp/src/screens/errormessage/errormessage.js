import React from "react";
import styled from "styled-components";
import { Event } from "utils/tracking";

const ErrorContainer = styled.div`
  margin-top: 8rem;
  display: flex;
  align-items: center;
  flex-direction: column;
`;

const ErrorTittel = styled.p`
  font-family: "AvinorBold";
  font-size: 60px;
  font-weight: 500;
  font-style: normal;
  font-stretch: normal;
  line-height: normal;
  letter-spacing: normal;
  color: #7d1b6b;
`;

const ErrorButton = styled.button`
  width: 300px;
  font-size: 2rem;
  margin-top: 2rem;
  padding: 2rem;
  border: none;
  background-color: black;
  color: white;
  font-family: "AvinorBold";
`;

export const ErrorMessage = () => {
  return (
    <ErrorContainer>
      <ErrorTittel>Oops something went wrong ...</ErrorTittel>
      <ErrorButton
        onClick={() => {
          Event(
            "Error",
            "Navigate to homepage by clicking on try-again button"
          );

          window.location.href = "/";
        }}
      >
        Try again
      </ErrorButton>
    </ErrorContainer>
  );
};
