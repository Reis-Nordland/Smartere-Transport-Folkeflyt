import styled from "styled-components";

export const Container = styled.div`
  height: 100%;
  padding: 66px 47px 39px 40px;
  position: relative;
  background-color: #f0f1f3;
  z-index: 0;
`;

export const HomeTitle = styled.p`
  font-family: "AvinorBold";
  font-size: 41px;
  width: 400px;
  color: #7d1b6b;
`;

export const SelectOptionsContainer = styled.div`
  display: grid;
  grid-template-rows: 109px 24px 100px 40px 191px 14px 438px;
  grid-template-areas: "." "." ".";
`;

export const OptionContainer = styled.div`
  display: flex;
  flex-direction: column;
  background-color: transparent;
  border: none;
  border-radius: 5px;
`;
