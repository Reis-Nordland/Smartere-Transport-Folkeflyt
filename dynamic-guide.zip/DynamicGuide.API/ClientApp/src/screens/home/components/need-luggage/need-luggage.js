import React, { Component } from "react";

import styled from "styled-components";
import { css } from "emotion";
import Luggage from "icon-components/luggage";

const BlackBox = styled.div`
  width: 286px;
  height: 157px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  background-color: #292929;
`;

const LuggageIconClass = css`
  width: 59px;
  height: 49px;
  path {
    fill: transparent;
    stroke: white;
    stroke-width: 2.5px;
  }
`;

const Title = styled.p`
  margin-top: 5px;
  width: 221px;
  height: 60px;
  font-family: "Avinor";
  font-size: 25px;
  font-weight: bold;
  font-style: normal;
  font-stretch: normal;
  line-height: normal;
  letter-spacing: normal;
  text-align: center;
  color: #ffffff;
`;

class NeedLuggage extends Component {
  render() {
    return (
      <BlackBox>
        <Luggage className={LuggageIconClass} viewBox="0 0 130 100" />
        <Title>Need Luggage Storage?</Title>
      </BlackBox>
    );
  }
}

export default NeedLuggage;
