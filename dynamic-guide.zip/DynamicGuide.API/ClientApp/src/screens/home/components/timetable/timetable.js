import React, { Component } from "react";
import styled from "styled-components";
import TimeRow from "./time-row";
import {
  getHurtigRuta,
  getEnturMoskenes,
  getEnturBodoTerminal
} from "api-requests/boat-api";
import moment from "moment";
import {AnimationMixin, AnimationMixin1} from "../city-center-transfer/city-center-transfer";

const BlackBox = styled.div`
  width: 366px;
  height: 100%;
  box-shadow: ${props => props.isHighlight ? '0px 0px 6px 4px rgb(255, 187, 10)' : '2px 4px 9px 1px rgba(0, 0, 0, 0.15)'};
  background-color: #292929;
  padding: 30px 30px;
  display: flex;
  flex-direction: column;
  
  ${
    props => {
      if(props.isHighlight) {
        return AnimationMixin
      } else {
        return AnimationMixin1
      }
    }
  }
    
`;

const Title = styled.p`
  font-family: "Avinor";
  font-size: 22px;
  color: #ffffff;
  margin-bottom: 5px;
`;

const TitleEmphasize = styled.p`
  font-family: "AvinorBold";
  font-size: 32px;
  color: #ffffff;
`;

const TitleAndIconWrapper = styled.div`
  display: flex;
  flex-direction: column;
  margin-bottom: 15px;
`;

const TimeRows = styled.div`
  display: flex;
  flex-direction: column;
  flex: 1;
  overflow-y: scroll;
  overflow-x: hidden;
  max-width: 100%;
`;

const TimeRowWrapper = styled.div`
  margin: 0.5rem 0rem;
`;

class TimeTable extends Component {
  _isMounted = false;

  state = {
    moskenesBoats: [],
    hurtigRutaBoats: [],
    terminalBoats: []
  };

  getHurtigRutaBoats = async () => {
    try {
      const req = await getHurtigRuta();
      const data = await req.json();
      if (this._isMounted) {
        this.setState(() => ({
          hurtigRutaBoats: this.mapHurtigRutaBoats(data)
        }));
      }
    } catch (e) {
      // this.setState(() => ({ failure: true, loading: false }));
      console.log("error", e);
    }
  };

  mapHurtigRutaBoats = rows => {
    let data = [];
    rows.forEach(row => {
      if(!(row.departureTime === null || row.shipName === null || row.direction === null))
      {
        let dateAndTime = row.departureTime.split(" "),
          date = dateAndTime[0].split("."),
          time = dateAndTime[1].split(":");

        let year = date[2],
          month = date[1] - 1,
          day = date[0],
          hours = time[0],
          minutes = time[1];

        let now = moment(new Date().toISOString()).utc(); //todays date
        let end = moment(
          new Date(year, month, day, hours, minutes).toISOString()
        ).utc(); // boat date

        let duration = moment.duration(end.diff(now)),
          durationInHours = duration.asHours().toFixed(1),
          durationInMinutes = duration.asMinutes();

        if (durationInHours > 10) {
          return;
        }

        let rowData = {
          time: dateAndTime[1],
          spareTime: Math.floor(durationInHours * 2) / 2,
          durationInMinutes: durationInMinutes,
          destination: row.shipName,
          from: "Bodø port",
          fromPoiId: 9,
          icon: "boat.svg",
          iconStyle: { width: 38, height: 22, marginRight: 5 },
          status: ""
        };
        data.push(rowData);
      }
    });
    return data;
  };

  getMoskenesBoats = async () => {
    try {
      const mosk = await getEnturMoskenes();
      const moskData = await mosk.json();
      if (
        this._isMounted &&
        moskData.stopPlace &&
        moskData.stopPlace.estimatedCalls.length
      ) {
        this.setState(() => ({
          moskenesBoats: this.mapEnturBoats(
            moskData.stopPlace.estimatedCalls,
            "port"
          )
        }));
      }
    } catch (e) {
      console.log("error", e);
    }
  };

  mapEnturBoats = (rows, location) => {
    let data = [];
    rows.forEach(row => {
      let now = moment(new Date()); //todays date
      let end = moment(new Date(row.expectedDepartureTime)); // boat date
      let endAimed = moment(new Date(row.aimedDepartureTime)); // boat date
      let duration = moment.duration(end.diff(now)),
        durationInHours = duration.asHours().toFixed(1),
        durationInMinutes = duration.asMinutes();
      let time = new Date(row.expectedDepartureTime).toLocaleTimeString(
        "nb-NO",
        {
          hour: "2-digit",
          minute: "2-digit"
        }
      );
      let delay = moment.duration(end.diff(endAimed)),
        delayInMinutes = delay.asMinutes();

      let status = "";
      if (delayInMinutes > 0) {
        status = "Delay";
      }
      let from = "Error",
        fromPoiId = 9;

      if (location === "port") {
        from = "Bodø port";
        fromPoiId = 9;
      } else if (location === "terminal") {
        from = "Boat terminal";
        fromPoiId = 2;
      }

      let rowData = {
        time: time,
        spareTime: Math.floor(durationInHours * 2) / 2,
        durationInMinutes: durationInMinutes,
        destination: row.serviceJourney.journeyPattern.line.name,
        from: from,
        fromPoiId: fromPoiId,
        icon: "boat.svg",
        iconStyle: { width: 38, height: 22, marginRight: 5 },
        status: status
      };
      data.push(rowData);
    });
    return data;
  };

  getTerminalBoats = async () => {
    try {
      const req = await getEnturBodoTerminal();
      const data = await req.json();

      if (
        this._isMounted &&
        data.stopPlace &&
        data.stopPlace.estimatedCalls.length
      ) {
        this.setState(() => ({
          terminalBoats: this.mapEnturBoats(
            data.stopPlace.estimatedCalls,
            "terminal"
          )
        }));
      }
    } catch (e) {
      console.log("error", e);
    }
  };

  componentDidMount() {
    this._isMounted = true;
    this.getAllBoats();
    this.timer = setInterval(this.getAllBoats, 30000);
  }

  getAllBoats = async () => {
    this.getHurtigRutaBoats();
    this.getMoskenesBoats();
    this.getTerminalBoats();
  };

  componentWillUnmount() {
    this._isMounted = false;
    if (this.timer) {
      clearInterval(this.timer);
    }
  }

  render() {
    return (
      <BlackBox isHighlight={this.props.isHighlight}>
        <TitleAndIconWrapper>
          <Title>Choose your</Title>
          <TitleEmphasize>boat transfer</TitleEmphasize>
        </TitleAndIconWrapper>
        <TimeRows>
          {[
            ...this.state.hurtigRutaBoats,
            ...this.state.moskenesBoats,
            ...this.state.terminalBoats
          ]
            .sort((a, b) => a.durationInMinutes - b.durationInMinutes)
            .map((rowData, index) => {
              return (
                <TimeRowWrapper key={index}>
                  <TimeRow {...rowData} goToMap={this.props.goToMap} />
                </TimeRowWrapper>
              );
            })}
        </TimeRows>
      </BlackBox>
    );
  }
}

export default TimeTable;
