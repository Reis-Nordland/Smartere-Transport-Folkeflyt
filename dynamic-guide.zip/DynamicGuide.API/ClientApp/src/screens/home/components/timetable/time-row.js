import React, { Component } from "react";
import styled, { css } from "styled-components";
import { withRouter } from "react-router-dom";
import { Event } from "utils/tracking";

const Row = styled.div`
  display: grid;
  width: 314px;
  padding: 6px;
  min-height: 44px;
  grid-template-columns: 2fr 4fr 1.5fr;
  grid-template-rows: 1fr;
  grid-template-areas: ". . .";
  grid-column-gap: 21px;
  background-color: black;
  word-break: break-all;
  word-wrap: break-word;
`;

const Time = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  padding-left: 5px;
`;

const YellowText = css`
  font-family: "Avinor";
  font-weight: 500;
  color: #ffbb00;
`;

const TimeText = styled.p`
  font-size: 18px;
  ${YellowText}
`;

const StatusText = styled.p`
  font-family: "Avinor";
  font-size: 11px;
  font-weight: 500;
  font-style: normal;
  font-stretch: normal;
  line-height: normal;
  letter-spacing: normal;
  color: #a3e7d6;
`;

const Destination = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: center;
`;

const DestinationText = styled.p`
  font-size: 18px;
  ${props => !props.notClickable && `text-decoration: underline`}
  /* text-decoration: ${props =>
    props.notClickable ? "none" : "underline"}; */
  ${YellowText}
`;

const FromText = styled.p`
  font-family: Avinor;
  font-size: 11px;
  font-weight: 500;
  color: #ffffff;
`;

const IconContainer = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
`;

class TimeRow extends Component {
  handleClick = () => {
    // let {
    //   time,
    //   status,
    //   from,
    //   destination,
    //   icon,
    //   iconStyle,
    //   spareTime,
    //   fromPoiId,
    //   durationInMinutes,
    //   ...otherProps
    // } = this.props;
    this.props.goToMap({
      ...this.props
    });
    Event("Navigate to map-page", "Click on a departure");
  };

  render() {
    return (
      <Row
        onClick={!this.props.notClickable ? this.handleClick : undefined}
        style={this.props.style}
      >
        <Time>
          <TimeText>{this.props.time}</TimeText>
          <StatusText>{this.props.status}</StatusText>
        </Time>
        <Destination>
          <DestinationText notClickable={this.props.notClickable}>
            {this.props.destination}
          </DestinationText>
          <FromText>From: {this.props.from}</FromText>
        </Destination>
        <IconContainer>
          <img
            src={`/avinor-white-icons/${this.props.icon}`}
            style={this.props.iconStyle}
            alt={this.props.icon}
          />
        </IconContainer>
      </Row>
    );
  }
}

export default withRouter(TimeRow);

TimeRow.defaultProps = {
  time: "10 min",
  status: "Cancelled",
  destination: "Bodø sentrumsterminalen 231",
  from: "Bodø port",
  notClickable: false
};
