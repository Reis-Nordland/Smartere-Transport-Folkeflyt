import React, { Component } from "react";
import styled, { keyframes, css } from "styled-components";
import { getBus } from "api-requests/boat-api";
import moment from "moment";
import { Event } from "utils/tracking";

export const waggle1 = keyframes`
  0% {
    transform: rotateZ(0) scale(1);
  }
  60% {
    transform: rotateZ(0) scale(1.04);
  }
  100% {
    transform: rotateZ(0) scale(1);
  }
`;

export const waggle = keyframes`
   0% {
    transform: rotateZ(0) scale(1.05);
  }
  30% {
    transform: rotateZ(0) scale(1.1);
  }
  100% {
    transform: rotateZ(0) scale(1);
  }
`;

export const AnimationMixin = css`
  animation: ${waggle} 0.3s 0.1s forwards ease-out;
`;

export const AnimationMixin1 = css`
  animation: ${waggle1} 0.2s 0.1s forwards ease-out;
`;

const BlackBox = styled.div`
  width: 366px;
  height: 100%;
  background-color: #292929;
  box-shadow: ${props =>
    props.isHighlight
      ? "0px 0px 6px 4px rgb(255, 187, 10)"
      : "2px 4px 9px 1px rgba(0, 0, 0, 0.15)"};

  position: relative;

  ${props => {
    if (props.isHighlight) {
      return AnimationMixin;
    } else {
      return AnimationMixin1;
    }
  }}

  padding: 24px 30px 36px 24px;
`;

const Title = styled.p`
  max-width: 248px;
  font-family: Avinor;
  font-size: 22px;
  font-weight: 500;
  font-style: normal;
  font-stretch: normal;
  line-height: normal;
  letter-spacing: normal;
  color: #ffffff;
`;

const TitleEmphasize = styled.span`
  font-size: 32px;
  font-family: AvinorBold;
`;

const Row = styled.div`
  display: flex;
  flex-direction: column;
  flex: 1;
  height: 100%;
  justify-content: space-between;
  position: relative;
  z-index: 1;

  &:before {
    content: "";
    background-color: black;
    position: absolute;
    width: 102%;
    height: 150px;
    z-index: -1;
  }
`;

const TransferContainer = styled.div`
  display: flex;
  flex-direction: row;
  /* min-width: 366px; */
  width: 100%;
  justify-content: space-between;
  position: absolute;
  bottom: -0.5rem;
`;

const TravelTime = styled.div`
  margin-left: 5px;
  font-family: Avinor;
  font-size: 16px;
  color: #ffbb00;
  text-decoration: underline;
`;

const TitleAndIcon = styled.div`
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  padding: 1rem;
`;

const CenterIcon = styled.img`
  display: flex;
  border: none;
  background-color: transparent;
  width: 67px;
  height: 49px;
  margin-right: -15px;
`;

const TextAndIcon = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  z-index: 10;
`;

class CityCenterTransfer extends Component {
  state = {
    busTime: 0
  };

  handleClick = () => {
    Event(
      "Navigate to map-page",
      "Click on 'Find your way to the city centre' box"
    );
    this.props.history.push({
      pathname: "/map",
      state: {
        active: "walk"
      }
    });
  };

  handleClickIcon = value => event => {
    event.stopPropagation();

    Event(
      "Navigate to map-page",
      "Click on transfer mode link to city centre",
      `${value}`
    );
    this.props.history.push({
      pathname: "/map",
      state: {
        active: value
      }
    });
  };

  getRemainingBusTime = async () => {
    try {
      let req = await getBus();
      let data = await req.json();

      let now = moment(new Date().toISOString()).utc(); //todays date
      let end = moment(
        new Date(data.expectedDepartureTime).toISOString()
      ).utc(); // bus date

      let duration = moment.duration(end.diff(now)),
        durationInMinutes = Math.ceil(duration.asMinutes());

      if (duration < 0) {
        this.setState(() => ({ busTime: 0 + 5 }));
      }
      this.setState(() => ({ busTime: durationInMinutes + 5 }));
    } catch (e) {
      console.log("error", e);
    }
  };

  componentDidMount() {
    this.getRemainingBusTime();
    this.timer = setInterval(this.getRemainingBusTime, 30000);
  }

  componentWillUnmount() {
    if (this.timer) {
      clearInterval(this.timer);
    }
  }

  render() {
    return (
      <BlackBox
        onClick={this.handleClickIcon("walk")}
        isHighlight={this.props.isHighlight}
      >
        <Row>
          <TitleAndIcon>
            <Title>
              Find your way to the <TitleEmphasize>city centre</TitleEmphasize>
            </Title>

            <CenterIcon src="/avinor-white-icons/yellow-arrow.svg" />
          </TitleAndIcon>
          <TransferContainer>
            <TextAndIcon onClick={this.handleClickIcon("walk")}>
              <img
                src="/avinor-white-icons/walking-man.svg"
                alt="Walk icon"
                width="14"
                height="22"
              />

              <TravelTime>10 min</TravelTime>
            </TextAndIcon>
            <TextAndIcon onClick={this.handleClickIcon("bicycle")}>
              <img
                src="/avinor-white-icons/bicycle.svg"
                alt="Bicycle icon"
                width="32"
                height="21"
              />
              <TravelTime>6 min</TravelTime>
            </TextAndIcon>
            <TextAndIcon onClick={this.handleClickIcon("bus")}>
              <img
                src="/avinor-white-icons/bus.svg"
                alt="Bus icon"
                width="44"
                height="18"
              />
              <TravelTime>{this.state.busTime} min</TravelTime>
            </TextAndIcon>
          </TransferContainer>
        </Row>
      </BlackBox>
    );
  }
}

export default CityCenterTransfer;
