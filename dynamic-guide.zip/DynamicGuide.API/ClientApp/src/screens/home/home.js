import React, { useEffect, useContext } from "react";
import styled from "styled-components";
import {
  Container,
  HomeTitle,
  SelectOptionsContainer,
  OptionContainer
} from "./styled-components";
import CityCenterTransfer from "./components/city-center-transfer/city-center-transfer";
import TimeTable from "./components/timetable/timetable";
import Luggage from "components/luggage";
import { AppContext } from "../../context/app-context";
import { initGA, PageView } from "utils/tracking";

const StaticMap = () => {
  const { state, dispatch } = useContext(AppContext);
  return (
    <img
      onClick={() => {
        dispatch({ type: "toggleClickEvent" });
      }}
      src={`/images/new-bodo-static-map${state.toggle ? "-luggage" : ""}.png`}
      alt="Static Map"
      style={{
        position: "absolute",
        top: 0,
        right: -300,
        height: "100%"
      }}
    />
  );
};

const NeedLuggageWrapper = styled.div`
  position: absolute;
  bottom: 67px;
  right: 47px;
  z-index: 1;
`;

const GetDirections = styled.p`
  font-family: AvinorBold;
  font-size: 89px;
  color: #7d1b6b;
  background-color: white;
  width: 735px;
  z-index: 2;
`;

const Home = props => {
  const { state } = useContext(AppContext);

  useEffect(() => {
    document.getElementsByTagName("body")[0].style.msContentZooming = "none";
    initGA();
    PageView();
  }, []);

  return (
    <Container>
      <SelectOptionsContainer>
        <OptionContainer>
          <GetDirections>Get directions</GetDirections>
        </OptionContainer>
        <OptionContainer />
        <OptionContainer>
          <HomeTitle>City centre is only 10 minutes away</HomeTitle>
        </OptionContainer>
        <OptionContainer />
        <OptionContainer>
          <CityCenterTransfer
            history={props.history}
            isHighlight={state.toggleClickEvent}
          />
        </OptionContainer>
        <OptionContainer />
        <OptionContainer>
          <TimeTable
            isHighlight={state.toggleClickEvent}
            goToMap={timeRow => {
              props.history.push({
                pathname: "/map",
                timeRow: timeRow
              });
            }}
          />
        </OptionContainer>
      </SelectOptionsContainer>
      <NeedLuggageWrapper>
        <Luggage isHighlight={state.toggleClickEvent} />
      </NeedLuggageWrapper>
      <StaticMap />
    </Container>
  );
};

export default Home;
