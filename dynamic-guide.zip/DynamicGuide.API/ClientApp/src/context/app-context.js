import React, { useReducer } from "react";
const initialState = {toggle: false, toggleClickEvent: false}
const AppContext = React.createContext(initialState);

let reducer = (state, action) => {
    if (action.type === "toggle") {
        return { ...state, toggle: !state.toggle };
    } else if (action.type === "toggleClickEvent") {
        return { ...state, toggleClickEvent: !state.toggleClickEvent };
    }
};

function AppProvider(props) {
    const [state, dispatch] = useReducer(reducer, initialState);

    return (
        <AppContext.Provider value={{ state, dispatch }}>
            {props.children}
        </AppContext.Provider>
    );
}
export { AppContext, AppProvider };