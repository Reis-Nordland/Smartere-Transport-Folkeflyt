export const getWeather = async () =>
  fetch("api/weatherforecast/weather?hourDuration=1", {
    method: "GET",
  });
