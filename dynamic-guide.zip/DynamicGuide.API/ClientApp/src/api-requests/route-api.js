export const getRoutes = async (
  start = 1,
  end = 2,
  minutesAvailable = 500,
  transportMode = "walk"
) =>
  fetch(
    `api/folkeflytpoi/route?startPOIID=${start}&endPOIID=${end}&minutesAvailable=${minutesAvailable}&transportMode=${transportMode}`,
    { method: "GET" }
  ).then(resp => {
    return resp;
  });
