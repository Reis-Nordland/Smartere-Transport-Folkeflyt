const getEnturResponses = async (
  stopPlaceId = 49739,
  transportType = "water",
  timeRange = 36050,
  numberOfDepartures = 10
) =>
  fetch(
    `api/enturreiseplanlegger/stopplace?stopPlaceId=${stopPlaceId}&transportType=${transportType}&timeRange=${timeRange}&numberOfDepartures=${numberOfDepartures}`,
    { method: "GET", headers: {} }
  );

//Bodo port
export const getHurtigRuta = async () =>
  fetch('api/hurtigruten/timetable', { method: "GET", headers: {} });
export const getEnturMoskenes = () =>
  getEnturResponses(47301, "water", 36050, 100);

//Bodo terminal
export const getEnturBodoTerminal = () =>
  getEnturResponses(49739, "water", 36050, 100);

//bus

export const getBus = () =>
    fetch('api/enturreiseplanlegger/stopplace/nextBus', {
    method: "GET",
    headers: {}
  });

//Bodo Terminal
// export const getEnturBodBystrand = getEnturResponses();
//transport types: water, air, bus
// Duration | Name | Poi ID | NSR:StopPlace
// 0 Bodø Flyplass: 1 NSR:StopPlace:59258
// 0 Bodø Port: 2 NSR:StopPlace:49739 = | moskenesferga = NSR:StopPlace:47301
// 60 Bodø Bystrand: 3
// 30 Bodø Molo/småbåthavn: 4
// 90 Glasshuset 5, spising
// 30 Stormen bibliotek 6
// 60 Nordlandsmuseet 7//
