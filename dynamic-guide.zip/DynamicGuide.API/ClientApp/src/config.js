export default {
  googleMapsAPIKey: "AIzaSyAAsNsXTdrlWCqQUNCE78wyhKHSWKRTSLs",
  googleAnalyticsKey: "UA-143080179-1"
};
