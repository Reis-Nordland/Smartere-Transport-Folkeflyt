import React, { useEffect } from "react";
import { Route, Switch, BrowserRouter as Router } from "react-router-dom";
import styled from "styled-components";
import Home from "screens/home";
import Map from "screens/map";
import { AppProvider } from "./context/app-context";
import Clock from "components/clock";
import Weather from "components/weather";
import { initGA } from "utils/tracking";

export const Container = styled.div`
  display: grid;
  grid-template-columns: 1fr;
  grid-template-rows: 5.625rem auto;
  grid-column-gap: 0px;
  grid-row-gap: 0px;
  height: 100vh;
  width: 100vw;
  overflow-x: hidden;
  overflow-y: hidden;
`;

const Content = styled.div`
  max-height: 990px;
  max-width: 100%;
`;

export const Header = styled.div`
  padding: 0 36px;
  height: 5.625rem;
  display: flex;
  background-color: black;
  justify-content: space-between;
  align-items: center;
`;

export const HeaderTitle = styled.p`
  width: 639px;
  height: 42px;
  font-family: "Avinor";
  font-size: 35px;
  font-weight: 500;
  font-style: normal;
  font-stretch: normal;
  line-height: normal;
  letter-spacing: normal;
  color: #ffffff;
  margin-left: 37px;
`;

const HeaderLogoAndTitle = styled.div`
  display: flex;
  align-items: center;
`;

const HeaderWeatherAndTime = styled.div`
  display: flex;
  flex-direction: row;
  justify-content: flex-end;
  align-items: center;
  width: 100%;
  height: 100%;
  color: white;
`;

const AvinorLogo = styled.img`
  height: 46px;
  width: 169px;
`;

const WeatherWrapper = styled.div`
  margin-right: 100px;
`;

function App() {
  useEffect(() => {
    /* Timeout and redirect after 3 minuttes */
    const timeoutAndRedirect = () => {
      return setTimeout(() => {
        // ***
        window.location.href = "/";
      }, 180000);
    };

    let timerHandle = timeoutAndRedirect();

    function addListenerMulti(element, eventNames, listener) {
      var events = eventNames.split(" ");
      for (var i = 0; i < events.length; i++) {
        element.addEventListener(events[i], listener, false);
      }
    }

    addListenerMulti(
      document,
      "mousedown mousemove touchstart touchmove",
      () => {
        if (timerHandle) {
          clearTimeout(timerHandle);
        }
        timerHandle = timeoutAndRedirect();
      }
    );
  }, []);

  useEffect(() => {
    initGA();
  }, []);

  return (
    <AppProvider>
      <Container>
        <Router>
          <Header>
            <HeaderLogoAndTitle>
              <AvinorLogo src="/icons/avinor-hvit.png" />
              <HeaderTitle>BODØ LUFTHAVN</HeaderTitle>
            </HeaderLogoAndTitle>
            <HeaderWeatherAndTime>
              <WeatherWrapper>
                <Weather />
              </WeatherWrapper>
              <Clock />
            </HeaderWeatherAndTime>
          </Header>
          <Content>
            <Switch>
              <Route path="/" component={Home} exact />
              <Route path="/map" component={Map} exact />
            </Switch>
          </Content>
        </Router>
      </Container>
    </AppProvider>
  );
}

export default App;
