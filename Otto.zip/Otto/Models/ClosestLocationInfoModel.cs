﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Otto.Models
{
    public class ClosestLocationInfoModel
    {
        public LocationModel Location { get; set; }

        /// <summary>
        /// Distance (by air) in meter
        /// </summary>
        public double DistanceInMeter { get; set; }
    }
}
