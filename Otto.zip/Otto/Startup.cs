using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Otto.Config;
using Otto.Services;
using Otto.Services.Implementation;
using Otto.Facades;
using Otto.Facades.Implementation;
using Otto.CronJob;
using System;
using Microsoft.AspNetCore.Mvc;

[assembly: ApiConventionType(typeof(DefaultApiConventions))]
namespace Otto
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.Configure<OttoAPIConfig>(Configuration.GetSection("OttoApi"));
            services.AddHttpClient();
            services.AddMemoryCache();
            services.AddTransient<IAuthorizationFacade, AuthorizationFacade>();
            services.AddTransient<ILocationFacade, LocationFacade>();
            services.AddTransient<ILocationService,LocationService>();
            services.AddTransient<IAuthorizationService, AuthorizationService>();
            services.AddControllers();


            services.AddCronJob<AuthorizationCronJob>(c =>
            {
#if DEBUG
                c.TimeZoneInfo = TimeZoneInfo.Local;
#else
                c.TimeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById("Europe/Stockholm");
#endif
                // NOTE: Current implementation does not allow for intervals greater than 24 days (see CronJobService.cs)
                c.CronExpression = @"0 1 1,11,21 * *"; // At 01:00 on the 1st, 11th and 21st of each month
            });

            // Register the Swagger services
            services.AddSwaggerDocument(config =>
            {
                config.PostProcess = document =>
                {
                    document.Info.Version = "v1";
                    document.Info.Title = "Otto API";
                    document.Info.Description = "API for the Otto mobility service in Bod�. This API provides information on locations from which a vehicle can be leased.";
                    document.Info.TermsOfService = "None";
                };
            });
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseHttpsRedirection();

            app.UseRouting();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });

            // Register the Swagger generator and the Swagger UI middlewares
            app.UseOpenApi();
            app.UseSwaggerUi3();
        }
    }
}
