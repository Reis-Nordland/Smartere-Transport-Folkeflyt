﻿using System;
using Newtonsoft.Json;
using Otto.Dtos;

namespace Otto.Dtos
{
    public class LocationDto
    {
        [JsonProperty("location_id")]
        public int LocationId { get; set; }

        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("pre_title")]
        public string PreTitle { get; set; }

        [JsonProperty("title")]
        public string Title { get; set; }

        [JsonProperty("campaign")]
        public bool? Campaign { get; set; }

        [JsonProperty("address")]
        public string Address { get; set; }

        [JsonProperty("latitude")]
        public string Latitude { get; set; }

        [JsonProperty("longitude")]
        public string Longitude { get; set; }

        [JsonProperty("cars")]
        public VehicleDto[] Cars { get; set; }

        [JsonProperty("scooters")]
        public VehicleDto[] Scooters { get; set; }

        [JsonProperty("bikes")]
        public VehicleDto[] Bikes { get; set; }
    }
}
