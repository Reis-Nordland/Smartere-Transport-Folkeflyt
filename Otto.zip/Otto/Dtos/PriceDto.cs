﻿using Newtonsoft.Json;
using Otto.Dtos;

namespace Otto.Dtos
{
    public class PriceDto
    {
        [JsonProperty("default")]
        public string Default { get; set; }

        [JsonProperty("minute")]
        public string Minute { get; set; }

        [JsonProperty("hour")]
        public string Hour { get; set; }

        [JsonProperty("day")]
        public string Day { get; set; }

        [JsonProperty("weekend")]
        public string Weekend { get; set; }

        [JsonProperty("week")]
        public string Week { get; set; }

        [JsonProperty("km")]
        public string Km { get; set; }

        [JsonProperty("included_km")]
        public long IncludedKm { get; set; }

        [JsonProperty("membership")]
        public MembershipDto Membership { get; set; }
    }
}
