﻿using System;
using Newtonsoft.Json;
using Otto.Dtos;

namespace Otto.Dtos
{
    public class VehicleDto
    {
        [JsonProperty("vehicle_id")]
        public long VehicleId { get; set; }

        [JsonProperty("licence_plate")]
        public string LicencePlate { get; set; }

        [JsonProperty("brand")]
        public string Brand { get; set; }

        [JsonProperty("model")]
        public string Model { get; set; }

        [JsonProperty("is_electric")]
        public string IsElectric { get; set; }

        [JsonProperty("auto_gearing")]
        public bool AutoGearing { get; set; }

        [JsonProperty("fuel_status")]
        public string FuelStatus { get; set; }

        [JsonProperty("fuel_type")]
        public string FuelType { get; set; }

        [JsonProperty("estimated_range")]
        public string EstimatedRange { get; set; }

        [JsonProperty("description")]
        public string Description { get; set; }

        [JsonProperty("seats")]
        public long Seats { get; set; }

        [JsonProperty("class")]
        public string Class { get; set; }

        [JsonProperty("available_from")]
        public long AvailableFrom { get; set; }

        [JsonProperty("available_blocks")]
        public AvailableBlockDto[] AvailableBlocks { get; set; }

        [JsonProperty("price")]
        public PriceDto Price { get; set; }

        [JsonProperty("available_amount")]
        public long AvailableAmount { get; set; }

        [JsonProperty("image")]
        public Uri Image { get; set; }

    }
}
