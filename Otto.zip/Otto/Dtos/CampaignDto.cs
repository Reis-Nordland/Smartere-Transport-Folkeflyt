﻿using Newtonsoft.Json;

namespace Otto.Dtos
{
    public class CampaignDto
    {
        [JsonProperty("Title")]
        public string Title { get; set; }

        [JsonProperty("Color")]
        public string Color { get; set; }
    }
}
