﻿using Newtonsoft.Json;

namespace Otto.Dtos
{
    public class AvailableBlockDto
    {
        [JsonProperty("title")]
        public string Title { get; set; }

        [JsonProperty("available")]
        public bool Available { get; set; }

        [JsonProperty("from_time")]
        public int FromTime { get; set; }

        [JsonProperty("to_time")]
        public int ToTime { get; set; }
    }
}
