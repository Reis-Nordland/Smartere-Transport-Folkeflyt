﻿using System;
using Newtonsoft.Json;
using Otto.Dtos;

namespace Otto.Dtos
{
    public class LocationsDto
    {
        [JsonProperty("location_id")]
        public int LocationId { get; set; }

        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("address")]
        public string Address { get; set; }

        [JsonProperty("latitude")]
        public string Latitude { get; set; }

        [JsonProperty("longitude")]
        public string Longitude { get; set; }

        [JsonProperty("campaign")]
        public CampaignDto Campaign { get; set; }

        [JsonProperty("car")]
        public string Car { get; set; }

        [JsonProperty("bike")]
        public string Bike { get; set; }

        [JsonProperty("scooter")]
        public string Scooter { get; set; }

        [JsonProperty("locked_garage")]
        public bool LockedGarage { get; set; }

        [JsonProperty("favourite")]
        public bool Favourite { get; set; }
    }
}
