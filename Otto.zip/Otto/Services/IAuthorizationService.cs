﻿using System;
using System.Threading.Tasks;

namespace Otto.Services
{
    public interface IAuthorizationService
    {
        Task FetchAndCacheJwt();
        Task<string> GetCachedJwt();
        bool IsCached();
    }
}