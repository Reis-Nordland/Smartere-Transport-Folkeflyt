﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Otto.Facades;
using Otto.Models;

namespace Otto.Services
{
    public interface ILocationService
    {

        Task<IEnumerable<LocationModel>> FindLocationsWithinCircle(double lat, double lon, double radiusKilometers);
        Task<IEnumerable<LocationModel>> GetLocations();
        Task<IEnumerable<VehicleModel>> GetVehicles(int locationId);
        Task<ClosestLocationInfoModel> FindClosest(double lat, double lon, string transportType);
        Task<IEnumerable<LocationModel>> FindLocationsBodo(string transportType);
    }
}
