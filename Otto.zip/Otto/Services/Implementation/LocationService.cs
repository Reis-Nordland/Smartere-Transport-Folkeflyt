﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Otto.Facades;
using Otto.Models;
using Otto.Mappers;
using System.Linq;
using MoreLinq;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;

namespace Otto.Services.Implementation
{
    public class LocationService : ILocationService
    {
        private readonly ILocationFacade _ottoFacade;
        private readonly IMemoryCache _memoryCache;
        private readonly IConfiguration _configuration;


        public LocationService(ILocationFacade ottoFacade, IMemoryCache memoryCache, IConfiguration configuration)
        {
            _ottoFacade = ottoFacade;
            _memoryCache = memoryCache;
            _configuration = configuration;
        }

        public async Task<IEnumerable<LocationModel>> GetLocations() 
        {
            var locations = _memoryCache.Get<IEnumerable<LocationModel>>(_configuration["AllLocationsCacheKey"]);

            if (locations == null)
            {
                locations = (await _ottoFacade.GetLocations()).ToModel();
                _memoryCache.Set(_configuration["AllLocationsCacheKey"], locations, TimeSpan.FromHours(24));
            }

            return locations;
        }

        public async Task<IEnumerable<VehicleModel>> GetVehicles(int locationId)
        {
            return (await _ottoFacade.GetVehicles(locationId)).ToModel();
        }

        public async Task<ClosestLocationInfoModel> FindClosest(double lat, double lon, string transportType)
        {
            var locations = await GetLocations();

            locations = TransportFilter(locations, transportType);

            var closestLoc = locations.MinBy(loc => CalculateDistance(lat, lon, Convert.ToDouble(loc.Latitude), Convert.ToDouble(loc.Longitude))).First();
            return new ClosestLocationInfoModel
            {
                Location = closestLoc,
                DistanceInMeter = CalculateDistance(lat, lon, Convert.ToDouble(closestLoc.Latitude), Convert.ToDouble(closestLoc.Longitude))
            };
        }

        

        public async Task<IEnumerable<LocationModel>> FindLocationsBodo(string transportType)
        {
            var locations = _memoryCache.Get<IEnumerable<LocationModel>>(_configuration["BodoLocationCacheKey"]);

            if (locations == null)
            {
                locations = await FindLocationsWithinCircle(67.28102243084668, 14.392142535876076, 2.5); ;
                _memoryCache.Set(_configuration["BodoLocationCacheKey"], locations, TimeSpan.FromHours(24));
            }

            return TransportFilter(locations, transportType);
        }

        public async Task<IEnumerable<LocationModel>> FindLocationsWithinCircle(double lat, double lon, double radiusKilometers)
        {
            var locations = await GetLocations();
            return locations.Where(loc => CalculateDistance(lat, lon, loc.Latitude, loc.Longitude) < radiusKilometers * 1000);
        }
        
        private double CalculateDistance(double originLat, double originLon, double inputLat, double inputLon)
        {
            // haversine formula to calculate distance, from https://www.movable-type.co.uk/scripts/latlong.html
            double R = 6359965; // meters; Radius at 67.28 degrees latitude, approximately the latitude of Bodø (https://rechneronline.de/earth-radius/)
            double phi1 = originLat * Math.PI / 180; // radians
            double phi2 = inputLat * Math.PI / 180;
            double deltaPhi = (inputLat - originLat) * Math.PI / 180;
            double deltaLambda = (inputLon - originLon) * Math.PI / 180;

            double a = Math.Sin(deltaPhi / 2) * Math.Sin(deltaPhi / 2) +
                        Math.Cos(phi1) * Math.Cos(phi2) *
                        Math.Sin(deltaLambda / 2) * Math.Sin(deltaLambda / 2);
            double c = 2 * Math.Atan2(Math.Sqrt(a), Math.Sqrt(1 - a));

            return R * c; // distance in meters, accurate to within approx 10 meters
        }


        private IEnumerable<LocationModel> TransportFilter(IEnumerable<LocationModel> locations, string transportType)
        {
            if (transportType == "any_except_car")
                locations = locations.Where(x => (x.SupportedVehicles.Scooter == true) || (x.SupportedVehicles.Bike == true));
            else if (transportType == "bike")
                locations = locations.Where(x => x.SupportedVehicles.Bike == true);
            else if (transportType == "scooter")
                locations = locations.Where(x => x.SupportedVehicles.Scooter == true);
            else if (transportType == "car")
                locations = locations.Where(x => x.SupportedVehicles.Car == true);
            return locations;
        }

    }
}
