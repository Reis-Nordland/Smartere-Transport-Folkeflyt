﻿using System;
using System.Threading.Tasks;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Otto.Facades;

namespace Otto.Services.Implementation
{
    public class AuthorizationService : IAuthorizationService
    {
        private readonly ILogger<AuthorizationService> _logger;
        private readonly IConfiguration _configuration;
        private readonly IAuthorizationFacade _authorizationFacade;
        private readonly IMemoryCache _memoryCache;

        public AuthorizationService(ILogger<AuthorizationService> logger, IConfiguration configuration, IAuthorizationFacade authorizationFacade, IMemoryCache memoryCache)
        {
            _logger = logger;
            _configuration = configuration;
            _authorizationFacade = authorizationFacade;
            _memoryCache = memoryCache;
        }

        public async Task FetchAndCacheJwt()
        {

            _logger.LogInformation("Fetching new JWT from Otto.");
            var jwt = await _authorizationFacade.GetJwt();

            if (jwt != null)
            {
                _memoryCache.Set(_configuration["JwtCacheKey"], jwt, TimeSpan.FromDays(29));
                _logger.LogInformation("New JWT successfully fetched and cached.");
            }
            else
            {
                _logger.LogError("Fetching new JWT failed. Keeping previous JWT as it may still be valid for up to 20 more days.");
            }
            
        }

        public async Task<string> GetCachedJwt()
        {

            var jwt = _memoryCache.Get<string>(_configuration["JwtCacheKey"]);
            
            if (jwt == null)
            { 
                await FetchAndCacheJwt();
                return _memoryCache.Get<string>(_configuration["JwtCacheKey"]);
            }

            return jwt;
        }

        public bool IsCached()
        {
            return _memoryCache.Get<string>(_configuration["JwtCacheKey"]) != null;
        }
    }        
}