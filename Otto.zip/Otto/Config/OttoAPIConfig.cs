﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Otto.Config
{
    public class OttoAPIConfig
    {
        public string BaseUri { get; set; }
        public string Jwt { get; set; }
        public string ClientId { get; set; }
        public string ClientSecret { get; set; }
    }
}
