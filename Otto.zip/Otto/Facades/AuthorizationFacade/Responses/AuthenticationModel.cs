﻿using Newtonsoft.Json;

namespace Otto.Facades
{
    public class AuthenticationResponseDto
    {
        [JsonProperty("token")] 
        public string Token { get; set; }

        [JsonProperty("expires_in")]
        public string ExpiresIn { get; set; }
    }
}
