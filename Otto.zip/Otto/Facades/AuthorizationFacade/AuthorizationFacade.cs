﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Otto.Config;
using Otto.Models;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace Otto.Facades.Implementation
{
    public class AuthorizationFacade : IAuthorizationFacade
    {
        private readonly OttoAPIConfig _ottoApiConfig;
        private readonly IHttpClientFactory _clientFactory;

        public AuthorizationFacade(IOptions<OttoAPIConfig> ottoApiConfig, IHttpClientFactory clientFactory)
        {
            _ottoApiConfig = ottoApiConfig.Value;
            _clientFactory = clientFactory;
        }

        public async Task<string> GetJwt()
        {
            var httpClient = _clientFactory.CreateClient();
            var credentials = new Dictionary<string, string>()
                {{"client_id", _ottoApiConfig.ClientId}, {"client_secret", _ottoApiConfig.ClientSecret}};

            var credentialsJson = JsonConvert.SerializeObject(credentials);

            var body = new StringContent(credentialsJson, Encoding.UTF8, "application/json");

            string content;
            try
            {
                var response = await httpClient.PostAsync(_ottoApiConfig.BaseUri + "auth", body);
                response.EnsureSuccessStatusCode();
                content = await response.Content.ReadAsStringAsync();
            } 
            catch
            {
                return null;
            }


            return JsonConvert.DeserializeObject<AuthenticationResponseDto>(content).Token;
        }
    }
}