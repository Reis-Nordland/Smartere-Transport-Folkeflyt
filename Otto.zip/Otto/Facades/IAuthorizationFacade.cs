﻿using System.Threading.Tasks;

namespace Otto.Facades
{
    public interface IAuthorizationFacade
    {
        Task<string> GetJwt();
    }
}