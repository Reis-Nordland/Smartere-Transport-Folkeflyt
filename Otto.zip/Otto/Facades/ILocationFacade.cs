﻿using Otto.Dtos;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Otto.Facades
{
    public interface ILocationFacade
    {
        Task<LocationResponseDto> GetLocations();
        Task<VehicleResponseDto> GetVehicles(int locationId);
    }
}
