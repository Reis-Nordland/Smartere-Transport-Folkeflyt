﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Otto.Facades
{
    // Otto API returns some deprecated fields; those are not included in this class.

    public class FuelDto
    {
        [JsonProperty("status")]
        public int? Status { get; set; }

        [JsonProperty("type")]
        public string Type { get; set; }

        [JsonProperty("estimated_range")]
        public int? EstimatedRange { get; set; }

        [JsonProperty("wltp")]
        public int? Wltp { get; set; }

        [JsonProperty("capacity")]
        public int? Capacity { get; set; }
    }

    public class OttoLocationDto
    {
        [JsonProperty("id")]
        public int Id { get; set; }

        [JsonProperty("name")]
        public string Name { get; set; }
    }

    public class AttributesDto
    {
        [JsonProperty("auto_gearing")]
        public bool AutoGearing { get; set; }

        [JsonProperty("seats")]
        public int? Seats { get; set; }

        [JsonProperty("class")]
        public string Class { get; set; }

        [JsonProperty("keyless")]
        public bool Keyless { get; set; }

        [JsonProperty("charge_parking")]
        public bool ChargeParking { get; set; }

        [JsonProperty("charge_tollroad")]
        public bool ChargeTollroad { get; set; }

        [JsonProperty("geofence")]
        public bool Geofence { get; set; }
    }

    public class StatesDto
    {
        [JsonProperty("doors")]
        public string Doors { get; set; }

        [JsonProperty("engine")]
        public string Engine { get; set; }

        [JsonProperty("voltage")]
        public double? Voltage { get; set; }
    }

    public class AvailabilityDto
    {
        [JsonProperty("from")]
        public int? From { get; set; }

        [JsonProperty("to")]
        public int? To { get; set; }
    }

    public class PositionDto
    {
        [JsonProperty("latitude")]
        public double? Latitude { get; set; }

        [JsonProperty("longitude")]
        public double? Longitude { get; set; }
    }

    public class PriceDto
    {
        [JsonProperty("default")]
        public string Default { get; set; }

        [JsonProperty("minute")]
        public int? Minute { get; set; }

        [JsonProperty("hour")]
        public int? Hour { get; set; }

        [JsonProperty("day")]
        public int? Day { get; set; }

        [JsonProperty("weekend")]
        public object Weekend { get; set; }

        [JsonProperty("week")]
        public object Week { get; set; }

        [JsonProperty("km")]
        public double? Km { get; set; }

        [JsonProperty("included_km")]
        public int? IncludedKm { get; set; }

        [JsonProperty("membership")]
        public object Membership { get; set; }
    }

    public class VehicleItemDto
    {
        [JsonProperty("id")]
        public int Id { get; set; }

        [JsonProperty("licence_plate")]
        public string LicencePlate { get; set; }

        [JsonProperty("type")]
        public string Type { get; set; }

        [JsonProperty("model")]
        public string Model { get; set; }

        [JsonProperty("brand")]
        public string Brand { get; set; }

        [JsonProperty("description")]
        public string Description { get; set; }

        [JsonProperty("milage")]
        public int? Milage { get; set; }

        [JsonProperty("image")]
        public string Image { get; set; }

        [JsonProperty("fuel")]
        public FuelDto Fuel { get; set; }

        [JsonProperty("location")]
        public OttoLocationDto Location { get; set; }

        [JsonProperty("attributes")]
        public AttributesDto Attributes { get; set; }

        [JsonProperty("states")]
        public StatesDto States { get; set; }

        [JsonProperty("availability")]
        public AvailabilityDto Availability { get; set; }

        [JsonProperty("position")]
        public PositionDto Position { get; set; }

        [JsonProperty("active")]
        public bool Active { get; set; }

        [JsonProperty("price")]
        public PriceDto Price { get; set; }
    }

    public class VehicleResponseDto
    {
        [JsonProperty("total")]
        public int? Total { get; set; }

        [JsonProperty("skip")]
        public int? Skip { get; set; }

        [JsonProperty("take")]
        public int? Take { get; set; }

        [JsonProperty("items")]
        public List<VehicleItemDto> Items { get; set; }
    }


}
