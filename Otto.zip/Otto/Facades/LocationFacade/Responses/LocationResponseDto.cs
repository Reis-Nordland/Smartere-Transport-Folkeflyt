﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Otto.Facades
{
    // Otto API returns some deprecated fields; those are not included in this class.

    public class VehicleSupportDto
    {
        [JsonProperty("car")]
        public bool Car { get; set; }

        [JsonProperty("bike")]
        public bool Bike { get; set; }

        [JsonProperty("scooter")]
        public bool Scooter { get; set; }
    }

    public class LocationItemDto
    {
        [JsonProperty("id")]
        public int Id { get; set; }

        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("address")]
        public string Address { get; set; }

        [JsonProperty("latitude")]
        public double Latitude { get; set; }

        [JsonProperty("longitude")]
        public double Longitude { get; set; }

        [JsonProperty("locked_garage")]
        public bool LockedGarage { get; set; }

        [JsonProperty("favourite")]
        public bool Favourite { get; set; }

        [JsonProperty("vehicle_support")]
        public VehicleSupportDto VehicleSupport { get; set; }

        [JsonProperty("has_remote_opener")]
        public bool HasRemoteOpener { get; set; }
    }

    public class LocationResponseDto
    {
        [JsonProperty("total")]
        public int Total { get; set; }

        [JsonProperty("skip")]
        public int Skip { get; set; }

        [JsonProperty("take")]
        public int Take { get; set; }

        [JsonProperty("items")]
        public List<LocationItemDto> Items { get; set; }
    }



}
