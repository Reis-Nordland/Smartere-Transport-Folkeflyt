﻿using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Otto.Dtos;
using Otto.Config;
using Microsoft.Extensions.Options;
using Otto.Models;
using Otto.Services;
using Otto.Facades;

namespace Otto.Facades.Implementation
{
    public class LocationFacade : ILocationFacade
    {

        private readonly OttoAPIConfig _ottoApiConfig;
        private readonly IAuthorizationService _authorizationService;
        private readonly IHttpClientFactory _clientFactory;

        public LocationFacade(IOptions<OttoAPIConfig> ottoApiConfig, IAuthorizationService authorizationService, IHttpClientFactory clientFactory)
        {
            _ottoApiConfig = ottoApiConfig.Value;
            _authorizationService = authorizationService;
            _clientFactory = clientFactory;
        }

        public async Task<LocationResponseDto> GetLocations()
        {
            var httpClient = _clientFactory.CreateClient();
            var jwt = await _authorizationService.GetCachedJwt();
            httpClient.DefaultRequestHeaders.Add("Authorization", "Bearer " + jwt);
            httpClient.DefaultRequestHeaders.Add("x-app-id", "Folkeflyt-SopraSteria");

            var response = await httpClient.GetAsync(_ottoApiConfig.BaseUri + @"locations"); //?query=bod%C3%B8\
            var content = await response.Content.ReadAsStringAsync();
            
            return JsonConvert.DeserializeObject<LocationResponseDto>(content);
        }

        public async Task<VehicleResponseDto> GetVehicles(int locationId)
        {
            var httpClient = _clientFactory.CreateClient();
            var jwt = await _authorizationService.GetCachedJwt();
            httpClient.DefaultRequestHeaders.Add("Authorization", "Bearer " + jwt);
            httpClient.DefaultRequestHeaders.Add("x-app-id", "Folkeflyt-SopraSteria");

            var response = await httpClient.GetAsync(_ottoApiConfig.BaseUri + $"vehicles?filters={{\"location_id\":[{locationId}]}}");
            var content = await response.Content.ReadAsStringAsync();

            return JsonConvert.DeserializeObject<VehicleResponseDto>(content);
        }
    }
}
