﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Otto.Models;
using Otto.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Threading.Tasks;

namespace Otto.Controllers
{
    [ApiController]
    public class LocationsController : Controller
    {
        private readonly ILogger<LocationsController> _logger;
        private readonly ILocationService _locationService;

        public LocationsController(ILogger<LocationsController> logger, ILocationService locationService)
        {
            _logger = logger;
            _locationService = locationService;
        }

        /// <summary>
        /// List all Otto stations
        /// </summary>
        /// <remarks>
        /// Get all available Otto stations. It is recommended to use BodoLocations for locations in the Bodø area.
        /// </remarks>
        [Route("Locations")]
        [HttpGet]
        public async Task<IEnumerable<LocationModel>> GetLocations()
        {
            return await _locationService.GetLocations();
        }

        /// <summary>
        /// Get vehicles
        /// </summary>
        /// <param name="location_id">
        /// The ID of the Otto station you wish to get vehicles from.
        /// </param>
        /// <remarks>
        /// Get detailed list of vehicles at a station.
        /// </remarks>
        [HttpGet("Vehicles/{location_id}")]
        public async Task<IEnumerable<VehicleModel>> GetVehicles(int location_id)
        {
            return await _locationService.GetVehicles(location_id);
        }


        /// <summary>
        /// Get closest location
        /// </summary>
        /// <param name="latitude"></param>
        /// <param name="longitude"></param>
        /// <param name="vehicle_type">
        /// The desired supported vehicle type(s). Defaults to "any" if omitted.
        /// </param>
        /// <remarks>
        /// Get the closest Otto location (by air). Returns the location info as well as the distance from where you currently are.
        /// </remarks>
        [HttpGet("FindClosest")]
        public async Task<ClosestLocationInfoModel> FindClosest(
            VehicleTypeEnum? vehicle_type,
            [Required] double latitude = 67.28102243084668,
            [Required] double longitude = 14.392142535876076
            )
        {
            if (vehicle_type == null)
            {
                vehicle_type = VehicleTypeEnum.any;
            }

            return await _locationService.FindClosest(latitude, longitude, Convert.ToString(vehicle_type));
        }

        /// <summary>
        /// Get Bodø locations
        /// </summary>
        /// <param name="vehicle_type">
        /// The desired supported vehicle type(s). Defaults to "any" if omitted.
        /// </param>
        /// <remarks>
        /// Get all stations within Bodø.
        /// </remarks>
        [HttpGet("BodoLocations")]
        public async Task<IEnumerable<LocationModel>> FindWithinBodo(VehicleTypeEnum? vehicle_type)
        {
            if (vehicle_type == null)
            {
                vehicle_type = VehicleTypeEnum.any;
            }

            return await _locationService.FindLocationsBodo(Convert.ToString(vehicle_type));
        }
    }
}
