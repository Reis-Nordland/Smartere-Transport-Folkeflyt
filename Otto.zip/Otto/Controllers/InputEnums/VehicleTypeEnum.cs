﻿using Newtonsoft.Json.Converters;
using System.Runtime.Serialization;
using System.Text.Json.Serialization;

namespace Otto.Controllers
{
    [JsonConverter(typeof(StringEnumConverter))]
    public enum VehicleTypeEnum
    {
        [EnumMember(Value = "any")]
        any,
        [EnumMember(Value = "bike")]
        bike,
        [EnumMember(Value = "scooter")]
        scooter,
        [EnumMember(Value = "car")]
        car,
        [EnumMember(Value = "any_except_car")]
        any_except_car
    }
}
