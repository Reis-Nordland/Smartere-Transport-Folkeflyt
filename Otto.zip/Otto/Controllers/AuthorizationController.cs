﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Otto.Services;
using System.ComponentModel;

namespace Otto.Controllers
{
    [Route ("[controller]")]
    [ApiController]
    public class AuthorizationController : ControllerBase
    {

        private readonly IAuthorizationService _authorizationService;

        public AuthorizationController(IAuthorizationService authorizationService)
        {
            _authorizationService = authorizationService;
        }

        //[Route("IsCached")]
        //[Description("Checks if a JWT is cached (should always be true)")]
        //[HttpGet]
        //public bool JwtIsCached()
        //{
        //    return _authorizationService.IsCached();
        //}

        //[Route("Cache")]
        //[Description("Manually caches a new JWT token (should always be unnecessary)")]
        //[HttpGet]
        //public async Task<OkResult> CacheJwt()
        //{
        //    await _authorizationService.FetchAndCacheJwt();
        //    return Ok();
        //}

        //[Route("GetCachedJWT")]
        //[HttpGet]
        //public async Task<string> GetCachedJwt()
        //{
        //    return await _authorizationService.GetCachedJwt();
        //}
    }
}
