﻿using Microsoft.Extensions.Logging;
using Otto.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Otto.CronJob
{
    public class AuthorizationCronJob : CronJobService
    {
        private readonly ILogger<AuthorizationCronJob> _logger;
        private readonly IAuthorizationService _authorizationService; 

        public AuthorizationCronJob(IScheduleConfig<AuthorizationCronJob> config, ILogger<AuthorizationCronJob> logger, IAuthorizationService authorizationService)
            : base(config.CronExpression, config.TimeZoneInfo)
        {
            _logger = logger;
            _authorizationService = authorizationService;
        }

        public override Task StartAsync(CancellationToken cancellationToken)
        {
            _logger.LogInformation("CronJob for new JWT starts.");
            return base.StartAsync(cancellationToken);
        }

        public override Task DoWork(CancellationToken cancellationToken)
        {
            _authorizationService.FetchAndCacheJwt();
            return Task.CompletedTask;
        }

        public override Task StopAsync(CancellationToken cancellationToken)
        {
            _logger.LogInformation("CronJob for new JWT starts.");
            return base.StopAsync(cancellationToken);
        }
    }
}
