﻿namespace Otto.CronJob
{
    public class ScheduleConfig<T> : IScheduleConfig<T>
    {
        public string CronExpression { get; set; }
        public System.TimeZoneInfo TimeZoneInfo { get; set; }
    }
}