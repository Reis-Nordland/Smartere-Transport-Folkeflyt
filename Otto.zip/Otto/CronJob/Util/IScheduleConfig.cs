﻿namespace Otto.CronJob
{
    public interface IScheduleConfig<T>
    {
        string CronExpression { get; set; }
        System.TimeZoneInfo TimeZoneInfo { get; set; }
    }
}