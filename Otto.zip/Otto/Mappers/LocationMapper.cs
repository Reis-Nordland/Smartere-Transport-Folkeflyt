﻿using Otto.Dtos;
using Otto.Facades;
using Otto.Models;
using System.Collections.Generic;
using System.Linq;

namespace Otto.Mappers
{
    public static class LocationMapper
    {
        public static IEnumerable<LocationModel> ToModel(this LocationResponseDto dto)
        {
            return dto.Items.Select(x => x.ToModel()).ToList();
        }

        public static LocationModel ToModel(this LocationItemDto dto)
        {
            return new LocationModel
            {
                Address = dto.Address,
                Favourite = dto.Favourite,
                HasRemoteOpener = dto.HasRemoteOpener,
                Id = dto.Id,
                Latitude = dto.Latitude,
                Longitude = dto.Longitude,
                LockedGarage = dto.LockedGarage,
                Name = dto.Name,
                SupportedVehicles = new VehicleSupport
                {
                    Bike = dto.VehicleSupport.Bike,
                    Car = dto.VehicleSupport.Car,
                    Scooter = dto.VehicleSupport.Scooter
                }
            };
        }
    }
}


