﻿using Otto.Facades;
using Otto.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Otto.Mappers
{
    public static class VehicleMapper
    {
        public static IEnumerable<VehicleModel> ToModel(this VehicleResponseDto dto)
        {
            return dto.Items?.Select(x => x.ToModel());
        }

        public static VehicleModel ToModel(this VehicleItemDto dto)
        {
            return new VehicleModel // I wish I had bothered to look into automappers
            {
                Active = dto.Active,
                Attributes = new Attributes
                {
                    AutoGearing = dto.Attributes.AutoGearing,
                    ChargeParking = dto.Attributes.ChargeParking,
                    ChargeTollroad = dto.Attributes.ChargeTollroad,
                    Class = dto.Attributes.Class,
                    Geofence = dto.Attributes.Geofence,
                    Keyless = dto.Attributes.Keyless,
                    Seats = dto.Attributes.Seats
                },
                Availability = new Availability
                {
                    From = dto.Availability.From,
                    To = dto.Availability.To
                },
                Brand = dto.Brand,
                Description = dto.Description,
                Fuel = new Fuel
                {
                    Capacity = dto.Fuel.Capacity,
                    EstimatedRange = dto.Fuel.EstimatedRange,
                    Status = dto.Fuel.Status,
                    Type = dto.Fuel.Type,
                    Wltp = dto.Fuel.Wltp
                },
                Type = dto.Type,
                Id = dto.Id,
                Image = dto.Image,
                LicencePlate = dto.LicencePlate,
                Location = new OttoLocation
                {
                    Id = dto.Location.Id,
                    Name = dto.Location.Name
                },
                Mileage = dto.Milage,
                Model = dto.Model,
                Position = new Position
                {
                    Latitude = dto.Position.Latitude,
                    Longitude = dto.Position.Longitude
                },
                States = new States
                {
                    Doors = dto.States.Doors,
                    Engine = dto.States.Engine,
                    Voltage = dto.States.Voltage
                },
                Price = new Price
                {
                    Day = dto.Price.Day,
                    Default = dto.Price.Default,
                    Hour = dto.Price.Hour,
                    IncludedKm = dto.Price.IncludedKm,
                    Km = dto.Price.Km,
                    Membership = dto.Price.Membership,
                    Minute = dto.Price.Minute,
                    Week = dto.Price.Week,
                    Weekend = dto.Price.Weekend
                }
            };
        }
    }
}
