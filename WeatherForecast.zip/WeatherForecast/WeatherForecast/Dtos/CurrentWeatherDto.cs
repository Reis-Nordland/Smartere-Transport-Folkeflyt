﻿using Newtonsoft.Json;

namespace WeatherForecast.Dtos
{
    public class CurrentWeatherDto
    {
        [JsonProperty("air_pressure_at_sea_level[hPa]")]
        public double? air_pressure_at_sea_level { get; set; }

        [JsonProperty("air_temperature[C]")]
        public double? air_temperature { get; set; }

        [JsonProperty("cloud_area_fraction[%]")]
        public double? cloud_area_fraction { get; set; }

        [JsonProperty("cloud_area_fraction_high[%]")]
        public double? cloud_area_fraction_high { get; set; }

        [JsonProperty("cloud_area_fraction_low[%]")]
        public double? cloud_area_fraction_low { get; set; }

        [JsonProperty("cloud_area_fraction_medium[%]")]
        public double? cloud_area_fraction_medium { get; set; }

        [JsonProperty("dew_point_temperature[C]")]
        public double? dew_point_temperature { get; set; }

        [JsonProperty("fog_area_fraction[%]")]
        public double? fog_area_fraction { get; set; }

        [JsonProperty("relative_humidity[%]")]
        public double? relative_humidity { get; set; }

        [JsonProperty("wind_from_direction[degrees]")]
        public double? wind_from_direction { get; set; }

        [JsonProperty("wind_speed[m/s]")]
        public double? wind_speed { get; set; }

        [JsonProperty("wind_speed_of_gust[m/s]")]
        public double? wind_speed_of_gust { get; set; }

        [JsonProperty("weather_description")]
        public string weather_description { get; set; }

        [JsonProperty("next_hour_precipitation_probability[%]")]
        public double? probability_of_precipitation { get; set; }

        [JsonProperty("next_hour_predicted_precipitation_amount[mm]")]
        public double? precipitation_amount { get; set; }
    }
}
