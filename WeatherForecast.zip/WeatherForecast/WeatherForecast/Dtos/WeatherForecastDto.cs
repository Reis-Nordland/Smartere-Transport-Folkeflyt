﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace WeatherForecast.Dtos
{
    public class WeatherForecastDto
    {
        public double? windSpeed { get; set; }

        public double? windDirection { get; set; }

        public double? temperature { get; set; }

        public PrecipitationDto precipitation { get; set; }

        public WeatherSymbolDto weatherSymbol { get; set; }
    }

    public class WeatherSymbolDto
    {
        public int? number { get; set; }
        public string text { get; set; }
    }

    public class PrecipitationDto
    {
        public double? probabilityOfPrecipitation { get; set; }
        public double? precipitationAmount { get; set; }
    }
}
