﻿using System;
using System.Linq;
using WeatherForecast.Client;

namespace WeatherForecast.Dtos
{
    public static class WeatherForecastMapper
    {
        public static WeatherForecastDto ToWeatherForecastDto(this METJSONForecast metJsonForecast, int startHour = 0, int hourDuration = 1)
        {


            DateTime fromHour;

            fromHour = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, DateTime.Now.Hour+startHour, 0, 0);
#if !DEBUG
            fromHour = TimeZoneInfo.ConvertTimeFromUtc(fromHour, TimeZoneInfo.FindSystemTimeZoneById("Europe/Stockholm"));
#endif

            //If current hour has more than 29 minutes passed, gets from the next hour. Example 10:31 -> 11:00 to 12:00 instead of 10:00 to 11:00
            if (DateTime.Now.Minute > 29)
            {
                fromHour.AddHours(1);
            }

            var resultDto = new WeatherForecastDto();

            var dataForThisTimeSpan = metJsonForecast.Properties.Timeseries.First(x => DateTime.Parse(x.Time) == fromHour);

            resultDto.windSpeed = dataForThisTimeSpan.Data.Instant.Details.Wind_speed;
            resultDto.windDirection = dataForThisTimeSpan.Data.Instant.Details.Wind_from_direction;
            resultDto.temperature = dataForThisTimeSpan.Data.Instant.Details.Air_temperature;

            if (hourDuration == 1)
            {
                resultDto.precipitation = new PrecipitationDto 
                {
                    probabilityOfPrecipitation = dataForThisTimeSpan.Data.Next_1_hours.Details.Probability_of_precipitation,
                    precipitationAmount = dataForThisTimeSpan.Data.Next_1_hours.Details.Precipitation_amount
                };
                resultDto.weatherSymbol = new WeatherSymbolDto
                {
                    number = (int?)dataForThisTimeSpan.Data.Next_1_hours.Summary.Symbol_code,
                    text = Convert.ToString(dataForThisTimeSpan.Data.Next_1_hours.Summary.Symbol_code).ToLower()
                };
                
            }
            else if (hourDuration == 6)
            {
                resultDto.precipitation = new PrecipitationDto
                {
                    probabilityOfPrecipitation = dataForThisTimeSpan.Data.Next_6_hours.Details.Probability_of_precipitation,
                    precipitationAmount = dataForThisTimeSpan.Data.Next_6_hours.Details.Precipitation_amount
                };
                resultDto.weatherSymbol = new WeatherSymbolDto
                {
                    number = (int?)dataForThisTimeSpan.Data.Next_6_hours.Summary.Symbol_code,
                    text = Convert.ToString(dataForThisTimeSpan.Data.Next_6_hours.Summary.Symbol_code).ToLower()
                };
            }
            else if (hourDuration == 12)
            {
                resultDto.precipitation = new PrecipitationDto
                {
                    probabilityOfPrecipitation = dataForThisTimeSpan.Data.Next_12_hours.Details.Probability_of_precipitation,
                    precipitationAmount = dataForThisTimeSpan.Data.Next_12_hours.Details.Precipitation_amount
                };
                resultDto.weatherSymbol = new WeatherSymbolDto
                {
                    number = (int?)dataForThisTimeSpan.Data.Next_12_hours.Summary.Symbol_code,
                    text = Convert.ToString(dataForThisTimeSpan.Data.Next_12_hours.Summary.Symbol_code).ToLower()
                };
            }
            else { throw new ArgumentException("Duration can only be 1, 6, or 12", nameof(hourDuration)); }

            return resultDto;
        }

    }
}
