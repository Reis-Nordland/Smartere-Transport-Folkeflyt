﻿using System;
using System.Linq;
using WeatherForecast.Client;

namespace WeatherForecast.Dtos
{
    public static class CurrentWeatherMapper
    {
        public static CurrentWeatherDto ToCurrentWeatherDto(this METJSONForecast metJsonForecast)
        {

            var fromHour = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, DateTime.Now.Hour, 0, 0);
#if !DEBUG
            fromHour = TimeZoneInfo.ConvertTimeFromUtc(fromHour, TimeZoneInfo.FindSystemTimeZoneById("Europe/Stockholm"));
#endif

            //If current hour has more than 29 minutes passed, gets from the next hour. Example 10:31 -> 11:00 to 12:00 instead of 10:00 to 11:00
            if (DateTime.Now.Minute > 29)
            {
                fromHour.AddHours(1);
            }

            var dataForThisTimeSpan = metJsonForecast.Properties.Timeseries.FirstOrDefault(x => DateTime.Parse(x.Time) == fromHour);


            return new CurrentWeatherDto()
            {
                air_pressure_at_sea_level = dataForThisTimeSpan.Data.Instant.Details.Air_pressure_at_sea_level,
                air_temperature = dataForThisTimeSpan.Data.Instant.Details.Air_temperature,
                cloud_area_fraction = dataForThisTimeSpan.Data.Instant.Details.Cloud_area_fraction,
                cloud_area_fraction_high = dataForThisTimeSpan.Data.Instant.Details.Cloud_area_fraction_high,
                cloud_area_fraction_low = dataForThisTimeSpan.Data.Instant.Details.Cloud_area_fraction_low,
                cloud_area_fraction_medium = dataForThisTimeSpan.Data.Instant.Details.Cloud_area_fraction_medium,
                dew_point_temperature = dataForThisTimeSpan.Data.Instant.Details.Dew_point_temperature,
                fog_area_fraction = dataForThisTimeSpan.Data.Instant.Details.Fog_area_fraction,
                relative_humidity = dataForThisTimeSpan.Data.Instant.Details.Relative_humidity,
                wind_from_direction = dataForThisTimeSpan.Data.Instant.Details.Wind_from_direction,
                wind_speed = dataForThisTimeSpan.Data.Instant.Details.Wind_speed,
                wind_speed_of_gust = dataForThisTimeSpan.Data.Instant.Details.Wind_speed_of_gust,
                probability_of_precipitation = dataForThisTimeSpan.Data.Next_1_hours.Details.Probability_of_precipitation,
                precipitation_amount = dataForThisTimeSpan.Data.Next_1_hours.Details.Precipitation_amount,
                weather_description = Convert.ToString(dataForThisTimeSpan.Data.Next_1_hours.Summary.Symbol_code).ToLower(),
            };

        }
    }
}
