﻿using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WeatherForecast.Client;
using WeatherForecast.Dtos;

namespace WeatherForecast.Services.Implementations
{
    public class WeatherService : IWeatherService
    {
        private readonly IClient _client;
        private readonly IMemoryCache _memoryCache;
        private readonly IConfiguration _configuration;

        public WeatherService(IClient client, IMemoryCache memoryCache, IConfiguration configuration)
        {
            _client = client;
            _memoryCache = memoryCache;
            _configuration = configuration;
        }

        private async Task<METJSONForecast> GetWeatherData(double lat, double lon)
        {
            float latitude = (float)lat;
            float longitude = (float)lon;
            var results = await _client.CompleteAsync(null, latitude, longitude);
            return results;
        }

        private async Task<METJSONForecast> GetCachedWeatherDataOrCacheNew(double lat, double lon)
        {
            if (lat != 67.280357 || lon != 14.404916)
            {
                var uncachedResults = await GetWeatherData(lat, lon);
                return uncachedResults;
            }

            var results = await _memoryCache.GetOrCreateAsync(_configuration["CacheKey"], entry => { 
                entry.AbsoluteExpirationRelativeToNow = TimeSpan.FromMinutes(60);
                return GetWeatherData(lat, lon);
                });

            return results;
        }

        public async Task<WeatherForecastDto> GetAndFormatWeatherData(int startHour, int hourDuration, double lat, double lon)
        {
            var results = await GetCachedWeatherDataOrCacheNew(lat, lon);
   
            return results.ToWeatherForecastDto(startHour, hourDuration);
        }

        public async Task<CurrentWeatherDto> GetCurrentWeather()
        {
            var results = await GetCachedWeatherDataOrCacheNew(67.280357, 14.404916); // Bodo's coordinates

            return results.ToCurrentWeatherDto();
        }
    }
}
