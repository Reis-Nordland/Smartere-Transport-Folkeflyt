﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WeatherForecast.Client;
using WeatherForecast.Dtos;

namespace WeatherForecast.Services
{
    public interface IWeatherService
    {
        Task<WeatherForecastDto> GetAndFormatWeatherData(int startHour, int hourDuration, double lat, double lon);
        Task<CurrentWeatherDto> GetCurrentWeather();
    }
}
