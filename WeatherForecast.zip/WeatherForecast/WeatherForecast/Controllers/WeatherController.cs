﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Xml.Serialization;
//using HtmlAgilityPack;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using WeatherForecast.Client;
using WeatherForecast.Dtos;
using WeatherForecast.Services;

namespace WeatherForecast.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class WeatherController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        private readonly IWeatherService _weatherService;

        public WeatherController(IConfiguration configuration, IWeatherService weatherService)
        {
            _configuration = configuration;
            _weatherService = weatherService;
        }

        /// <summary>
        /// Get weather forecast for location
        /// </summary>>
        /// <remarks>
        /// Get weather forecast for a location for startHours to endHours, 1, 6 or 12 hours difference. Default location is Bodø.
        /// </remarks>
        [HttpGet]
        public async Task<WeatherForecastDto> Get(int startHour = 0, int hourDuration = 1, double latitude = 67.280357, double longitude = 14.404916)
        {
            var results = await _weatherService.GetAndFormatWeatherData(startHour, hourDuration, latitude, longitude);
            return results;
        }

        /// <summary>
        /// Get current weather conditions in Bodø
        /// </summary>>
        /// <remarks>
        /// Get detailed information about current weather conditions in Bodø
        /// </remarks>
        [Route("CurrentWeather")]
        [HttpGet]
        public async Task<CurrentWeatherDto> GetCurrentWeather()
        {
            var results = await _weatherService.GetCurrentWeather();
            return results;
        }


        // May be useful

        //[Route("IsCached")]
        //[HttpGet]
        //[Description("Checks whether the data for Bodø (the default coordinates) is currently cached")]
        //public bool IsCached()
        //{
        //    return _weatherService.IsCached();
        //}
    }
}
