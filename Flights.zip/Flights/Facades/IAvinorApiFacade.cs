﻿using System.Collections.Generic;
using System.Collections.Specialized;
using System.Threading.Tasks;
using Flights.Dtos;

namespace Flights.Facades
{
    public interface IAvinorApiFacade
    {
        Task<IEnumerable<AirportNameDto>> GetAirports();

        Task<IEnumerable<FlightStatusDto>> GetFlightStatuses();

        Task<AirportDto> GetFlights(NameValueCollection parameters);
        Task<AirportDto> GetLast24Hours(NameValueCollection parameters);
    }
}
