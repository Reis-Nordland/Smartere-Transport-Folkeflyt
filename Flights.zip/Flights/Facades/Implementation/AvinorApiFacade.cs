﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web;
using System.Xml.Serialization;
using Flights.Config;
using Flights.Dtos;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Options;

namespace Flights.Facades.Implementation
{
    public class AvinorApiFacade : IAvinorApiFacade
    {
        private readonly IHttpClientFactory _clientFactory;
        private readonly IMemoryCache _cache;
        private readonly AvinorApiConfig _apiConfig;

        public AvinorApiFacade(IHttpClientFactory clientFactory, IOptions<AvinorApiConfig> options, IMemoryCache memoryCache)
        {
            _clientFactory = clientFactory;
            _cache = memoryCache;
            _apiConfig = options.Value;

        }

        public async Task<IEnumerable<AirportNameDto>> GetAirports()
        {
            var cacheKey = "folkeflyt.airports";
            if (!_cache.TryGetValue(cacheKey, out IEnumerable<AirportNameDto> airports))
            {
                var data = await PerformRequestAndSerialize<AirportNamesDto>("airportNames.asp");
                airports = data?.AirportName;
                var cacheOptions = new MemoryCacheEntryOptions().SetAbsoluteExpiration(TimeSpan.FromHours(24));
                _cache.Set(cacheKey, airports, cacheOptions);
            }

            return airports;
        }

        public async Task<IEnumerable<FlightStatusDto>> GetFlightStatuses()
        {
            var cacheKey = "folkeflyt.statuses";
            if (!_cache.TryGetValue(cacheKey, out IEnumerable<FlightStatusDto> statuses))
            {
                var data = await PerformRequestAndSerialize<FlightStatusesDto>("flightStatuses.asp");
                statuses = data.FlightStatus;
                var cacheOptions = new MemoryCacheEntryOptions().SetAbsoluteExpiration(TimeSpan.FromHours(24));
                _cache.Set(cacheKey, statuses, cacheOptions);
            }
            return statuses;
        }

        public async Task<AirportDto> GetFlights(NameValueCollection parameters)
        {
            var cacheKey = "folkeflyt.flights";
            if (!_cache.TryGetValue(cacheKey, out AirportDto flights))
            {
                var args = new NameValueCollection(parameters);

                args.Set("timeFrom", "0");
                args.Set("timeTo", "4");

                flights = await PerformRequestAndSerialize<AirportDto>("XmlFeed.asp",
                     string.Join("&", args.AllKeys.Select(key => string.Concat(HttpUtility.UrlEncode(key), "=", HttpUtility.UrlEncode(args[key]))).ToArray()));
                var cacheOptions = new MemoryCacheEntryOptions().SetAbsoluteExpiration(TimeSpan.FromMinutes(3));
                _cache.Set(cacheKey, flights, cacheOptions);
            }

            return flights;
        }

        public async Task<AirportDto> GetLast24Hours(NameValueCollection parameters)
        {
            var cacheKey = "folkeflyt.last24hours";
            if (!_cache.TryGetValue(cacheKey, out AirportDto flights))
            {
                var args = new NameValueCollection(parameters);

                args.Set("timeFrom", "24");
                args.Set("timeTo", "0");

                flights = await PerformRequestAndSerialize<AirportDto>("XmlFeed.asp",
                     string.Join("&", args.AllKeys.Select(key => string.Concat(HttpUtility.UrlEncode(key), "=", HttpUtility.UrlEncode(args[key]))).ToArray()));
                var cacheOptions = new MemoryCacheEntryOptions().SetAbsoluteExpiration(TimeSpan.FromHours(1));
                _cache.Set(cacheKey, flights, cacheOptions);
            }

            return flights;
        }

        private async Task<T> PerformRequestAndSerialize<T>(string endpoint, string param = null) where T : class
        {
            var httpClient = _clientFactory.CreateClient();
            var uriBuilder = new UriBuilder(new Uri(_apiConfig.BaseUri)) { Path = endpoint, Query = param };
            var response = await httpClient.GetStreamAsync(uriBuilder.Uri);
            var serializer = new XmlSerializer(typeof(T));

            return serializer.Deserialize(response) as T;
        }
    }
}
