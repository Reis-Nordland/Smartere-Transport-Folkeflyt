﻿using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Threading.Tasks;
using Flights.Models;
using Flights.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Flights.Controllers
{
    /// <summary>
    /// Get data about current flights
    /// </summary>
    [Route("flights")]
    [ApiController]
    public class FlightsController : ControllerBase
    {
        private readonly IFlightDataApiService _flightDataApi;
        public FlightsController(IFlightDataApiService flightDataApi)
        {
            _flightDataApi = flightDataApi;
        }

        /// <summary>
        /// Flights
        /// </summary>
        /// <remarks>
        /// Get all departures and arrivals for Bodø Airport in the next 4 hours. 
        /// Responses are cached for 3 minutes.</remarks>
        /// <returns>All arrivals and departures</returns>
        [HttpGet]
        public async Task<AirportFlightsModel> Get()
        {
            var data = await _flightDataApi.GetFlights(new NameValueCollection { { "airport", "BOO" } });
            return data;
        }

        /// <summary>
        /// Departures
        /// </summary>
        /// <remarks>
        /// Get all flights departing from Bodø Airport in the next 4 hours.
        /// </remarks>
        /// <returns>All departing flights</returns>
        [HttpGet("departures")]
        public async Task<AirportFlightsModel> GetDepartures()
        {
            var data = await _flightDataApi.GetFlights(new NameValueCollection { { "airport", "BOO" }, { "direction", "D" } });
            return data;
        }

        /// <summary>
        /// Arrivals
        /// </summary>
        /// <remarks>
        /// Get all flights arriving at Bodø Airport in the next 4 hours.
        /// </remarks>
        /// <returns>All arriving flights</returns>
        [HttpGet("arrivals")]
        public async Task<AirportFlightsModel> GetArrivals()
        {
            var data = await _flightDataApi.GetFlights(new NameValueCollection { { "airport", "BOO" }, { "direction", "A" } });
            return data;
        }


        /// <summary>
        /// Last 24 hours
        /// </summary>
        /// <remarks>
        /// Get all flights from the last 24 hours at Bodø Airport.
        /// </remarks>
        /// <returns>All flights from the last 24 hours</returns>
        [HttpGet("last24hours")]
        public async Task<IEnumerable<FlightModel>> GetLast24Hours()
        {
            var data = await _flightDataApi.GetLast24HoursFlights(new NameValueCollection { { "airport", "BOO" } });
            return data;
        }
    }
}
