﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Flights.Models;
using Flights.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Flights.Controllers
{
    [Route("meta")]
    [ApiController]
    public class MetaController : ControllerBase
    {
        private readonly IFlightDataApiService _flightDataApi;
        public MetaController(IFlightDataApiService flightDataApi)
        {
            _flightDataApi = flightDataApi;
        }

        /// <summary>
        /// Airports
        /// </summary>
        /// <remarks>
        /// Get all airport names and their code.
        /// </remarks>
        /// <returns></returns>
        [HttpGet("airports")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IEnumerable<AirportModel>> GetAirports()
        {
            var data = await _flightDataApi.GetAirports();
            return data;
        }

        /// <summary>
        /// Statuses
        /// </summary>
        /// <remarks>
        /// Get all possible flight statuses
        /// </remarks>
        /// <returns></returns>
        [HttpGet("statuses")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IEnumerable<FlightStatusModel>> GetStatuses()
        {
            var data = await _flightDataApi.GetFlightStatuses();
            return data;
        }

    }
}
