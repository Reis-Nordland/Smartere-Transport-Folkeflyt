﻿using System.Collections.Generic;
using System.Collections.Specialized;
using System.Threading.Tasks;
using Flights.Models;

namespace Flights.Services
{
    public interface IFlightDataApiService
    {
        Task<AirportFlightsModel> GetFlights(NameValueCollection parameters);

        Task<IEnumerable<AirportModel>> GetAirports();

        Task<IEnumerable<FlightStatusModel>> GetFlightStatuses();
        Task<IEnumerable<FlightModel>> GetLast24HoursFlights(NameValueCollection parameters);
    }
}
