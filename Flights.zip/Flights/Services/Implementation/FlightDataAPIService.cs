﻿using System.Collections.Generic;
using System.Collections.Specialized;
using System.Threading.Tasks;
using Flights.Facades;
using Flights.Mappers;
using Flights.Models;

namespace Flights.Services.Implementation
{
    public class FlightDataApiService : IFlightDataApiService
    {
        private readonly IAvinorApiFacade _facade;
        public FlightDataApiService(IAvinorApiFacade facade)
        {
            _facade = facade;
        }

        public async Task<AirportFlightsModel> GetFlights(NameValueCollection parameters)
        {

            var flights = await _facade.GetFlights(parameters);
            var airports = await _facade.GetAirports();
            var statuses = await _facade.GetFlightStatuses();

            return flights.ToModel(airports.ToModel(), statuses.ToModel());
        }

        public async Task<IEnumerable<AirportModel>> GetAirports()
        {
            var airports = await _facade.GetAirports();
            return airports.ToModel();
        }

        public async Task<IEnumerable<FlightStatusModel>> GetFlightStatuses()
        {
            var statuses = await _facade.GetFlightStatuses();
            return statuses.ToModel();
        }

        public async Task<IEnumerable<FlightModel>> GetLast24HoursFlights(NameValueCollection parameters)
        {
            var flights = await _facade.GetLast24Hours(parameters);
            var airports = await _facade.GetAirports();
            var statuses = await _facade.GetFlightStatuses();

            return flights.ToModel(airports.ToModel(), statuses.ToModel()).Flights;
        }
    }
}
