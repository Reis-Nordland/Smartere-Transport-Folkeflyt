﻿namespace Flights.Models
{
    public class AirportModel
    { 
        public string Code { get; set; }
        public string Name { get; set; }
    }
}