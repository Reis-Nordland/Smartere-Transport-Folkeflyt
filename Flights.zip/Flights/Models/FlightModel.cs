﻿using System;
using System.Collections.Generic;

namespace Flights.Models
{
    public class FlightModel
    {
        /// <summary>
        /// Angir unik ID for flight, max 12 tall
        /// </summary>
        public string UniqueId { get; set; }

        public string Airline { get; set; }
        
        /// <summary>
        /// ID for flight. Eks: "SK4167".
        /// </summary>
        public string FlightId { get; set; }
    
        /// <summary>
        /// Angir ankomst eller avgang. "Arrival" eller "Departure"
        /// </summary>
        public string Direction { get; set; }

        /// <summary>
        /// Angir type flight. Innenriks ("Domestic"), internasjonal ("International") eller Schengen ("Schengen")
        /// </summary>
        public string Type { get; set; }

        /// <summary>
        /// Ankomst/Avgangstid (UTC)
        /// </summary>
        public DateTime ScheduledTime { get; set; }

        /// <summary>
        /// Viser IATA-kode for ankomst- eller avgangsflyplass avhengig av "Direction"
        /// </summary>
        public AirportModel Airport { get; set; }

        /// <summary>
        /// Viser eventuelle mellomlandinger
        /// </summary>
        public IEnumerable<AirportModel> ViaAirports { get; set; }
  
        /// <summary>
        /// Unik Id for flight
        /// </summary>
        public string Gate { get; set; }

        /// <summary>
        ///  Viser innsjekkingsområde (foreløpig bare tilgjengelig for Oslo Lufthavn). Eks: "A, B, C, D".
        /// </summary>
        public string CheckIn { get; set; }

        /// <summary>
        /// Angir hvilket bagasjebånd som benyttes for en flight.
        /// </summary>
        public string BeltNumber { get; set; }

        public FlightStatusModel Status { get; set; }
        
        /// <summary>
        /// Angir om flight er forsinket.
        /// </summary>
        public bool Delayed { get; set; }
    }
}
