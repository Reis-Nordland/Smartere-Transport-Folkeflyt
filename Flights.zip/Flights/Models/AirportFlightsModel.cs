﻿using System;
using System.Collections.Generic;

namespace Flights.Models
{
    public class AirportFlightsModel
    {
        public AirportFlightsModel()
        {
            Flights = new List<FlightModel>();
        }
        public DateTime? LastUpdated { get; set; }
        public AirportModel Airport { get; set; }

        /// <summary>
        /// Scheduled flights for the given airport.
        /// </summary>
        public IEnumerable<FlightModel> Flights { get; set; }
    }
}
