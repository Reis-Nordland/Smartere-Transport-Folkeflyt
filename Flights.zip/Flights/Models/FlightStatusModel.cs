﻿using System;

namespace Flights.Models
{
    public class FlightStatusModel
    {
        /// <summary>
        /// Angir status på en flight
        /// </summary>
        public string Code { get; set; }
        /// <summary>
        /// StatusDto tekst på engelsk
        /// </summary>
        public string English { get; set; }
        /// <summary>
        /// StatusDto tekst på norsk
        /// </summary>
        public string Norwegian { get; set; }
        /// <summary>
        /// Angir statustidspunkt for en flight (UTC)
        /// </summary>
        public DateTime? Time { get; set; }
    }
}
