﻿namespace Flights.Config
{
    public class AvinorApiConfig
    {
        public string BaseUri { get; set; }
    }
}
