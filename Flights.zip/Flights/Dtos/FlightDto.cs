﻿using System;
using System.Xml.Serialization;

namespace Flights.Dtos
{
    [XmlRoot(ElementName = "flight")]
    public class FlightDto
    {
        [XmlElement(ElementName = "check_in")]
        public string Check_in { get; set; }
        
        [XmlElement(ElementName = "belt")]
        public string Belt { get; set; }

        [XmlElement(ElementName = "airline")]
        public string Airline { get; set; }

        /// <summary>
        /// airport - Obligatorisk. Viser IATA-kode for ankomst- eller avgangsflyplass avhengig av arr_dep. Se egen tjeneste for navn på flyplass nedenfor.
        /// </summary>
        [XmlElement(ElementName = "airport")]
        public string Airport { get; set; }

        /// <summary>
        /// arr_dep - Obligatorisk. Angir ankomst eller avgang. A = "Ankomst", D = "Avgang".
        /// </summary>
        [XmlElement(ElementName = "arr_dep")]
        public string Arr_dep { get; set; }

        /// <summary>
        /// dom_int - Obligatorisk. Viser om det er en innenriks (D), internasjonal (I) eller Schengen (S) flight.
        /// </summary>
        [XmlElement(ElementName = "dom_int")]
        public string Dom_int { get; set; }

        /// <summary>
        /// flight_id - Obligatorisk. Sub-element av ”flight” som angir ID for flight. Eks: "SK4167".
        /// </summary>
        [XmlElement(ElementName = "flight_id")]
        public string Flight_id { get; set; }

        /// <summary>
        /// gate - Ikke-obligatorisk. Viser gatenummer. Kan inneholde både tall og bokstaver. Eks: "37B".
        /// </summary>
        [XmlElement(ElementName = "gate")]
        public string Gate { get; set; }

        /// <summary>
        /// schedule_time - Obligatorisk.ankomst/avgangstid.Eks: "2009-02-03T09:30:00Z".
        /// </summary>
        [XmlElement(ElementName = "schedule_time")]
        public DateTime Schedule_time { get; set; }


        [XmlElement(ElementName = "status")]
        public StatusDto StatusDto { get; set; }

        /// <summary>
        /// uniqueId - Obligatorisk. Attributt for elementet flight som angir unik ID for flight, max 12 tall
        /// </summary>
        [XmlAttribute(AttributeName = "uniqueID")]
        public string UniqueID { get; set; }

        /// <summary>
        /// via_airport - Ikke-obligatorisk. Viser eventuelle mellomlandinger, max. 6 IATA-koder atskilt med komma «,».
        /// </summary>
        [XmlElement(ElementName = "via_airport")]
        public string Via_airport { get; set; }

        [XmlElement(ElementName = "delayed")]
        public string Delayed { get; set; }
    }
}
