﻿using System;
using System.Collections.Generic;
using System.Xml.Serialization;

namespace Flights.Dtos
{
    [XmlRoot(ElementName = "flights")]
    public class FlightsDto
    {
        [XmlElement(ElementName = "flight")]
        public List<FlightDto> Flight { get; set; }

        /// <summary>
        /// lastUpdate - Obligatorisk. Attributt for elementet flights som angir siste endringstidspunkt for flydata for den aktuelle flyplassen. Eks: ”2009-02-03T09:30:00Z”.
        /// </summary>
        [XmlAttribute(AttributeName = "lastUpdate")]
        public DateTime LastUpdate { get; set; }
    }
}
