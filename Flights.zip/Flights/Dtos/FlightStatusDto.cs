﻿using System.Xml.Serialization;

namespace Flights.Dtos
{
    [XmlRoot(ElementName = "flightStatus")]
    public class FlightStatusDto
    {
        [XmlAttribute(AttributeName = "code")]
        public string Code { get; set; }
        [XmlAttribute(AttributeName = "statusTextEn")]
        public string StatusTextEn { get; set; }
        [XmlAttribute(AttributeName = "statusTextNo")]
        public string StatusTextNo { get; set; }
    }
}
