﻿using System.Xml.Serialization;

namespace Flights.Dtos
{
    [XmlRoot(ElementName = "airport")]
    public class AirportDto
    {
        [XmlElement(ElementName = "flights")]
        public FlightsDto FlightsDto { get; set; }
        [XmlAttribute(AttributeName = "name")]
        
        public string Name { get; set; }
    }
}
