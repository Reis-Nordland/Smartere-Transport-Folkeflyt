﻿using System.Collections.Generic;
using System.Xml.Serialization;

namespace Flights.Dtos
{
    [XmlRoot(ElementName = "airportNames")]
    public class AirportNamesDto
    {
        [XmlElement(ElementName = "airportName")]
        public List<AirportNameDto> AirportName { get; set; }
    }
}
