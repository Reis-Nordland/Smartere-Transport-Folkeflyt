﻿using System;
using System.Xml.Serialization;

namespace Flights.Dtos
{
    [XmlRoot(ElementName = "status")]
    public class StatusDto
    {
        /// <summary>
        /// status code - ikke-obligatorisk. Attributt code på elementet status angir statustekst for en flight: A = "Landet" (Arrived), C = "Innstilt" (Cancelled), D = "Avreist" (Departed), E = "Ny tid" (New time), N = "Ny info" (New info). Merk at statustekstene kan endres uten varsel. Vi anbefaler å benytte egen tjeneste for statustekster (se nedenfor).
        /// </summary>
        [XmlAttribute(AttributeName = "code")]
        public string Code { get; set; }

        /// <summary>
        /// status time - Ikke-obligatorisk. Attributt ”time” på elementet status angir statustidspunkt for en flight. Eks: ”2009-02-03T09:30:00Z”.
        /// </summary>
        [XmlAttribute(AttributeName = "time")]
        public DateTime Time { get; set; }

        /// <summary>
        /// StatusDto text to be displayed, Have to be fetched from another api call
        /// </summary>
        public string StatusTextNo { get; set; }
        public string StatusTextEn { get; set; }
    }
}
