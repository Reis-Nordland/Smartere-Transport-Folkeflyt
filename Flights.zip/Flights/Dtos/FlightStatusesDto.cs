﻿using System.Collections.Generic;
using System.Xml.Serialization;

namespace Flights.Dtos
{
	[XmlRoot(ElementName = "flightStatuses")]
	public class FlightStatusesDto
	{
		[XmlElement(ElementName = "flightStatus")]
		public List<FlightStatusDto> FlightStatus { get; set; }
    }
}
