﻿using System.Xml.Serialization;

namespace Flights.Dtos
{
    [XmlRoot(ElementName = "airportName")]
	public class AirportNameDto
	{
		[XmlAttribute(AttributeName = "code")]
		public string Code { get; set; }
		[XmlAttribute(AttributeName = "name")]
		public string Name { get; set; }
	}
}