﻿using System;
using System.Collections.Generic;
using System.Linq;
using Flights.Dtos;
using Flights.Models;

namespace Flights.Mappers
{
    public static class AirportMapper
    {
        public static AirportModel ToModel(this AirportNameDto dto)
        {
            return new AirportModel
            {
                Code = dto.Code,
                Name = dto.Name,

            };
        }

        public static IEnumerable<AirportModel> ToModel(this IEnumerable<AirportNameDto> dto)
        {
            return dto.Select(model => model.ToModel()).ToList();
        }

        public static FlightModel ToModel(this FlightDto dto, IEnumerable<AirportModel> airports = null, IEnumerable<FlightStatusModel> statuses = null)
        { 
            var status = statuses?.FirstOrDefault(s => s.Code == dto.StatusDto?.Code);

            string type;
            if (dto.Dom_int == "D")
            {
                type = "Domestic";
            }
            else if (dto.Dom_int == "I")
            {
                type = "International";
            }
            else if (dto.Dom_int == "S")
            {
                type = "Schengen";
            }
            else
            {
                type = dto.Dom_int;
            }


            return new FlightModel
            {
                UniqueId = dto.UniqueID,
                FlightId = dto.Flight_id,
                Type = type,
                ScheduledTime = dto.Schedule_time,
                Airport = airports == null ? new AirportModel { Code = dto.Airport } : airports.FirstOrDefault(a => a.Code == dto.Airport),
                Airline = dto.Airline,
                Direction = dto.Arr_dep == "D" ? "Departure" : "Arrival",
                Gate = dto.Gate,
                CheckIn = dto.Check_in,
                BeltNumber = dto.Belt,
                ViaAirports = dto.Via_airport?.ToViaAirportModel(airports),
                Status = new FlightStatusModel
                {
                    Code = status?.Code ?? dto.StatusDto?.Code,
                    English = status?.English ?? dto.StatusDto?.StatusTextEn,
                    Norwegian = status?.Norwegian ?? dto.StatusDto?.StatusTextNo,
                    Time = dto.StatusDto?.Time == null ? null : (DateTime?)dto.StatusDto.Time
                },
                Delayed = dto.Delayed == "Y"
            };

        }

        public static IEnumerable<AirportModel> ToViaAirportModel(this string viaAriports, IEnumerable<AirportModel> airports)
        {
            if (string.IsNullOrEmpty(viaAriports)) return null;

            var formedPorts = new List<AirportModel>();
            var viaPorts = viaAriports.Split(",");

            if (airports == null)
            {
                foreach (var viaAirport in viaPorts)
                {
                    formedPorts.Add(new AirportModel
                    {
                        Code = viaAirport
                    });
                }

                return formedPorts;
            }

            formedPorts.AddRange(viaPorts.Select(viaAirport => airports.FirstOrDefault(a => a.Code == viaAirport)));

            return formedPorts;
        }

        public static IEnumerable<FlightModel> ToModel(this IEnumerable<FlightDto> dto, IEnumerable<AirportModel> airports = null, IEnumerable<FlightStatusModel> statuses = null)
        {
            return dto.Select(model => model.ToModel(airports, statuses)).ToList();
        }



        public static AirportFlightsModel ToModel(this AirportDto dto, IEnumerable<AirportModel> airports, IEnumerable<FlightStatusModel> statuses)
        {
            return new AirportFlightsModel
            {
                LastUpdated = dto?.FlightsDto?.LastUpdate,
                Airport = airports?.FirstOrDefault(x => x.Code == dto.Name),
                Flights = dto.FlightsDto.Flight?.ToModel(airports, statuses)
            };
        }
    }
}
