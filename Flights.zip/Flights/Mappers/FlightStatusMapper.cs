﻿using System.Collections.Generic;
using System.Linq;
using Flights.Dtos;
using Flights.Models;

namespace Flights.Mappers
{
    public static class FlightStatusMapper
    {
       public static FlightStatusModel ToModel(this FlightStatusDto dto)
        {
            return new FlightStatusModel
            {
                Code = dto.Code,
                English = dto.StatusTextEn,
                Norwegian = dto.StatusTextNo

            };
        }

        public static IEnumerable<FlightStatusModel> ToModel(this IEnumerable<FlightStatusDto> dtos)
        {
            return dtos.Select(dto => dto.ToModel()).ToList();
        }
    }
}
